# 🎮 RYCHLÝ START — MapEditorDemo

## Co je v projektu

Hotový Godot 4.6.1 projekt s:
- **Předpřipravenou mapou 64×64** — kopce, řeka, cesty, vesnice, kamenné plošiny
- **153 objektů** — stromy, kameny, keře, dekorace
- **9 budov** — domy, tržnice, věž, velký dům na plošině
- **Plugin MapEditor** zapnutý a připravený k použití
- **Orbit kamera** — scroll = zoom, prostřední myš = otáčení, pravá myš = posun

---

## Krok za krokem

### 1. Otevři projekt
```
1. Otevři Godot 4.6.1
2. Import → vybereš složku "godot_project"
3. Otevři projekt
```

### 2. Plugin se aktivuje sám
- Plugin "MapEditor" je už zapnutý v `project.godot`
- Vpravo nahoře uvidíš panel **🗺️ Map Editor v1.0**
- Pokud ne: Project → Project Settings → Plugins → Enable "MapEditor"

### 3. Otevři hlavní scénu
- Otevři `scenes/main.tscn`
- Uvidíš předpřipravený terén s kopcem, řekou, vesnicí
- Kamera se dá ovládat scrollem (zoom), prostředním tlačítkem (orbit), pravým (pan)

### 4. Začni upravovat
- **Malování**: Vyber dlaždici (Grass/Dirt/Stone/Water/Path) → klikni do viewportu
- **Větší štětec**: Zvol 2×2, 3×3 nebo 5×5
- **Výška**: Klikni "Height+" nebo "Height-"
- **Rampa**: Vyber "Transition" → "Ramp ↑" → klikni na buňku
- **Objekty**: Klikni na strom/kámen → "Place Obj" → klikni do mapy
- **Budovy**: Vyber budovu → "Place Bld" → klikni (kontroluje se footprint)
- **Mazání**: "Erase" pro dlaždice, "Del Obj" pro objekty, "Del Bld" pro budovy
- **Fill**: 🪣 Fill vyplní spojené buňky stejného typu
- **Obdélník**: ▮ Rect — táhni obdélník myší

### 5. Uprav vzhled dlaždic
- Vyber dlaždici v paletě (např. Grass)
- V sekci **🎨 Tile Styles**:
  - **Color** — změní barvu
  - **Roughness** — matnost (0 = lesklá, 1 = matná)
  - **Noise** — zvlnění povrchu (0 = hladký, 0.5 = hodně zvlněný)
  - **Texture** — cesta k textuře (např. `res://textures/grass.png`)
  - **Normal** — cesta k normal mapě

### 6. Ulož
- Klikni **Save** v panelu → uloží do `res://map_data.json`
- Soubor je čitelný JSON — můžeš ho i ručně editovat

---

## Co je na mapě

```
┌─────────────────────────────────────────────────────────────────┐
│                          64×64 mapa                             │
│                                                                 │
│  ░░░░░░░░░░░░ Řeka (water) ░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░  │ ← z=16
│                                                                 │
│          ◇ Kamenné výchozy (stone, výška+1)                     │
│                                                                 │
│              ╔═══════════╗                                      │
│              ║  KOPEC    ║ ← výška 2 uprostřed                  │
│              ║  (grass)  ║    výška 1 okraj                     │
│              ║  rampy    ║    rampy na severu                   │
│              ╚═══════════╝                                      │
│                                                                 │
│  │ Cesta (path)        ─── Cesta (path) ───                    │
│  │ sever-jih                východ-západ                       │
│  │                                                              │
│  │  🏠🏠🏡  Vesnice     ◆◆◆◆◆◆◆◆                              │
│  │  🏪 Tržnice          ◆ Kamenná ◆ ← výška 1                 │
│  │  🗼 Věž              ◆ plošina ◆   s rampami               │
│  │                       ◆  🏰     ◆   a velkým domem         │
│  ▼                       ◆◆◆◆◆◆◆◆                              │
│                                                                 │
│  ▓▓ Hlína (dirt) ▓▓                                            │
│                                                                 │
│  🌳🌳🌳 Stromy rozptýlené po celé mapě 🌳🌳🌳                 │
└─────────────────────────────────────────────────────────────────┘
```

---

## Ovládání kamery v editoru

| Akce | Klávesa/myš |
|------|-------------|
| Zoom | Scroll kolečkem |
| Otáčení | Prostřední tlačítko + tah |
| Posun | Pravé tlačítko + tah |
| Malování | Levé tlačítko |

---

## Tipy

- **Ctrl+Z** = Undo, **Ctrl+Shift+Z** = Redo (standardní Godot)
- Pokud nevidíš terén, klikni na MapRoot v Scene tree
- Mapa se ukládá do `res://map_data.json` — můžeš mít více souborů
- Styl dlaždic (barvy, textury) se ukládá společně s mapou
- Pro runtime: přidej `runtime_map_loader.gd` do herní scény
