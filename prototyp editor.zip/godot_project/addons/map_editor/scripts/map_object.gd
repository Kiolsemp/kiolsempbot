## map_object.gd — Placeholder scene‐object placed on the map.
## Generates a simple coloured shape so there's something visible.
@tool
class_name MapObject
extends Node3D

@export var object_id: int = -1
@export var object_type: int = MapConstants.ObjectType.TREE
@export var grid_x: int = 0
@export var grid_z: int = 0
@export var properties: Dictionary = {}

func _ready() -> void:
	_build_visual()

func _build_visual() -> void:
	# Remove old visuals
	for c in get_children():
		c.queue_free()

	var mi := MeshInstance3D.new()
	mi.name = "Visual"
	match object_type:
		MapConstants.ObjectType.TREE:
			# Trunk
			var trunk_mi := MeshInstance3D.new()
			trunk_mi.name = "Trunk"
			var trunk := CylinderMesh.new()
			trunk.top_radius = 0.12
			trunk.bottom_radius = 0.18
			trunk.height = 1.0
			trunk.material = _make_mat(Color(0.45, 0.30, 0.15), 0.9)
			trunk_mi.mesh = trunk
			trunk_mi.position.y = 0.5
			add_child(trunk_mi)
			# Canopy
			mi.mesh = _simple_sphere(Color(0.22, 0.55, 0.18), 0.55)
			mi.position.y = 1.3
		MapConstants.ObjectType.ROCK:
			mi.mesh = _simple_box(Color(0.52, 0.50, 0.48), Vector3(0.6, 0.4, 0.5))
			mi.position.y = 0.2
		MapConstants.ObjectType.BUSH:
			mi.mesh = _simple_sphere(Color(0.28, 0.52, 0.18), 0.35)
			mi.position.y = 0.25
		_:
			mi.mesh = _simple_box(Color(0.8, 0.7, 0.3), Vector3(0.3, 0.5, 0.3))
			mi.position.y = 0.25
	add_child(mi)

func _simple_sphere(col: Color, r: float) -> SphereMesh:
	var sm := SphereMesh.new()
	sm.radius = r
	sm.height = r * 2.0
	sm.radial_segments = 12
	sm.rings = 6
	sm.material = _make_mat(col, 0.9)
	return sm

func _simple_box(col: Color, sz: Vector3) -> BoxMesh:
	var bm := BoxMesh.new()
	bm.size = sz
	bm.material = _make_mat(col, 0.85)
	return bm

func _make_mat(col: Color, roughness: float) -> StandardMaterial3D:
	var mat := StandardMaterial3D.new()
	mat.albedo_color = col
	mat.roughness = roughness
	return mat
