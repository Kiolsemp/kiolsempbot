## mesh_generator.gd v3 — Solid block terrain like tile.glb
##
## CONCEPT:
## Each cell is a SOLID CLOSED BOX — just like tile.glb (1×1×1 with
## TopMaterial on top, SideMaterial on sides). The box goes from Y=0
## up to the cell's height. Neighbouring same-type same-height cells
## share internal walls (they are skipped = seamless merge).
##
## This means:
## - TOP face always exists (no see-through)
## - BOTTOM face at Y=0 always exists
## - 4 SIDE faces exist unless hidden by same-type same-height neighbour
## - Ramps are smoothly subdivided with Hermite interpolation
## - Side walls of ramps follow the slope contour
##
## Materials: Two surfaces per chunk — "top" surface and "side" surface,
## matching the tile.glb TopMaterial / SideMaterial approach.
@tool
class_name MeshGenerator
extends RefCounted

const CS := MapConstants.CELL_SIZE
const LH := MapConstants.LEVEL_HEIGHT
const CHUNK := MapConstants.CHUNK_SIZE
const RAMP_SUBS: int = 8  # Smooth ramp subdivisions

var _noise: FastNoiseLite

func _init() -> void:
	_noise = FastNoiseLite.new()
	_noise.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
	_noise.frequency = 0.15
	_noise.seed = 42

# ═══════════════════════════════════════════════════════════════════
#  PUBLIC API
# ═══════════════════════════════════════════════════════════════════

func build_chunk(map_data: MapData, cx: int, cz: int) -> Dictionary:
	# We build TWO surfaces: top faces and side faces
	# This matches the tile.glb material split (TopMaterial + SideMaterial)
	var top_v := PackedVector3Array()
	var top_n := PackedVector3Array()
	var top_c := PackedColorArray()
	var top_uv := PackedVector2Array()
	var top_i := PackedInt32Array()

	var side_v := PackedVector3Array()
	var side_n := PackedVector3Array()
	var side_c := PackedColorArray()
	var side_uv := PackedVector2Array()
	var side_i := PackedInt32Array()

	var has_any := false

	for lz in CHUNK:
		for lx in CHUNK:
			var gx := cx + lx
			var gz := cz + lz
			var c := map_data.cell(gx, gz)
			if c == null or c.tile_type == MapConstants.TileType.EMPTY:
				continue
			has_any = true

			var style: Dictionary = map_data.tile_styles.get(c.tile_type, {})
			var top_col: Color = style.get("color", MapConstants.TILE_COLORS.get(c.tile_type, Color.WHITE))
			var side_col: Color = top_col * 0.55 + Color(0.15, 0.10, 0.05) # Earthy brown tint
			side_col.a = top_col.a
			var ns: float = style.get("noise_strength", 0.12)

			# TOP surface
			if c.transition != MapConstants.TransitionType.NONE:
				_build_ramp_top(map_data, gx, gz, c, top_col, ns, top_v, top_n, top_c, top_uv, top_i)
				_build_ramp_sides(map_data, gx, gz, c, side_col, side_v, side_n, side_c, side_uv, side_i)
			else:
				_build_flat_top(map_data, gx, gz, c, top_col, ns, top_v, top_n, top_c, top_uv, top_i)
				_build_flat_sides(map_data, gx, gz, c, side_col, side_v, side_n, side_c, side_uv, side_i)

	if not has_any:
		return {"mesh": null, "materials": {}}

	var mesh := ArrayMesh.new()
	var materials := {}

	# Surface 0: Top faces
	if top_v.size() > 0:
		var arr := _pack(top_v, top_n, top_c, top_uv, top_i)
		mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arr)
		var mat := _make_top_material(map_data)
		mesh.surface_set_material(0, mat)
		materials["top"] = mat

	# Surface 1: Side faces
	if side_v.size() > 0:
		var arr := _pack(side_v, side_n, side_c, side_uv, side_i)
		var si := mesh.get_surface_count()
		mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arr)
		var mat := _make_side_material()
		mesh.surface_set_material(si, mat)
		materials["side"] = mat

	return {"mesh": mesh, "materials": materials}

# ═══════════════════════════════════════════════════════════════════
#  FLAT CELL — solid box from Y=0 to cell_height
# ═══════════════════════════════════════════════════════════════════

func _build_flat_top(map_data: MapData, gx: int, gz: int, c: CellData,
		col: Color, ns: float,
		verts: PackedVector3Array, norms: PackedVector3Array,
		cols: PackedColorArray, uvs: PackedVector2Array,
		idxs: PackedInt32Array) -> void:
	var top_y: float = c.height * LH
	var x0: float = gx * CS
	var z0: float = gz * CS
	var x1: float = x0 + CS
	var z1: float = z0 + CS

	# Noise for organic undulation
	var y00 := top_y + _hn(x0, z0, ns)
	var y10 := top_y + _hn(x1, z0, ns)
	var y01 := top_y + _hn(x0, z1, ns)
	var y11 := top_y + _hn(x1, z1, ns)

	var v0 := Vector3(x0, y00, z0)
	var v1 := Vector3(x1, y10, z0)
	var v2 := Vector3(x0, y01, z1)
	var v3 := Vector3(x1, y11, z1)

	_quad(v0, v1, v2, v3, Vector3.UP,
		_vc(col, x0, z0), _vc(col, x1, z0), _vc(col, x0, z1), _vc(col, x1, z1),
		verts, norms, cols, uvs, idxs)

func _build_flat_sides(map_data: MapData, gx: int, gz: int, c: CellData,
		col: Color,
		verts: PackedVector3Array, norms: PackedVector3Array,
		cols: PackedColorArray, uvs: PackedVector2Array,
		idxs: PackedInt32Array) -> void:
	var top_y: float = c.height * LH
	var x0: float = gx * CS
	var z0: float = gz * CS
	var x1: float = x0 + CS
	var z1: float = z0 + CS

	# 4 directions: [dx, dz, wall_top_left, wall_top_right, normal]
	var walls := [
		[0, -1, Vector3(x1, top_y, z0), Vector3(x0, top_y, z0), Vector3(0, 0, -1)],  # North
		[0,  1, Vector3(x0, top_y, z1), Vector3(x1, top_y, z1), Vector3(0, 0,  1)],  # South
		[-1, 0, Vector3(x0, top_y, z0), Vector3(x0, top_y, z1), Vector3(-1, 0, 0)],  # West
		[ 1, 0, Vector3(x1, top_y, z1), Vector3(x1, top_y, z0), Vector3( 1, 0, 0)],  # East
	]

	for w in walls:
		var nb := map_data.neighbor(gx, gz, w[0], w[1])
		var floor_y: float = 0.0

		if nb != null and nb.tile_type != MapConstants.TileType.EMPTY:
			# Same type, same height, both flat → seamless, skip this wall
			if nb.tile_type == c.tile_type and nb.height == c.height \
				and c.transition == MapConstants.TransitionType.NONE \
				and nb.transition == MapConstants.TransitionType.NONE:
				continue
			# Neighbour's top
			var nb_top: float = nb.height * LH
			if nb.transition != MapConstants.TransitionType.NONE:
				nb_top += LH  # Ramp cell can reach up to height+1
			floor_y = maxf(0.0, nb_top)

		if top_y <= floor_y:
			continue

		var tl: Vector3 = w[2]
		var tr: Vector3 = w[3]
		var bl := Vector3(tl.x, floor_y, tl.z)
		var br := Vector3(tr.x, floor_y, tr.z)
		var n: Vector3 = w[4]

		# Gradient: darker at bottom, lighter at top
		var col_top := col
		var col_bot := col * 0.7

		_quad(tl, tr, bl, br, n, col_top, col_top, col_bot, col_bot,
			verts, norms, cols, uvs, idxs)

# ═══════════════════════════════════════════════════════════════════
#  RAMP CELL — subdivided smooth slope top + contoured sides
# ═══════════════════════════════════════════════════════════════════

func _build_ramp_top(map_data: MapData, gx: int, gz: int, c: CellData,
		col: Color, ns: float,
		verts: PackedVector3Array, norms: PackedVector3Array,
		cols: PackedColorArray, uvs: PackedVector2Array,
		idxs: PackedInt32Array) -> void:
	var base_y: float = c.height * LH
	var top_y: float = base_y + LH
	var x0: float = gx * CS
	var z0: float = gz * CS
	var is_stair := _is_stairs(c.transition)
	var n_sub := RAMP_SUBS

	# Build vertex grid
	var grid: Array = []
	for row in range(n_sub + 1):
		var row_arr: Array = []
		for col_idx in range(n_sub + 1):
			var u: float = float(col_idx) / float(n_sub)
			var v: float = float(row) / float(n_sub)
			var wx: float = x0 + u * CS
			var wz: float = z0 + v * CS
			var wy: float = _ramp_y(c.transition, u, v, base_y, top_y, is_stair)
			wy += _hn(wx, wz, ns * 0.3)
			row_arr.append(Vector3(wx, wy, wz))
		grid.append(row_arr)

	# Emit quads from grid
	for row in range(n_sub):
		for col_idx in range(n_sub):
			var v0: Vector3 = grid[row][col_idx]
			var v1: Vector3 = grid[row][col_idx + 1]
			var v2: Vector3 = grid[row + 1][col_idx]
			var v3: Vector3 = grid[row + 1][col_idx + 1]
			var n := _qn(v0, v1, v2, v3)
			_quad(v0, v1, v2, v3, n,
				_vc(col, v0.x, v0.z), _vc(col, v1.x, v1.z),
				_vc(col, v2.x, v2.z), _vc(col, v3.x, v3.z),
				verts, norms, cols, uvs, idxs)

func _build_ramp_sides(map_data: MapData, gx: int, gz: int, c: CellData,
		col: Color,
		verts: PackedVector3Array, norms: PackedVector3Array,
		cols: PackedColorArray, uvs: PackedVector2Array,
		idxs: PackedInt32Array) -> void:
	var base_y: float = c.height * LH
	var top_y: float = base_y + LH
	var x0: float = gx * CS
	var z0: float = gz * CS
	var x1: float = x0 + CS
	var z1: float = z0 + CS

	# Corner heights: [NW, NE, SW, SE]
	var ch := _corners(c)

	# Each side wall — 4 directions
	var sides := [
		{"dx": 0, "dz": -1, "h0": ch[1], "h1": ch[0],  # North: NE→NW (facing -Z)
		 "p0": Vector3(x1, 0, z0), "p1": Vector3(x0, 0, z0), "n": Vector3(0, 0, -1)},
		{"dx": 0, "dz": 1, "h0": ch[2], "h1": ch[3],   # South: SW→SE (facing +Z)
		 "p0": Vector3(x0, 0, z1), "p1": Vector3(x1, 0, z1), "n": Vector3(0, 0, 1)},
		{"dx": -1, "dz": 0, "h0": ch[0], "h1": ch[2],  # West: NW→SW (facing -X)
		 "p0": Vector3(x0, 0, z0), "p1": Vector3(x0, 0, z1), "n": Vector3(-1, 0, 0)},
		{"dx": 1, "dz": 0, "h0": ch[3], "h1": ch[1],   # East: SE→NE (facing +X)
		 "p0": Vector3(x1, 0, z1), "p1": Vector3(x1, 0, z0), "n": Vector3(1, 0, 0)},
	]

	for s in sides:
		var nb := map_data.neighbor(gx, gz, s["dx"], s["dz"])
		var floor_y: float = 0.0
		var skip := false

		if nb and nb.tile_type != MapConstants.TileType.EMPTY:
			if nb.tile_type == c.tile_type:
				var nb_ch := _corners(nb)
				var nb_edge := _facing_edge(nb_ch, -s["dx"], -s["dz"])
				# If edges match → seamless
				if absf(s["h0"] - nb_edge[0]) < 0.05 and absf(s["h1"] - nb_edge[1]) < 0.05:
					skip = true
				elif absf(s["h0"] - nb_edge[1]) < 0.05 and absf(s["h1"] - nb_edge[0]) < 0.05:
					skip = true
			if not skip:
				var nb_max: float = maxf(maxf(_corners(nb)[0], _corners(nb)[1]),
										maxf(_corners(nb)[2], _corners(nb)[3]))
				floor_y = nb_max

		if skip:
			continue

		var edge_h0: float = s["h0"]
		var edge_h1: float = s["h1"]
		if edge_h0 <= floor_y and edge_h1 <= floor_y:
			continue

		# Top-left, top-right, bottom-left, bottom-right
		var tl: Vector3 = s["p0"]; tl.y = edge_h0
		var tr: Vector3 = s["p1"]; tr.y = edge_h1
		var bl: Vector3 = s["p0"]; bl.y = floor_y
		var br: Vector3 = s["p1"]; br.y = floor_y

		var col_top := col
		var col_bot := col * 0.65
		_quad(tl, tr, bl, br, s["n"], col_top, col_top, col_bot, col_bot,
			verts, norms, cols, uvs, idxs)

# ═══════════════════════════════════════════════════════════════════
#  RAMP MATH
# ═══════════════════════════════════════════════════════════════════

func _ramp_y(tr: int, u: float, v: float, lo: float, hi: float, stairs: bool) -> float:
	var t: float = 0.0
	match tr:
		MapConstants.TransitionType.RAMP_NORTH, MapConstants.TransitionType.STAIRS_NORTH:
			t = 1.0 - v  # v=0 (north) is high
		MapConstants.TransitionType.RAMP_SOUTH, MapConstants.TransitionType.STAIRS_SOUTH:
			t = v         # v=1 (south) is high
		MapConstants.TransitionType.RAMP_EAST, MapConstants.TransitionType.STAIRS_EAST:
			t = u         # u=1 (east) is high
		MapConstants.TransitionType.RAMP_WEST, MapConstants.TransitionType.STAIRS_WEST:
			t = 1.0 - u  # u=0 (west) is high
	if stairs:
		t = floor(t * 4.0) / 4.0
	else:
		t = t * t * (3.0 - 2.0 * t)  # Hermite smoothstep
	return lerpf(lo, hi, t)

func _is_stairs(tr: int) -> bool:
	return tr >= MapConstants.TransitionType.STAIRS_NORTH

func _corners(c: CellData) -> Array:
	## Returns [NW, NE, SW, SE] top heights
	var b: float = c.height * LH
	var t: float = b + LH
	match c.transition:
		MapConstants.TransitionType.RAMP_NORTH, MapConstants.TransitionType.STAIRS_NORTH:
			return [t, t, b, b]
		MapConstants.TransitionType.RAMP_SOUTH, MapConstants.TransitionType.STAIRS_SOUTH:
			return [b, b, t, t]
		MapConstants.TransitionType.RAMP_EAST, MapConstants.TransitionType.STAIRS_EAST:
			return [b, t, b, t]
		MapConstants.TransitionType.RAMP_WEST, MapConstants.TransitionType.STAIRS_WEST:
			return [t, b, t, b]
		_:
			return [b, b, b, b]

func _facing_edge(ch: Array, face_dx: int, face_dz: int) -> Array:
	## Returns [h0, h1] of the edge facing the given direction
	if face_dz == -1: return [ch[1], ch[0]]   # North: NE, NW
	if face_dz == 1:  return [ch[2], ch[3]]   # South: SW, SE
	if face_dx == -1: return [ch[0], ch[2]]   # West: NW, SW
	if face_dx == 1:  return [ch[3], ch[1]]   # East: SE, NE
	return [0.0, 0.0]

# ═══════════════════════════════════════════════════════════════════
#  GEOMETRY HELPERS
# ═══════════════════════════════════════════════════════════════════

func _quad(v0: Vector3, v1: Vector3, v2: Vector3, v3: Vector3,
		n: Vector3, c0: Color, c1: Color, c2: Color, c3: Color,
		verts: PackedVector3Array, norms: PackedVector3Array,
		cols: PackedColorArray, uvs: PackedVector2Array,
		idxs: PackedInt32Array) -> void:
	var ib := verts.size()
	verts.append(v0); verts.append(v1); verts.append(v2); verts.append(v3)
	norms.append(n); norms.append(n); norms.append(n); norms.append(n)
	cols.append(c0); cols.append(c1); cols.append(c2); cols.append(c3)
	uvs.append(Vector2(0, 0)); uvs.append(Vector2(1, 0))
	uvs.append(Vector2(0, 1)); uvs.append(Vector2(1, 1))
	idxs.append(ib); idxs.append(ib + 2); idxs.append(ib + 1)
	idxs.append(ib + 1); idxs.append(ib + 2); idxs.append(ib + 3)

func _qn(v0: Vector3, v1: Vector3, v2: Vector3, v3: Vector3) -> Vector3:
	var n := (v1 - v0).cross(v2 - v0) + (v2 - v3).cross(v1 - v3)
	return n.normalized() if n.length_squared() > 0.001 else Vector3.UP

func _hn(x: float, z: float, amp: float) -> float:
	if amp < 0.001: return 0.0
	return _noise.get_noise_2d(x * 2.5, z * 2.5) * amp

func _vc(base: Color, x: float, z: float) -> Color:
	var v := _noise.get_noise_2d(x * 3.0 + 200.0, z * 3.0 + 200.0) * 0.05
	return Color(clampf(base.r + v, 0, 1), clampf(base.g + v, 0, 1),
				 clampf(base.b + v * 0.5, 0, 1), base.a)

func _pack(v: PackedVector3Array, n: PackedVector3Array, c: PackedColorArray,
		uv: PackedVector2Array, i: PackedInt32Array) -> Array:
	var arr := []
	arr.resize(Mesh.ARRAY_MAX)
	arr[Mesh.ARRAY_VERTEX] = v
	arr[Mesh.ARRAY_NORMAL] = n
	arr[Mesh.ARRAY_COLOR] = c
	arr[Mesh.ARRAY_TEX_UV] = uv
	arr[Mesh.ARRAY_INDEX] = i
	return arr

# ═══════════════════════════════════════════════════════════════════
#  MATERIALS — matching tile.glb concept (TopMaterial + SideMaterial)
# ═══════════════════════════════════════════════════════════════════

func _make_top_material(map_data: MapData) -> StandardMaterial3D:
	var mat := StandardMaterial3D.new()
	mat.vertex_color_use_as_albedo = true
	mat.albedo_color = Color.WHITE
	mat.roughness = 0.85
	mat.cull_mode = BaseMaterial3D.CULL_BACK
	return mat

func _make_side_material() -> StandardMaterial3D:
	var mat := StandardMaterial3D.new()
	mat.vertex_color_use_as_albedo = true
	mat.albedo_color = Color.WHITE
	mat.roughness = 0.95
	mat.cull_mode = BaseMaterial3D.CULL_BACK
	return mat

# ═══════════════════════════════════════════════════════════════════
#  COLLISION
# ═══════════════════════════════════════════════════════════════════

func build_collision_shape(mesh: ArrayMesh) -> ConcavePolygonShape3D:
	if mesh == null or mesh.get_surface_count() == 0:
		return null
	var shape := ConcavePolygonShape3D.new()
	var faces := PackedVector3Array()
	for si in mesh.get_surface_count():
		var arr := mesh.surface_get_arrays(si)
		var v: PackedVector3Array = arr[Mesh.ARRAY_VERTEX]
		var idx: PackedInt32Array = arr[Mesh.ARRAY_INDEX]
		for i in range(0, idx.size(), 3):
			faces.append(v[idx[i]])
			faces.append(v[idx[i + 1]])
			faces.append(v[idx[i + 2]])
	shape.set_faces(faces)
	return shape
