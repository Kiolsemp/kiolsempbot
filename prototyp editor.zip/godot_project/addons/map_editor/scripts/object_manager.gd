## object_manager.gd — Spawns and manages MapObject + MapBuilding nodes.
@tool
class_name ObjectManager
extends Node3D

var map_data: MapData
var _obj_nodes: Dictionary = {}       # object id -> MapObject
var _building_nodes: Dictionary = {}  # building uid -> MapBuilding

func initialize(data: MapData) -> void:
	map_data = data
	rebuild_all()

func rebuild_all() -> void:
	_clear_all()
	if map_data == null:
		return
	for o in map_data.objects:
		_spawn_object(o)
	for b in map_data.buildings:
		_spawn_building(b)

func _clear_all() -> void:
	for child in get_children():
		child.queue_free()
	_obj_nodes.clear()
	_building_nodes.clear()

# ─── Objects ─────────────────────────────────────────────────────
func spawn_object_from_data(o: Dictionary) -> MapObject:
	return _spawn_object(o)

func _spawn_object(o: Dictionary) -> MapObject:
	var node := MapObject.new()
	node.object_id = o["id"]
	node.object_type = o["type"]
	node.grid_x = o["gx"]
	node.grid_z = o["gz"]
	node.properties = o.get("props", {})
	var sc: Array = o.get("scale", [1, 1, 1])
	node.scale = Vector3(sc[0], sc[1], sc[2])
	node.rotation.y = o.get("rotation", 0.0)

	var c := map_data.cell(o["gx"], o["gz"])
	var y: float = 0.0
	if c:
		y = c.height * MapConstants.LEVEL_HEIGHT
	node.position = Vector3(
		o["gx"] * MapConstants.CELL_SIZE + MapConstants.CELL_SIZE * 0.5,
		y,
		o["gz"] * MapConstants.CELL_SIZE + MapConstants.CELL_SIZE * 0.5
	)
	node.name = "Obj_%d" % o["id"]
	add_child(node)
	_obj_nodes[o["id"]] = node
	return node

func remove_object_node(id: int) -> void:
	if _obj_nodes.has(id):
		_obj_nodes[id].queue_free()
		_obj_nodes.erase(id)

# ─── Buildings ───────────────────────────────────────────────────
func spawn_building_from_data(b: Dictionary) -> MapBuilding:
	return _spawn_building(b)

func _spawn_building(b: Dictionary) -> MapBuilding:
	var node := MapBuilding.new()
	node.building_uid = b["uid"]
	node.type_id = b["type_id"]
	node.grid_x = b["gx"]
	node.grid_z = b["gz"]
	node.footprint_w = b["fw"]
	node.footprint_h = b["fh"]
	node.properties = b.get("props", {})
	node.rotation.y = b.get("rotation", 0.0)

	var c := map_data.cell(b["gx"], b["gz"])
	var y: float = 0.0
	if c:
		y = c.height * MapConstants.LEVEL_HEIGHT
	node.position = Vector3(
		b["gx"] * MapConstants.CELL_SIZE,
		y,
		b["gz"] * MapConstants.CELL_SIZE
	)
	node.name = "Bld_%d" % b["uid"]
	add_child(node)
	_building_nodes[b["uid"]] = node
	return node

func remove_building_node(uid: int) -> void:
	if _building_nodes.has(uid):
		_building_nodes[uid].queue_free()
		_building_nodes.erase(uid)
