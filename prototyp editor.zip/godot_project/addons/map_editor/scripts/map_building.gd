## map_building.gd — Placeholder building placed on the map.
@tool
class_name MapBuilding
extends Node3D

@export var building_uid: int = -1
@export var type_id: int = 0
@export var grid_x: int = 0
@export var grid_z: int = 0
@export var footprint_w: int = 1
@export var footprint_h: int = 1
@export var properties: Dictionary = {}

# Predefined building templates: {type_id: {name, fw, fh, color}}
const TEMPLATES: Dictionary = {
	0: {"name": "Small House",  "fw": 1, "fh": 1, "color": Color(0.85, 0.75, 0.55)},
	1: {"name": "Medium House", "fw": 2, "fh": 2, "color": Color(0.80, 0.60, 0.45)},
	2: {"name": "Large House",  "fw": 3, "fh": 3, "color": Color(0.70, 0.55, 0.40)},
	3: {"name": "Castle",       "fw": 4, "fh": 4, "color": Color(0.60, 0.60, 0.65)},
	4: {"name": "Tower",        "fw": 1, "fh": 1, "color": Color(0.55, 0.55, 0.60)},
	5: {"name": "Market",       "fw": 2, "fh": 3, "color": Color(0.75, 0.65, 0.40)},
}

func _ready() -> void:
	_build_visual()

func _build_visual() -> void:
	for c in get_children():
		c.queue_free()
	var tmpl: Dictionary = TEMPLATES.get(type_id, TEMPLATES[0])
	var w: float = footprint_w * MapConstants.CELL_SIZE
	var h_val: float = MapConstants.CELL_SIZE * 1.5  # Visual height
	var d: float = footprint_h * MapConstants.CELL_SIZE

	var mi := MeshInstance3D.new()
	mi.name = "Visual"
	var bm := BoxMesh.new()
	bm.size = Vector3(w, h_val, d)
	mi.mesh = bm
	mi.position = Vector3(w * 0.5, h_val * 0.5, d * 0.5)

	var mat := StandardMaterial3D.new()
	mat.albedo_color = tmpl.get("color", Color.WHITE)
	mat.roughness = 0.8
	mi.material_override = mat
	add_child(mi)

	# Label
	var label := Label3D.new()
	label.name = "Label"
	label.text = tmpl.get("name", "Building")
	label.font_size = 32
	label.position = Vector3(w * 0.5, h_val + 0.3, d * 0.5)
	label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	add_child(label)
