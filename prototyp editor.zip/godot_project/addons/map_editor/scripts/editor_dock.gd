## editor_dock.gd — The dock panel UI for the map editor.
## Contains: tile palette, tool selection, brush size, tile style editor,
## object/building palette, save/load, and status bar.
@tool
class_name MapEditorDock
extends Control

signal tool_changed(tool_mode: int)
signal tile_selected(tile_type: int)
signal brush_size_changed(size: int)
signal transition_selected(transition_type: int)
signal object_selected(object_type: int)
signal building_selected(building_type_id: int)
signal save_requested()
signal load_requested()
signal new_map_requested()
signal tile_style_changed(tile_type: int, style: Dictionary)

var current_tool: int = MapConstants.ToolMode.PAINT
var current_tile: int = MapConstants.TileType.GRASS
var current_brush_size: int = 1
var current_transition: int = MapConstants.TransitionType.NONE
var current_object_type: int = MapConstants.ObjectType.TREE
var current_building_type: int = 0

var _status_label: Label
var _tile_buttons: Dictionary = {}
var _style_controls: Dictionary = {}   # Per tile‐type style widgets
var _map_data_ref: MapData              # Reference for reading styles

func set_map_data(md: MapData) -> void:
	_map_data_ref = md
	_refresh_style_controls()

func _ready() -> void:
	_build_ui()

func show_status(text: String) -> void:
	if _status_label:
		_status_label.text = text

# ─── UI Builder ──────────────────────────────────────────────────
func _build_ui() -> void:
	custom_minimum_size = Vector2(320, 0)
	var scroll := ScrollContainer.new()
	scroll.set_anchors_and_offsets_preset(PRESET_FULL_RECT)
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	add_child(scroll)

	var vbox := VBoxContainer.new()
	vbox.size_flags_horizontal = SIZE_EXPAND_FILL
	scroll.add_child(vbox)

	_add_section_label(vbox, "🗺️  Map Editor v1.0")
	_add_separator(vbox)

	# ── File buttons ──
	_add_section_label(vbox, "File")
	var file_row := HBoxContainer.new()
	vbox.add_child(file_row)
	_add_button(file_row, "New", _on_new, "Create a blank map")
	_add_button(file_row, "Save", _on_save, "Save map to file")
	_add_button(file_row, "Load", _on_load, "Load map from file")

	_add_separator(vbox)

	# ── Tool selection ──
	_add_section_label(vbox, "Tool")
	var tool_grid := GridContainer.new()
	tool_grid.columns = 3
	vbox.add_child(tool_grid)
	_add_tool_btn(tool_grid, "🖌️ Paint",    MapConstants.ToolMode.PAINT,       "Paint tiles")
	_add_tool_btn(tool_grid, "▮ Rect",      MapConstants.ToolMode.RECTANGLE,   "Drag a rectangle")
	_add_tool_btn(tool_grid, "🪣 Fill",      MapConstants.ToolMode.FILL,        "Flood fill same type")
	_add_tool_btn(tool_grid, "⬆ Height+",   MapConstants.ToolMode.HEIGHT_UP,   "Raise by 1 level")
	_add_tool_btn(tool_grid, "⬇ Height-",   MapConstants.ToolMode.HEIGHT_DOWN, "Lower by 1 level")
	_add_tool_btn(tool_grid, "🔀 Transit",  MapConstants.ToolMode.TRANSITION,  "Set ramp/stairs")

	_add_separator(vbox)

	# ── Brush size ──
	_add_section_label(vbox, "Brush Size")
	var brush_row := HBoxContainer.new()
	vbox.add_child(brush_row)
	for s in [1, 2, 3, 5]:
		var b := Button.new()
		b.text = "%dx%d" % [s, s]
		b.custom_minimum_size = Vector2(56, 36)
		b.tooltip_text = "Brush %dx%d" % [s, s]
		b.pressed.connect(_on_brush.bind(s))
		brush_row.add_child(b)

	_add_separator(vbox)

	# ── Tile palette ──
	_add_section_label(vbox, "🧱 Tiles")
	var tile_grid := GridContainer.new()
	tile_grid.columns = 3
	vbox.add_child(tile_grid)
	for t_key in MapConstants.TILE_NAMES:
		if t_key == MapConstants.TileType.EMPTY:
			continue
		var b := Button.new()
		b.text = MapConstants.TILE_NAMES[t_key]
		b.custom_minimum_size = Vector2(90, 36)
		b.tooltip_text = "Select " + MapConstants.TILE_NAMES[t_key]
		b.pressed.connect(_on_tile.bind(t_key))
		tile_grid.add_child(b)
		_tile_buttons[t_key] = b
	# Eraser
	var eb := Button.new()
	eb.text = "❌ Erase"
	eb.custom_minimum_size = Vector2(90, 36)
	eb.tooltip_text = "Erase tile (set to empty)"
	eb.pressed.connect(_on_tile.bind(MapConstants.TileType.EMPTY))
	tile_grid.add_child(eb)
	_tile_buttons[MapConstants.TileType.EMPTY] = eb

	_add_separator(vbox)

	# ── Tile Style Editor ──
	_add_section_label(vbox, "🎨 Tile Styles (select a tile first)")
	var style_box := VBoxContainer.new()
	style_box.name = "StyleBox"
	vbox.add_child(style_box)
	_build_style_editor(style_box)

	_add_separator(vbox)

	# ── Transitions ──
	_add_section_label(vbox, "🔀 Transitions")
	var trans_grid := GridContainer.new()
	trans_grid.columns = 3
	vbox.add_child(trans_grid)
	for tr_key in MapConstants.TRANSITION_NAMES:
		var b := Button.new()
		b.text = MapConstants.TRANSITION_NAMES[tr_key]
		b.custom_minimum_size = Vector2(90, 32)
		b.pressed.connect(_on_transition.bind(tr_key))
		trans_grid.add_child(b)

	_add_separator(vbox)

	# ── Objects ──
	_add_section_label(vbox, "🌳 Objects")
	var obj_row := HBoxContainer.new()
	vbox.add_child(obj_row)
	_add_tool_btn(obj_row, "📌 Place Obj", MapConstants.ToolMode.OBJECT_PLACE, "Place selected object")
	_add_tool_btn(obj_row, "🗑️ Del Obj",   MapConstants.ToolMode.OBJECT_ERASE, "Remove object at cell")
	var obj_grid := GridContainer.new()
	obj_grid.columns = 2
	vbox.add_child(obj_grid)
	for o_key in MapConstants.OBJECT_NAMES:
		var b := Button.new()
		b.text = MapConstants.OBJECT_NAMES[o_key]
		b.custom_minimum_size = Vector2(90, 32)
		b.tooltip_text = "Select " + MapConstants.OBJECT_NAMES[o_key]
		b.pressed.connect(_on_object.bind(o_key))
		obj_grid.add_child(b)

	_add_separator(vbox)

	# ── Buildings ──
	_add_section_label(vbox, "🏠 Buildings")
	var bld_row := HBoxContainer.new()
	vbox.add_child(bld_row)
	_add_tool_btn(bld_row, "📌 Place Bld", MapConstants.ToolMode.BUILDING_PLACE, "Place selected building")
	_add_tool_btn(bld_row, "🗑️ Del Bld",   MapConstants.ToolMode.BUILDING_ERASE, "Remove building at cell")
	var bld_grid := GridContainer.new()
	bld_grid.columns = 2
	vbox.add_child(bld_grid)
	for bt_key in MapBuilding.TEMPLATES:
		var tmpl: Dictionary = MapBuilding.TEMPLATES[bt_key]
		var b := Button.new()
		b.text = "%s (%dx%d)" % [tmpl["name"], tmpl["fw"], tmpl["fh"]]
		b.custom_minimum_size = Vector2(140, 32)
		b.pressed.connect(_on_building.bind(bt_key))
		bld_grid.add_child(b)

	_add_separator(vbox)

	# ── Status ──
	_status_label = Label.new()
	_status_label.text = "Ready. Select a tool and click in the 3D viewport."
	_status_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	vbox.add_child(_status_label)

# ─── Style Editor ────────────────────────────────────────────────
func _build_style_editor(parent: VBoxContainer) -> void:
	# Color picker
	var color_row := HBoxContainer.new()
	parent.add_child(color_row)
	var cl := Label.new()
	cl.text = "Color:"
	color_row.add_child(cl)
	var cp := ColorPickerButton.new()
	cp.name = "StyleColorPicker"
	cp.custom_minimum_size = Vector2(60, 30)
	cp.color = Color.WHITE
	cp.color_changed.connect(_on_style_color_changed)
	color_row.add_child(cp)
	_style_controls["color_picker"] = cp

	# Roughness slider
	var rough_row := HBoxContainer.new()
	parent.add_child(rough_row)
	var rl := Label.new()
	rl.text = "Roughness:"
	rough_row.add_child(rl)
	var rs := HSlider.new()
	rs.name = "StyleRoughness"
	rs.min_value = 0.0
	rs.max_value = 1.0
	rs.step = 0.05
	rs.value = 0.85
	rs.custom_minimum_size = Vector2(120, 0)
	rs.value_changed.connect(_on_style_roughness_changed)
	rough_row.add_child(rs)
	_style_controls["roughness_slider"] = rs

	# Noise strength
	var noise_row := HBoxContainer.new()
	parent.add_child(noise_row)
	var nl := Label.new()
	nl.text = "Noise:"
	noise_row.add_child(nl)
	var ns := HSlider.new()
	ns.name = "StyleNoise"
	ns.min_value = 0.0
	ns.max_value = 0.5
	ns.step = 0.01
	ns.value = 0.15
	ns.custom_minimum_size = Vector2(120, 0)
	ns.value_changed.connect(_on_style_noise_changed)
	noise_row.add_child(ns)
	_style_controls["noise_slider"] = ns

	# Texture path (line edit)
	var tex_row := HBoxContainer.new()
	parent.add_child(tex_row)
	var tl := Label.new()
	tl.text = "Texture:"
	tex_row.add_child(tl)
	var te := LineEdit.new()
	te.name = "StyleTexturePath"
	te.placeholder_text = "res://textures/grass.png"
	te.custom_minimum_size = Vector2(180, 0)
	te.text_submitted.connect(_on_style_texture_changed)
	tex_row.add_child(te)
	_style_controls["texture_edit"] = te

	# Normal map path
	var norm_row := HBoxContainer.new()
	parent.add_child(norm_row)
	var nml := Label.new()
	nml.text = "Normal:"
	norm_row.add_child(nml)
	var ne := LineEdit.new()
	ne.name = "StyleNormalPath"
	ne.placeholder_text = "res://textures/grass_normal.png"
	ne.custom_minimum_size = Vector2(180, 0)
	ne.text_submitted.connect(_on_style_normal_changed)
	norm_row.add_child(ne)
	_style_controls["normal_edit"] = ne

func _refresh_style_controls() -> void:
	if _map_data_ref == null:
		return
	var style: Dictionary = _map_data_ref.tile_styles.get(current_tile, {})
	if _style_controls.has("color_picker"):
		_style_controls["color_picker"].color = style.get("color", Color.WHITE)
	if _style_controls.has("roughness_slider"):
		_style_controls["roughness_slider"].value = style.get("roughness", 0.85)
	if _style_controls.has("noise_slider"):
		_style_controls["noise_slider"].value = style.get("noise_strength", 0.15)
	if _style_controls.has("texture_edit"):
		_style_controls["texture_edit"].text = style.get("texture_path", "")
	if _style_controls.has("normal_edit"):
		_style_controls["normal_edit"].text = style.get("normal_path", "")

func _emit_style_change() -> void:
	if _map_data_ref == null:
		return
	var style: Dictionary = _map_data_ref.tile_styles.get(current_tile, {}).duplicate()
	tile_style_changed.emit(current_tile, style)

func _on_style_color_changed(color: Color) -> void:
	if _map_data_ref and _map_data_ref.tile_styles.has(current_tile):
		_map_data_ref.tile_styles[current_tile]["color"] = color
		_emit_style_change()

func _on_style_roughness_changed(val: float) -> void:
	if _map_data_ref and _map_data_ref.tile_styles.has(current_tile):
		_map_data_ref.tile_styles[current_tile]["roughness"] = val
		_emit_style_change()

func _on_style_noise_changed(val: float) -> void:
	if _map_data_ref and _map_data_ref.tile_styles.has(current_tile):
		_map_data_ref.tile_styles[current_tile]["noise_strength"] = val
		_emit_style_change()

func _on_style_texture_changed(path: String) -> void:
	if _map_data_ref and _map_data_ref.tile_styles.has(current_tile):
		_map_data_ref.tile_styles[current_tile]["texture_path"] = path
		_emit_style_change()

func _on_style_normal_changed(path: String) -> void:
	if _map_data_ref and _map_data_ref.tile_styles.has(current_tile):
		_map_data_ref.tile_styles[current_tile]["normal_path"] = path
		_emit_style_change()

# ─── Callbacks ───────────────────────────────────────────────────
func _on_new() -> void:
	new_map_requested.emit()

func _on_save() -> void:
	save_requested.emit()

func _on_load() -> void:
	load_requested.emit()

func _on_tool(mode: int) -> void:
	current_tool = mode
	tool_changed.emit(mode)
	show_status("Tool: " + _tool_name(mode))

func _on_brush(s: int) -> void:
	current_brush_size = s
	brush_size_changed.emit(s)
	show_status("Brush: %dx%d" % [s, s])

func _on_tile(t: int) -> void:
	current_tile = t
	tile_selected.emit(t)
	show_status("Tile: " + MapConstants.TILE_NAMES.get(t, "?"))
	_refresh_style_controls()

func _on_transition(t: int) -> void:
	current_transition = t
	current_tool = MapConstants.ToolMode.TRANSITION
	transition_selected.emit(t)
	tool_changed.emit(MapConstants.ToolMode.TRANSITION)
	show_status("Transition: " + MapConstants.TRANSITION_NAMES.get(t, "?"))

func _on_object(t: int) -> void:
	current_object_type = t
	current_tool = MapConstants.ToolMode.OBJECT_PLACE
	tool_changed.emit(MapConstants.ToolMode.OBJECT_PLACE)
	object_selected.emit(t)
	show_status("Object: " + MapConstants.OBJECT_NAMES.get(t, "?"))

func _on_building(t: int) -> void:
	current_building_type = t
	current_tool = MapConstants.ToolMode.BUILDING_PLACE
	tool_changed.emit(MapConstants.ToolMode.BUILDING_PLACE)
	building_selected.emit(t)
	var tmpl: Dictionary = MapBuilding.TEMPLATES.get(t, {})
	show_status("Building: " + tmpl.get("name", "?"))

# ─── Helpers ─────────────────────────────────────────────────────
func _tool_name(m: int) -> String:
	match m:
		MapConstants.ToolMode.PAINT: return "Paint"
		MapConstants.ToolMode.RECTANGLE: return "Rectangle"
		MapConstants.ToolMode.FILL: return "Fill"
		MapConstants.ToolMode.HEIGHT_UP: return "Height +"
		MapConstants.ToolMode.HEIGHT_DOWN: return "Height -"
		MapConstants.ToolMode.OBJECT_PLACE: return "Place Object"
		MapConstants.ToolMode.OBJECT_ERASE: return "Remove Object"
		MapConstants.ToolMode.BUILDING_PLACE: return "Place Building"
		MapConstants.ToolMode.BUILDING_ERASE: return "Remove Building"
		MapConstants.ToolMode.TRANSITION: return "Transition"
	return "?"

func _add_section_label(parent: Control, text: String) -> void:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", 15)
	parent.add_child(l)

func _add_separator(parent: Control) -> void:
	var s := HSeparator.new()
	parent.add_child(s)

func _add_button(parent: Control, text: String, callback: Callable, tooltip: String = "") -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(70, 32)
	b.tooltip_text = tooltip
	b.pressed.connect(callback)
	parent.add_child(b)
	return b

func _add_tool_btn(parent: Control, text: String, mode: int, tooltip: String = "") -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(90, 36)
	b.tooltip_text = tooltip
	b.pressed.connect(_on_tool.bind(mode))
	parent.add_child(b)
	return b
