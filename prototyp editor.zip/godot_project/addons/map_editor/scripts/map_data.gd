## map_data.gd — Central data model for the entire map.
@tool
class_name MapData
extends RefCounted

# ─── Grid ────────────────────────────────────────────────────────
var width: int = 128
var height: int = 128
var cells: Array = []            # Flat array [z * width + x]

# ─── Objects ─────────────────────────────────────────────────────
var objects: Array[Dictionary] = []   # {id, type, gx, gz, rotation, scale, props}
var _next_obj_id: int = 0

# ─── Buildings ───────────────────────────────────────────────────
var buildings: Array[Dictionary] = [] # {uid, type_id, gx, gz, footprint_w, footprint_h, rotation, props}
var _next_building_uid: int = 0

# ─── Tile material overrides (per tile‐type) ────────────────────
# Key = TileType int, Value = dict {color, roughness, texture_path, normal_path ...}
var tile_styles: Dictionary = {}

# ─── Init ────────────────────────────────────────────────────────
func _init(w: int = 128, h: int = 128) -> void:
	resize(w, h)
	_init_default_styles()

func _init_default_styles() -> void:
	for t_key in MapConstants.TILE_COLORS:
		tile_styles[t_key] = {
			"color": MapConstants.TILE_COLORS[t_key],
			"roughness": 0.85,
			"texture_path": "",
			"normal_path": "",
			"noise_strength": 0.15,    # Vertex‐noise amplitude (seamless variation)
			"noise_scale": 4.0,
		}

func resize(w: int, h: int) -> void:
	width = w
	height = h
	cells.clear()
	cells.resize(w * h)
	for i in cells.size():
		cells[i] = CellData.new()

# ─── Cell access ─────────────────────────────────────────────────
func in_bounds(gx: int, gz: int) -> bool:
	return gx >= 0 and gx < width and gz >= 0 and gz < height

func cell(gx: int, gz: int) -> CellData:
	if not in_bounds(gx, gz):
		return null
	return cells[gz * width + gx]

func set_cell(gx: int, gz: int, c: CellData) -> void:
	if in_bounds(gx, gz):
		cells[gz * width + gx] = c

# ─── Neighbor helper ─────────────────────────────────────────────
func neighbor(gx: int, gz: int, dx: int, dz: int) -> CellData:
	return cell(gx + dx, gz + dz)

# ─── Objects ─────────────────────────────────────────────────────
func add_object(type: int, gx: int, gz: int, rotation: float = 0.0, scale_v: Vector3 = Vector3.ONE, props: Dictionary = {}) -> int:
	var id := _next_obj_id
	_next_obj_id += 1
	objects.append({
		"id": id, "type": type, "gx": gx, "gz": gz,
		"rotation": rotation, "scale": [scale_v.x, scale_v.y, scale_v.z],
		"props": props,
	})
	return id

func remove_object(id: int) -> bool:
	for i in objects.size():
		if objects[i]["id"] == id:
			objects.remove_at(i)
			return true
	return false

func objects_at(gx: int, gz: int) -> Array:
	var res := []
	for o in objects:
		if o["gx"] == gx and o["gz"] == gz:
			res.append(o)
	return res

# ─── Buildings ───────────────────────────────────────────────────
func can_place_building(gx: int, gz: int, fw: int, fh: int) -> bool:
	for dz in fh:
		for dx in fw:
			var cx := gx + dx
			var cz := gz + dz
			if not in_bounds(cx, cz):
				return false
			var c := cell(cx, cz)
			if c.occupied_by_building >= 0:
				return false
			if c.tile_type == MapConstants.TileType.WATER:
				return false
	# Check height uniformity
	var base_h: int = cell(gx, gz).height
	for dz in fh:
		for dx in fw:
			if cell(gx + dx, gz + dz).height != base_h:
				return false
	return true

func place_building(type_id: int, gx: int, gz: int, fw: int, fh: int, rotation: float = 0.0, props: Dictionary = {}) -> int:
	if not can_place_building(gx, gz, fw, fh):
		return -1
	var uid := _next_building_uid
	_next_building_uid += 1
	buildings.append({
		"uid": uid, "type_id": type_id,
		"gx": gx, "gz": gz,
		"fw": fw, "fh": fh,
		"rotation": rotation,
		"props": props,
	})
	for dz in fh:
		for dx in fw:
			cell(gx + dx, gz + dz).occupied_by_building = uid
	return uid

func remove_building(uid: int) -> bool:
	for i in buildings.size():
		var b: Dictionary = buildings[i]
		if b["uid"] == uid:
			for dz in b["fh"]:
				for dx in b["fw"]:
					var c := cell(b["gx"] + dx, b["gz"] + dz)
					if c:
						c.occupied_by_building = -1
			buildings.remove_at(i)
			return true
	return false

func building_at(gx: int, gz: int) -> Dictionary:
	var c := cell(gx, gz)
	if c and c.occupied_by_building >= 0:
		for b in buildings:
			if b["uid"] == c.occupied_by_building:
				return b
	return {}

# ─── Serialization ───────────────────────────────────────────────
func to_dict() -> Dictionary:
	var cell_arr := []
	for c in cells:
		cell_arr.append(c.to_dict())
	return {
		"version": 1,
		"width": width,
		"height": height,
		"cells": cell_arr,
		"objects": objects.duplicate(true),
		"buildings": buildings.duplicate(true),
		"tile_styles": _serialize_styles(),
		"_next_obj_id": _next_obj_id,
		"_next_building_uid": _next_building_uid,
	}

func _serialize_styles() -> Dictionary:
	var out := {}
	for key in tile_styles:
		var s: Dictionary = tile_styles[key]
		var sc: Dictionary = s.duplicate()
		if sc.has("color") and sc["color"] is Color:
			var col: Color = sc["color"]
			sc["color"] = [col.r, col.g, col.b, col.a]
		out[str(key)] = sc
	return out

static func from_dict(d: Dictionary) -> MapData:
	var m := MapData.new(d.get("width", 128), d.get("height", 128))
	var cell_arr: Array = d.get("cells", [])
	for i in mini(cell_arr.size(), m.cells.size()):
		m.cells[i] = CellData.from_dict(cell_arr[i])
	m.objects.assign(d.get("objects", []))
	m.buildings.assign(d.get("buildings", []))
	m._next_obj_id = d.get("_next_obj_id", 0)
	m._next_building_uid = d.get("_next_building_uid", 0)
	if d.has("tile_styles"):
		m._deserialize_styles(d["tile_styles"])
	return m

func _deserialize_styles(raw: Dictionary) -> void:
	for key_str in raw:
		var key_int := int(key_str)
		var s: Dictionary = raw[key_str]
		if s.has("color") and s["color"] is Array:
			var a: Array = s["color"]
			s["color"] = Color(a[0], a[1], a[2], a[3] if a.size() > 3 else 1.0)
		tile_styles[key_int] = s

func save_to_file(path: String) -> Error:
	var json_str := JSON.stringify(to_dict(), "\t")
	var f := FileAccess.open(path, FileAccess.WRITE)
	if f == null:
		return FileAccess.get_open_error()
	f.store_string(json_str)
	f.close()
	return OK

static func load_from_file(path: String) -> MapData:
	if not FileAccess.file_exists(path):
		return null
	var f := FileAccess.open(path, FileAccess.READ)
	if f == null:
		return null
	var text := f.get_as_text()
	f.close()
	var json := JSON.new()
	if json.parse(text) != OK:
		return null
	return MapData.from_dict(json.data)
