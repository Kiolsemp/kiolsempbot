## map_constants.gd — Shared constants and enums for the map editor.
@tool
class_name MapConstants

# ─── Grid settings ───────────────────────────────────────────────
const CELL_SIZE: float = 2.0          # World‐space width/depth of one cell
const LEVEL_HEIGHT: float = 1.0       # World‐space height of one level step
const MAP_MAX: int = 256              # Maximum map extent per axis
const CHUNK_SIZE: int = 16            # Cells per chunk side (16×16 = 256 cells)

# ─── Tile types ──────────────────────────────────────────────────
enum TileType {
	EMPTY = 0,
	GRASS = 1,
	DIRT = 2,
	STONE = 3,
	WATER = 4,
	PATH = 5,
}

# Human‐readable names for the palette
const TILE_NAMES: Dictionary = {
	TileType.EMPTY: "Empty",
	TileType.GRASS: "Grass",
	TileType.DIRT:  "Dirt",
	TileType.STONE: "Stone",
	TileType.WATER: "Water",
	TileType.PATH:  "Path",
}

# Default colors per tile type (used for procedural mesh tinting)
const TILE_COLORS: Dictionary = {
	TileType.EMPTY: Color(0.0, 0.0, 0.0, 0.0),
	TileType.GRASS: Color(0.32, 0.65, 0.22),
	TileType.DIRT:  Color(0.55, 0.36, 0.20),
	TileType.STONE: Color(0.58, 0.58, 0.56),
	TileType.WATER: Color(0.20, 0.45, 0.75, 0.85),
	TileType.PATH:  Color(0.72, 0.65, 0.50),
}

# ─── Transition / ramp types ────────────────────────────────────
enum TransitionType {
	NONE = 0,
	RAMP_NORTH = 1,
	RAMP_SOUTH = 2,
	RAMP_EAST = 3,
	RAMP_WEST = 4,
	STAIRS_NORTH = 5,
	STAIRS_SOUTH = 6,
	STAIRS_EAST = 7,
	STAIRS_WEST = 8,
}

const TRANSITION_NAMES: Dictionary = {
	TransitionType.NONE: "Flat",
	TransitionType.RAMP_NORTH: "Ramp ↑",
	TransitionType.RAMP_SOUTH: "Ramp ↓",
	TransitionType.RAMP_EAST:  "Ramp →",
	TransitionType.RAMP_WEST:  "Ramp ←",
	TransitionType.STAIRS_NORTH: "Stairs ↑",
	TransitionType.STAIRS_SOUTH: "Stairs ↓",
	TransitionType.STAIRS_EAST:  "Stairs →",
	TransitionType.STAIRS_WEST:  "Stairs ←",
}

# ─── Object types ────────────────────────────────────────────────
enum ObjectType {
	TREE = 0,
	ROCK = 1,
	BUSH = 2,
	DECORATION = 3,
}

const OBJECT_NAMES: Dictionary = {
	ObjectType.TREE: "Tree",
	ObjectType.ROCK: "Rock",
	ObjectType.BUSH: "Bush",
	ObjectType.DECORATION: "Decoration",
}

# ─── Tool modes ──────────────────────────────────────────────────
enum ToolMode {
	PAINT = 0,
	RECTANGLE = 1,
	FILL = 2,
	HEIGHT_UP = 3,
	HEIGHT_DOWN = 4,
	OBJECT_PLACE = 5,
	OBJECT_ERASE = 6,
	BUILDING_PLACE = 7,
	BUILDING_ERASE = 8,
	TRANSITION = 9,
}
