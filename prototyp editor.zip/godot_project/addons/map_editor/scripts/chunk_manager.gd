## chunk_manager.gd — Manages per‐chunk MeshInstance3D + StaticBody3D nodes.
## Only rebuilds chunks that are affected by a cell change → fast local update.
@tool
class_name ChunkManager
extends Node3D

var map_data: MapData
var _meshgen := MeshGenerator.new()
var _chunks: Dictionary = {}       # Vector2i(chunk_x, chunk_z) -> Node3D (chunk root)
var _dirty_chunks: Dictionary = {} # Vector2i -> true  (queued for rebuild)

# ─── Setup ───────────────────────────────────────────────────────
func initialize(data: MapData) -> void:
	map_data = data
	_clear_all()
	_rebuild_all()

# ─── Mark a grid cell dirty (and its border neighbours' chunks) ──
func mark_dirty(gx: int, gz: int) -> void:
	var ck := _chunk_key(gx, gz)
	_dirty_chunks[ck] = true
	# If the cell is on a chunk edge, mark the adjacent chunk too
	var lx := gx % MapConstants.CHUNK_SIZE
	var lz := gz % MapConstants.CHUNK_SIZE
	if lx == 0 and ck.x > 0:
		_dirty_chunks[ck + Vector2i(-1, 0)] = true
	if lx == MapConstants.CHUNK_SIZE - 1:
		_dirty_chunks[ck + Vector2i(1, 0)] = true
	if lz == 0 and ck.y > 0:
		_dirty_chunks[ck + Vector2i(0, -1)] = true
	if lz == MapConstants.CHUNK_SIZE - 1:
		_dirty_chunks[ck + Vector2i(0, 1)] = true

func flush_dirty() -> void:
	for ck in _dirty_chunks:
		_rebuild_chunk(ck)
	_dirty_chunks.clear()

# ─── Internals ───────────────────────────────────────────────────
func _chunk_key(gx: int, gz: int) -> Vector2i:
	@warning_ignore("integer_division")
	return Vector2i(gx / MapConstants.CHUNK_SIZE, gz / MapConstants.CHUNK_SIZE)

func _clear_all() -> void:
	for child in get_children():
		child.queue_free()
	_chunks.clear()
	_dirty_chunks.clear()

func _rebuild_all() -> void:
	if map_data == null:
		return
	var cw := ceili(float(map_data.width) / MapConstants.CHUNK_SIZE)
	var ch := ceili(float(map_data.height) / MapConstants.CHUNK_SIZE)
	for cz in ch:
		for cx in cw:
			_rebuild_chunk(Vector2i(cx, cz))

func _rebuild_chunk(ck: Vector2i) -> void:
	# Remove old node
	if _chunks.has(ck):
		_chunks[ck].queue_free()
		_chunks.erase(ck)

	var cx := ck.x * MapConstants.CHUNK_SIZE
	var cz := ck.y * MapConstants.CHUNK_SIZE
	var result := _meshgen.build_chunk(map_data, cx, cz)
	var mesh: ArrayMesh = result["mesh"]
	if mesh == null:
		return

	var root := Node3D.new()
	root.name = "Chunk_%d_%d" % [ck.x, ck.y]
	add_child(root)
	if Engine.is_editor_hint():
		root.owner = get_tree().edited_scene_root if get_tree() else null

	var mi := MeshInstance3D.new()
	mi.name = "Mesh"
	mi.mesh = mesh
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON
	root.add_child(mi)

	# Collision (for editor raycasting and runtime)
	var shape := _meshgen.build_collision_shape(mesh)
	if shape:
		var sb := StaticBody3D.new()
		sb.name = "Collision"
		var cs := CollisionShape3D.new()
		cs.shape = shape
		sb.add_child(cs)
		root.add_child(sb)

	_chunks[ck] = root
