## cell_data.gd — Lightweight value‐object for a single map cell.
@tool
class_name CellData
extends RefCounted

var tile_type: int = MapConstants.TileType.EMPTY
var height: int = 0                        # Level index (0, 1, 2 …)
var transition: int = MapConstants.TransitionType.NONE
var occupied_by_building: int = -1         # Building UID or ‐1
var metadata: Dictionary = {}              # Future‐proof bag

func duplicate_cell() -> CellData:
	var c := CellData.new()
	c.tile_type = tile_type
	c.height = height
	c.transition = transition
	c.occupied_by_building = occupied_by_building
	c.metadata = metadata.duplicate(true)
	return c

func to_dict() -> Dictionary:
	return {
		"t": tile_type,
		"h": height,
		"tr": transition,
		"b": occupied_by_building,
		"m": metadata,
	}

static func from_dict(d: Dictionary) -> CellData:
	var c := CellData.new()
	c.tile_type = d.get("t", MapConstants.TileType.EMPTY)
	c.height = d.get("h", 0)
	c.transition = d.get("tr", MapConstants.TransitionType.NONE)
	c.occupied_by_building = d.get("b", -1)
	c.metadata = d.get("m", {})
	return c
