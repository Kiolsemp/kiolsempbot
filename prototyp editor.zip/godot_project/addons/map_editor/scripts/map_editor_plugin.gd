## map_editor_plugin.gd — Main EditorPlugin entry point.
## Handles: dock lifecycle, 3D viewport input capture, undo/redo,
## tool dispatch (paint, rect-drag, fill, height, objects, buildings).
@tool
extends EditorPlugin

const DOCK_NAME := "MapEditor"

var _dock: MapEditorDock
var _map_root: MapRoot
var _undo: EditorUndoRedoManager

# Rectangle‐drag state
var _drag_active: bool = false
var _drag_start: Vector2i = Vector2i.ZERO
var _drag_current: Vector2i = Vector2i.ZERO

# Preview highlight
var _preview_node: MeshInstance3D

func _enter_tree() -> void:
	_undo = get_undo_redo()

	_dock = MapEditorDock.new()
	_dock.name = DOCK_NAME
	add_control_to_dock(EditorPlugin.DOCK_SLOT_RIGHT_UL, _dock)

	_dock.save_requested.connect(_on_save)
	_dock.load_requested.connect(_on_load)
	_dock.new_map_requested.connect(_on_new_map)
	_dock.tile_style_changed.connect(_on_tile_style_changed)

	# Try to find an existing MapRoot in the scene
	_find_or_create_map_root()
	_dock.show_status("Plugin loaded. Click in 3D viewport to paint.")

func _exit_tree() -> void:
	if _preview_node and is_instance_valid(_preview_node):
		_preview_node.queue_free()
	remove_control_from_docks(_dock)
	if _dock:
		_dock.queue_free()

# ─── Ensure a MapRoot exists ─────────────────────────────────────
func _find_or_create_map_root() -> void:
	var root := get_editor_interface().get_edited_scene_root()
	if root == null:
		return
	_map_root = _find_map_root(root)
	if _map_root == null:
		_map_root = MapRoot.new()
		_map_root.name = "MapRoot"
		root.add_child(_map_root)
		_map_root.owner = root
		_map_root.new_map(128, 128)
	elif _map_root.map_data == null:
		_map_root.load_map()
	_dock.set_map_data(_map_root.map_data)

func _find_map_root(node: Node) -> MapRoot:
	if node is MapRoot:
		return node
	for c in node.get_children():
		var r := _find_map_root(c)
		if r:
			return r
	return null

# ─── Scene change ────────────────────────────────────────────────
func _handles(object: Object) -> bool:
	return object is MapRoot or object is Node3D

func _make_visible(visible: bool) -> void:
	if _dock:
		_dock.visible = visible

# ─── 3D Viewport Input ──────────────────────────────────────────
func _forward_3d_gui_input(camera: Camera3D, event: InputEvent) -> int:
	if _map_root == null or _map_root.map_data == null:
		_find_or_create_map_root()
		if _map_root == null:
			return EditorPlugin.AFTER_GUI_INPUT_PASS

	# Mouse button
	if event is InputEventMouseButton:
		var mb: InputEventMouseButton = event
		if mb.button_index == MOUSE_BUTTON_LEFT:
			if mb.pressed:
				var cell := _raycast_to_grid(camera, mb.position)
				if cell.x < 0:
					return EditorPlugin.AFTER_GUI_INPUT_PASS
				if _dock.current_tool == MapConstants.ToolMode.RECTANGLE:
					_drag_active = true
					_drag_start = cell
					_drag_current = cell
					return EditorPlugin.AFTER_GUI_INPUT_STOP
				else:
					_apply_tool(cell)
					return EditorPlugin.AFTER_GUI_INPUT_STOP
			else:
				# Mouse released
				if _drag_active:
					_drag_active = false
					_apply_rect(_drag_start, _drag_current)
					return EditorPlugin.AFTER_GUI_INPUT_STOP

	# Mouse motion (for drag preview / continuous paint)
	if event is InputEventMouseMotion:
		var mm: InputEventMouseMotion = event
		var cell := _raycast_to_grid(camera, mm.position)
		if cell.x >= 0:
			_update_preview(cell)
			if _drag_active:
				_drag_current = cell
			elif Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT):
				# Continuous painting
				if _dock.current_tool == MapConstants.ToolMode.PAINT:
					_apply_tool(cell)
					return EditorPlugin.AFTER_GUI_INPUT_STOP

	return EditorPlugin.AFTER_GUI_INPUT_PASS

# ─── Raycast from screen point to grid cell ──────────────────────
func _raycast_to_grid(camera: Camera3D, screen_pos: Vector2) -> Vector2i:
	var from := camera.project_ray_origin(screen_pos)
	var dir := camera.project_ray_normal(screen_pos)

	# Use physics raycast via space state
	var space := camera.get_world_3d().direct_space_state
	var query := PhysicsRayQueryParameters3D.create(from, from + dir * 500.0)
	query.collide_with_areas = false
	query.collide_with_bodies = true
	var result := space.intersect_ray(query)

	var hit_pos: Vector3
	if result.is_empty():
		# Fallback: intersect Y=0 plane
		if abs(dir.y) < 0.001:
			return Vector2i(-1, -1)
		var t := -from.y / dir.y
		if t < 0:
			return Vector2i(-1, -1)
		hit_pos = from + dir * t
	else:
		hit_pos = result["position"]

	var gx := floori(hit_pos.x / MapConstants.CELL_SIZE)
	var gz := floori(hit_pos.z / MapConstants.CELL_SIZE)
	if not _map_root.map_data.in_bounds(gx, gz):
		_dock.show_status("Outside map bounds")
		return Vector2i(-1, -1)
	return Vector2i(gx, gz)

# ─── Tool dispatch ───────────────────────────────────────────────
func _apply_tool(cell: Vector2i) -> void:
	var tool_mode: int = _dock.current_tool
	match tool_mode:
		MapConstants.ToolMode.PAINT:
			_paint_brush(cell)
		MapConstants.ToolMode.FILL:
			_flood_fill(cell)
		MapConstants.ToolMode.HEIGHT_UP:
			_height_change(cell, 1)
		MapConstants.ToolMode.HEIGHT_DOWN:
			_height_change(cell, -1)
		MapConstants.ToolMode.TRANSITION:
			_set_transition(cell)
		MapConstants.ToolMode.OBJECT_PLACE:
			_place_object(cell)
		MapConstants.ToolMode.OBJECT_ERASE:
			_erase_object(cell)
		MapConstants.ToolMode.BUILDING_PLACE:
			_place_building(cell)
		MapConstants.ToolMode.BUILDING_ERASE:
			_erase_building(cell)
		MapConstants.ToolMode.RECTANGLE:
			pass  # Handled on release

# ─── Paint Brush ─────────────────────────────────────────────────
func _paint_brush(center: Vector2i) -> void:
	var md := _map_root.map_data
	var tile := _dock.current_tile
	var sz := _dock.current_brush_size
	var half := sz / 2
	var cells_changed: Array[Dictionary] = []

	for dz in sz:
		for dx in sz:
			var gx := center.x - half + dx
			var gz := center.y - half + dz
			var c := md.cell(gx, gz)
			if c == null:
				continue
			if c.tile_type == tile:
				continue
			cells_changed.append({"gx": gx, "gz": gz, "old_type": c.tile_type, "new_type": tile})

	if cells_changed.is_empty():
		return

	_undo.create_action("Paint Tiles")
	for ch in cells_changed:
		_undo.add_do_method(self, "_do_set_tile", ch["gx"], ch["gz"], ch["new_type"])
		_undo.add_undo_method(self, "_do_set_tile", ch["gx"], ch["gz"], ch["old_type"])
	_undo.add_do_method(self, "_rebuild_region", center.x, center.y, sz)
	_undo.add_undo_method(self, "_rebuild_region", center.x, center.y, sz)
	_undo.commit_action()
	_dock.show_status("Painted %d cells" % cells_changed.size())

# ─── Rectangle ───────────────────────────────────────────────────
func _apply_rect(start: Vector2i, end: Vector2i) -> void:
	var md := _map_root.map_data
	var tile := _dock.current_tile
	var x0 := mini(start.x, end.x)
	var x1 := maxi(start.x, end.x)
	var z0 := mini(start.y, end.y)
	var z1 := maxi(start.y, end.y)
	var changes: Array[Dictionary] = []
	for gz in range(z0, z1 + 1):
		for gx in range(x0, x1 + 1):
			var c := md.cell(gx, gz)
			if c == null or c.tile_type == tile:
				continue
			changes.append({"gx": gx, "gz": gz, "old": c.tile_type, "new": tile})

	if changes.is_empty():
		return

	_undo.create_action("Rectangle Paint")
	for ch in changes:
		_undo.add_do_method(self, "_do_set_tile", ch["gx"], ch["gz"], ch["new"])
		_undo.add_undo_method(self, "_do_set_tile", ch["gx"], ch["gz"], ch["old"])
	var cx := (x0 + x1) / 2
	var cz := (z0 + z1) / 2
	var radius := maxi(x1 - x0, z1 - z0) + 2
	_undo.add_do_method(self, "_rebuild_region", cx, cz, radius)
	_undo.add_undo_method(self, "_rebuild_region", cx, cz, radius)
	_undo.commit_action()
	_dock.show_status("Rect: %d cells" % changes.size())

# ─── Flood Fill ──────────────────────────────────────────────────
func _flood_fill(start: Vector2i) -> void:
	var md := _map_root.map_data
	var sc := md.cell(start.x, start.y)
	if sc == null:
		return
	var source_type := sc.tile_type
	var target_type := _dock.current_tile
	if source_type == target_type:
		return

	var visited: Dictionary = {}
	var stack: Array[Vector2i] = [start]
	var changes: Array[Dictionary] = []
	var limit := 10000  # Safety limit

	while stack.size() > 0 and changes.size() < limit:
		var p := stack.pop_back()
		if visited.has(p):
			continue
		visited[p] = true
		var c := md.cell(p.x, p.y)
		if c == null or c.tile_type != source_type:
			continue
		changes.append({"gx": p.x, "gz": p.y, "old": source_type, "new": target_type})
		stack.append(Vector2i(p.x + 1, p.y))
		stack.append(Vector2i(p.x - 1, p.y))
		stack.append(Vector2i(p.x, p.y + 1))
		stack.append(Vector2i(p.x, p.y - 1))

	if changes.is_empty():
		return

	_undo.create_action("Flood Fill")
	for ch in changes:
		_undo.add_do_method(self, "_do_set_tile", ch["gx"], ch["gz"], ch["new"])
		_undo.add_undo_method(self, "_do_set_tile", ch["gx"], ch["gz"], ch["old"])
	_undo.add_do_method(_map_root, "full_rebuild")
	_undo.add_undo_method(_map_root, "full_rebuild")
	_undo.commit_action()
	_dock.show_status("Filled %d cells" % changes.size())

# ─── Height +/- ──────────────────────────────────────────────────
func _height_change(center: Vector2i, delta: int) -> void:
	var md := _map_root.map_data
	var sz := _dock.current_brush_size
	var half := sz / 2
	var changes: Array[Dictionary] = []

	for dz in sz:
		for dx in sz:
			var gx := center.x - half + dx
			var gz := center.y - half + dz
			var c := md.cell(gx, gz)
			if c == null:
				continue
			var old_h := c.height
			var new_h := maxi(0, old_h + delta)
			if new_h == old_h:
				continue
			changes.append({"gx": gx, "gz": gz, "old_h": old_h, "new_h": new_h})

	if changes.is_empty():
		return

	_undo.create_action("Height Change")
	for ch in changes:
		_undo.add_do_method(self, "_do_set_height", ch["gx"], ch["gz"], ch["new_h"])
		_undo.add_undo_method(self, "_do_set_height", ch["gx"], ch["gz"], ch["old_h"])
	_undo.add_do_method(self, "_rebuild_region", center.x, center.y, sz + 2)
	_undo.add_undo_method(self, "_rebuild_region", center.x, center.y, sz + 2)
	_undo.commit_action()
	_dock.show_status("Height changed: %d cells" % changes.size())

# ─── Transition ──────────────────────────────────────────────────
func _set_transition(cell: Vector2i) -> void:
	var md := _map_root.map_data
	var c := md.cell(cell.x, cell.y)
	if c == null:
		return
	var old_tr := c.transition
	var new_tr := _dock.current_transition
	if old_tr == new_tr:
		return

	_undo.create_action("Set Transition")
	_undo.add_do_method(self, "_do_set_transition", cell.x, cell.y, new_tr)
	_undo.add_undo_method(self, "_do_set_transition", cell.x, cell.y, old_tr)
	_undo.add_do_method(self, "_rebuild_region", cell.x, cell.y, 3)
	_undo.add_undo_method(self, "_rebuild_region", cell.x, cell.y, 3)
	_undo.commit_action()

# ─── Objects ─────────────────────────────────────────────────────
func _place_object(cell: Vector2i) -> void:
	var md := _map_root.map_data
	if not md.in_bounds(cell.x, cell.y):
		return
	var otype := _dock.current_object_type
	var id := md.add_object(otype, cell.x, cell.y)
	var obj_data := md.objects.back()

	_undo.create_action("Place Object")
	_undo.add_do_method(self, "_do_add_object", obj_data.duplicate(true))
	_undo.add_undo_method(self, "_do_remove_object", id)
	_undo.commit_action(false)  # Already applied
	_map_root.object_manager.spawn_object_from_data(obj_data)
	_dock.show_status("Placed %s" % MapConstants.OBJECT_NAMES.get(otype, "?"))

func _erase_object(cell: Vector2i) -> void:
	var md := _map_root.map_data
	var objs := md.objects_at(cell.x, cell.y)
	if objs.is_empty():
		_dock.show_status("No object here")
		return
	var o: Dictionary = objs.back()
	_undo.create_action("Remove Object")
	_undo.add_do_method(self, "_do_remove_object", o["id"])
	_undo.add_undo_method(self, "_do_add_object", o.duplicate(true))
	_undo.commit_action()
	_dock.show_status("Removed object")

# ─── Buildings ───────────────────────────────────────────────────
func _place_building(cell: Vector2i) -> void:
	var md := _map_root.map_data
	var bt := _dock.current_building_type
	var tmpl: Dictionary = MapBuilding.TEMPLATES.get(bt, MapBuilding.TEMPLATES[0])
	var fw: int = tmpl["fw"]
	var fh: int = tmpl["fh"]

	if not md.can_place_building(cell.x, cell.y, fw, fh):
		_dock.show_status("❌ Cannot place: overlap, water, height mismatch, or out of bounds")
		return

	var uid := md.place_building(bt, cell.x, cell.y, fw, fh)
	if uid < 0:
		_dock.show_status("❌ Placement failed")
		return
	var bld_data := md.buildings.back()

	_undo.create_action("Place Building")
	_undo.add_do_method(self, "_do_place_building", bld_data.duplicate(true))
	_undo.add_undo_method(self, "_do_remove_building", uid)
	_undo.commit_action(false)
	_map_root.object_manager.spawn_building_from_data(bld_data)
	_dock.show_status("Placed %s" % tmpl.get("name", "Building"))

func _erase_building(cell: Vector2i) -> void:
	var md := _map_root.map_data
	var b := md.building_at(cell.x, cell.y)
	if b.is_empty():
		_dock.show_status("No building here")
		return
	var uid: int = b["uid"]
	_undo.create_action("Remove Building")
	_undo.add_do_method(self, "_do_remove_building", uid)
	_undo.add_undo_method(self, "_do_place_building", b.duplicate(true))
	_undo.commit_action()
	_dock.show_status("Removed building")

# ─── Undo/Redo atomic operations ────────────────────────────────
func _do_set_tile(gx: int, gz: int, tile_type: int) -> void:
	if _map_root and _map_root.map_data:
		var c := _map_root.map_data.cell(gx, gz)
		if c:
			c.tile_type = tile_type

func _do_set_height(gx: int, gz: int, h: int) -> void:
	if _map_root and _map_root.map_data:
		var c := _map_root.map_data.cell(gx, gz)
		if c:
			c.height = h

func _do_set_transition(gx: int, gz: int, tr: int) -> void:
	if _map_root and _map_root.map_data:
		var c := _map_root.map_data.cell(gx, gz)
		if c:
			c.transition = tr

func _do_add_object(data: Dictionary) -> void:
	if _map_root and _map_root.map_data:
		# Re‐insert into data
		var exists := false
		for o in _map_root.map_data.objects:
			if o["id"] == data["id"]:
				exists = true
				break
		if not exists:
			_map_root.map_data.objects.append(data)
		_map_root.object_manager.spawn_object_from_data(data)

func _do_remove_object(id: int) -> void:
	if _map_root and _map_root.map_data:
		_map_root.map_data.remove_object(id)
		_map_root.object_manager.remove_object_node(id)

func _do_place_building(data: Dictionary) -> void:
	if _map_root and _map_root.map_data:
		var md := _map_root.map_data
		# Re‐insert
		var exists := false
		for b in md.buildings:
			if b["uid"] == data["uid"]:
				exists = true
				break
		if not exists:
			md.buildings.append(data)
			for dz in data["fh"]:
				for dx in data["fw"]:
					var c := md.cell(data["gx"] + dx, data["gz"] + dz)
					if c:
						c.occupied_by_building = data["uid"]
		_map_root.object_manager.spawn_building_from_data(data)

func _do_remove_building(uid: int) -> void:
	if _map_root and _map_root.map_data:
		_map_root.map_data.remove_building(uid)
		_map_root.object_manager.remove_building_node(uid)

func _rebuild_region(cx: int, cz: int, radius: int) -> void:
	if _map_root:
		_map_root.rebuild_around(cx, cz, radius)

# ─── Preview highlight ───────────────────────────────────────────
func _update_preview(cell: Vector2i) -> void:
	if _preview_node == null or not is_instance_valid(_preview_node):
		_preview_node = MeshInstance3D.new()
		var bm := BoxMesh.new()
		bm.size = Vector3(MapConstants.CELL_SIZE, 0.05, MapConstants.CELL_SIZE)
		_preview_node.mesh = bm
		var mat := StandardMaterial3D.new()
		mat.albedo_color = Color(1, 1, 0, 0.35)
		mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
		mat.cull_mode = BaseMaterial3D.CULL_DISABLED
		_preview_node.material_override = mat
		if _map_root:
			_map_root.add_child(_preview_node)

	var y: float = 0.0
	if _map_root and _map_root.map_data:
		var c := _map_root.map_data.cell(cell.x, cell.y)
		if c:
			y = c.height * MapConstants.LEVEL_HEIGHT
	_preview_node.position = Vector3(
		cell.x * MapConstants.CELL_SIZE + MapConstants.CELL_SIZE * 0.5,
		y + 0.05,
		cell.y * MapConstants.CELL_SIZE + MapConstants.CELL_SIZE * 0.5
	)

	# Resize for brush
	var sz: float = _dock.current_brush_size * MapConstants.CELL_SIZE
	_preview_node.mesh.size = Vector3(sz, 0.05, sz)

# ─── Save / Load / New ──────────────────────────────────────────
func _on_save() -> void:
	if _map_root:
		_map_root.save_map()
		_dock.show_status("✅ Map saved to " + _map_root.map_file_path)

func _on_load() -> void:
	if _map_root:
		_map_root.load_map()
		_dock.set_map_data(_map_root.map_data)
		_dock.show_status("✅ Map loaded from " + _map_root.map_file_path)

func _on_new_map() -> void:
	if _map_root:
		_map_root.new_map(128, 128)
		_dock.set_map_data(_map_root.map_data)
		_dock.show_status("✅ New 128×128 map created")

func _on_tile_style_changed(_tile_type: int, _style: Dictionary) -> void:
	# Rebuild all chunks to reflect new style
	if _map_root:
		_map_root.full_rebuild()
		_dock.show_status("Style updated — rebuilding terrain…")
