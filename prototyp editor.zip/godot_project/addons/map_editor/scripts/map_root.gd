## map_root.gd — Root node added to the scene that holds terrain + objects.
## Used both in editor and at runtime.
@tool
class_name MapRoot
extends Node3D

@export var map_file_path: String = "res://map_data.json"

var map_data: MapData
var chunk_manager: ChunkManager
var object_manager: ObjectManager

func _ready() -> void:
	if map_data == null:
		load_map()

func load_map() -> void:
	if FileAccess.file_exists(map_file_path):
		map_data = MapData.load_from_file(map_file_path)
	if map_data == null:
		map_data = MapData.new(128, 128)
	_setup_children()

func save_map() -> void:
	if map_data:
		map_data.save_to_file(map_file_path)

func new_map(w: int = 128, h: int = 128) -> void:
	map_data = MapData.new(w, h)
	_setup_children()

func _setup_children() -> void:
	# Remove old managers
	for c in get_children():
		c.queue_free()

	chunk_manager = ChunkManager.new()
	chunk_manager.name = "ChunkManager"
	add_child(chunk_manager)
	chunk_manager.initialize(map_data)

	object_manager = ObjectManager.new()
	object_manager.name = "ObjectManager"
	add_child(object_manager)
	object_manager.initialize(map_data)

func rebuild_around(gx: int, gz: int, radius: int = 1) -> void:
	if chunk_manager == null:
		return
	for dz in range(-radius, radius + 1):
		for dx in range(-radius, radius + 1):
			chunk_manager.mark_dirty(gx + dx, gz + dz)
	chunk_manager.flush_dirty()

func full_rebuild() -> void:
	if chunk_manager:
		chunk_manager.initialize(map_data)
	if object_manager:
		object_manager.rebuild_all()

# ─── Runtime navigation helper ───────────────────────────────────
## Call this at runtime to bake a NavigationRegion3D from terrain.
func bake_navigation(nav_region: NavigationRegion3D, slope_limit_deg: float = 45.0) -> void:
	if nav_region == null or map_data == null:
		return
	var nav_mesh := NavigationMesh.new()
	nav_mesh.agent_radius = 0.4
	nav_mesh.agent_height = 1.8
	nav_mesh.agent_max_slope = slope_limit_deg
	nav_mesh.cell_size = 0.25
	nav_mesh.cell_height = 0.1
	# Feed all chunk meshes as source geometry
	nav_region.navigation_mesh = nav_mesh
	nav_region.bake_navigation_mesh()
