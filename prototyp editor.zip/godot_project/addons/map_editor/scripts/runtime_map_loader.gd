## runtime_map_loader.gd — Attach this to a Node3D in your game scene.
## It loads the map JSON, builds terrain chunks + objects, and optionally
## bakes navigation.
extends Node3D

@export var map_file: String = "res://map_data.json"
@export var bake_navigation: bool = true
@export var nav_slope_limit: float = 45.0

var map_root: MapRoot

func _ready() -> void:
	map_root = MapRoot.new()
	map_root.map_file_path = map_file
	add_child(map_root)
	map_root.load_map()

	if bake_navigation:
		var nav_region := NavigationRegion3D.new()
		nav_region.name = "NavRegion"
		add_child(nav_region)
		# Wait one frame for meshes to be ready
		await get_tree().process_frame
		map_root.bake_navigation(nav_region, nav_slope_limit)
		print("Navigation baked.")

	print("Map loaded: %dx%d cells" % [map_root.map_data.width, map_root.map_data.height])
