# 🗺️ Map Editor pro Godot 4.6 — Kompletní dokumentace

---

## 📋 PŘEDPOKLADY (co jsem rozhodl za tebe)

1. **Varianta B (voxel data + procedurální mesh)** — zvolena jako hlavní cesta.
   - Důvod: Nepotřebuješ stovky ručně modelovaných 3D dílů. Mesh se generuje z dat automaticky. Sousední dlaždice stejného typu sdílejí hrany = **žádné spáry, jednolitý povrch**.
   - GridMap (varianta A) by vyžadovala desítky unikátních MeshLibrary dílů (rohy, hrany, T-kusy, přechody). Pro první verzi je to zbytečně pracné.

2. **Godot 4.6**, GDScript, 3D.

3. **Cell size = 2.0**, Level height = 1.0 (snadno změníš v `map_constants.gd`).

4. **Mapa 128×128** jako default (až 256×256), chunkovaná po 16×16 buňkách.

5. **JSON** jako formát ukládání (čitelný, debugovatelný, snadno parsovatelný i za runtime).

6. **Bez externích assetů** — vše se generuje procedurálně s barvami. Textury můžeš přidat kdykoliv přes Style editor.

---

## 1. MINI SPECIFIKACE EDITORU

### 1.1 Nástroje v UI

| Nástroj | Jak se používá |
|---------|---------------|
| 🖌️ Paint | Vyber dlaždici v paletě, klikni nebo táhni v 3D viewportu |
| ▮ Rectangle | Klikni, drž a táhni obdélník, uvolni |
| 🪣 Fill | Klikni na buňku — vyplní všechny spojené buňky stejného typu |
| ⬆ Height+ | Klikni — zvýší výšku o 1 level |
| ⬇ Height- | Klikni — sníží výšku o 1 level |
| 🔀 Transition | Vyber typ přechodu (rampa/schody/směr) a klikni na buňku |
| 📌 Place Obj | Vyber objekt (strom, kámen…) a klikni do mapy |
| 🗑️ Del Obj | Klikni na buňku — smaže objekt na ní |
| 📌 Place Bld | Vyber budovu, klikni — položí s kontrolou footprintu |
| 🗑️ Del Bld | Klikni na budovu — odstraní ji |

**Brush size**: 1×1, 2×2, 3×3, 5×5 — tlačítka v panelu.

### 1.2 Vrstvy dat

| Vrstva | Co obsahuje |
|--------|-------------|
| **Tiles** | Typ dlaždice (grass/dirt/stone/water/path) per buňka |
| **Heights** | Celočíselná výška (level) per buňka |
| **Transitions** | Typ přechodu (rampa, schody, směr) per buňka |
| **Objects** | Seznam objektů (strom, kámen, keř, dekorace) s pozicí a properties |
| **Buildings** | Seznam budov s footprintem, obsazené buňky |
| **Tile Styles** | Barva, roughness, textura, normal mapa, noise per typ dlaždice |

### 1.3 Přechody mezi výškami

- **Rampy**: Buňka s transition RAMP_NORTH/SOUTH/EAST/WEST. Dva rohy jsou na spodní úrovni, dva na horní. Vytváří plynulý svah.
- **Schody**: Podobné, ale s mírným schodovitým profilem (3 substepy).
- **Chůze**: Runtime NavigationMesh s nastavitelným slope limitem (default 45°).

### 1.4 Slévání dlaždic (KLÍČOVÉ)

**Jak to funguje technicky:**

```
Princip: Sousední buňky stejného typu a stejné výšky SDÍLEJÍ hraniční
vrcholy v jednom spojeném meshi. Neexistuje mezera ani duplikovaný
vertex na hranici → žádná viditelná spára.
```

**Cesta 1 (implementovaná — procedurální mesh per chunk):**
- Každý chunk (16×16 buněk) generuje JEDEN `ArrayMesh`.
- Buňky stejného typu jsou jedna surface (jeden materiál).
- Na hranici dvou sousedních stejných buněk se negeneruje stěna (wall skip).
- Vertex noise dodává organický, ne-mřížkový vzhled.
- Vertex color variace rozbíjí uniformitu.

**Cesta 2 (robustní pro budoucnost — Marching Cubes / Dual Contouring):**
- Převedeš grid na volumetrická data (density field).
- Marching Cubes vygeneruje hladký mesh bez jakýchkoliv hran.
- Ideální pro jeskyně, převisy, eroze.
- Implementačně složitější, ale vizuálně nejlepší.

**Typické chyby způsobující viditelné spáry a jak je opravit:**

| Problém | Příčina | Řešení |
|---------|---------|--------|
| Tenká čára mezi buňkami | Floating-point gap | Sdílet PŘESNĚ stejné souřadnice na hranici |
| Šev na chunk hranici | Chunk A vertex ≠ Chunk B vertex | mark_dirty() označí i sousední chunk |
| Z-fighting | Dvě plochy ve stejné rovině | Negenerovat stěnu mezi stejnými typy |
| Viditelná mřížka | Příliš uniformní barva | Vertex noise + color variation |

---

## 2. DATOVÝ MODEL

### 2.1 Struktura jedné buňky (`CellData`)

```
tile_type:  int (EMPTY=0, GRASS=1, DIRT=2, STONE=3, WATER=4, PATH=5)
height:     int (0, 1, 2, …)
transition: int (NONE=0, RAMP_N/S/E/W, STAIRS_N/S/E/W)
occupied_by_building: int (-1 = volná, jinak UID budovy)
metadata:   Dictionary (budoucí rozšíření)
```

### 2.2 Objekty

```
{
  id:       int (unikátní),
  type:     int (TREE=0, ROCK=1, BUSH=2, DECORATION=3),
  gx, gz:   int (grid souřadnice),
  rotation: float (radiány),
  scale:    [x, y, z],
  props:    Dictionary (budoucí: health, growth_stage, …)
}
```

### 2.3 Budovy

```
{
  uid:      int (unikátní),
  type_id:  int (viz TEMPLATES: 0=Small House 1×1, 1=Medium 2×2, …),
  gx, gz:   int (levý horní roh),
  fw, fh:   int (footprint šířka × hloubka v buňkách),
  rotation: float,
  props:    Dictionary (budoucí: level, owner, production, …)
}
```

### 2.4 Tile Styles (per typ dlaždice)

```
{
  color:          Color (albedo tint),
  roughness:      float (0.0 – 1.0),
  texture_path:   String (cesta k albedo textuře, "" = žádná),
  normal_path:    String (cesta k normal mapě),
  noise_strength: float (amplituda vertex šumu — výchozí 0.15),
  noise_scale:    float (frekvence šumu — výchozí 4.0)
}
```

Upravíš přímo v editoru:
- **Color picker** — změní barvu dlaždice
- **Roughness slider** — lesklost/matnost
- **Noise slider** — jak moc "zvlněný" povrch
- **Texture/Normal** — zadej cestu k textuře (`res://textures/grass.png`)

---

## 3. RUNTIME POUŽITÍ

### 3.1 Postavení scény ve hře

```gdscript
# V herní scéně přidej Node3D se skriptem runtime_map_loader.gd
# Nastaví map_file = "res://map_data.json"
# Automaticky: načte JSON → vytvoří MapRoot → postaví chunky + objekty
```

### 3.2 Navigace

```gdscript
# runtime_map_loader.gd automaticky bake-ne NavigationRegion3D
# Parametry: slope_limit (default 45°), agent_radius (0.4), agent_height (1.8)
# Rampy s úhlem < 45° jsou walkable, strmé stěny ne.
```

---

## 4. INSTALACE

### 4.1 Struktura složek

```
res://addons/map_editor/
├── plugin.cfg
├── scripts/
│   ├── map_editor_plugin.gd    ← hlavní EditorPlugin
│   ├── map_constants.gd        ← konstanty a enumy
│   ├── cell_data.gd            ← data jedné buňky
│   ├── map_data.gd             ← celá mapa + save/load
│   ├── mesh_generator.gd       ← seamless mesh generátor
│   ├── chunk_manager.gd        ← správa chunk Node3D
│   ├── object_manager.gd       ← spawn/remove objektů a budov
│   ├── map_root.gd             ← kořenový uzel mapy
│   ├── map_object.gd           ← placeholder objekt (strom, kámen…)
│   ├── map_building.gd         ← placeholder budova
│   ├── editor_dock.gd          ← UI panel editoru
│   └── runtime_map_loader.gd   ← runtime loader pro hru
└── resources/                   ← (volitelné textury, materiály)
```

### 4.2 Zapnutí pluginu

1. Zkopíruj celou složku `addons/map_editor/` do svého Godot projektu.
2. Otevři **Project → Project Settings → Plugins**.
3. Najdi "MapEditor" a zaškrtni **Enable**.
4. Vpravo nahoře se objeví panel **MapEditor**.

### 4.3 První použití

1. Vytvoř novou 3D scénu (Node3D jako root).
2. **Ulož scénu** (důležité! Plugin potřebuje `edited_scene_root`).
3. Panel MapEditor se objeví vpravo. Pokud ne, klikni kamkoliv do 3D viewportu.
4. Plugin automaticky přidá `MapRoot` uzel do tvé scény.
5. Vyber "Grass" v paletě → klikni do viewportu → hotovo!

---

## 5. QUICK START — Tráva + rampa za 10 minut

```
Krok 1: Nový projekt v Godot 4.6, vytvoř 3D scénu, ulož.
Krok 2: Zkopíruj addons/map_editor/ do projektu.
Krok 3: Project Settings → Plugins → Enable "MapEditor".
Krok 4: V pravém panelu klikni "Grass".
Krok 5: Vyber Brush 5×5.
Krok 6: Klikni/táhni v 3D viewportu → zelená plocha.
Krok 7: Vyber tool "Height+" a Brush 3×3.
Krok 8: Klikni na střed plochy → zvýší se o 1 level.
Krok 9: Vyber "Transition" → "Ramp ↑" (north).
Krok 10: Klikni na buňku na okraji zvýšené oblasti → rampa!
Krok 11: Klikni "Save" → mapa uložena do res://map_data.json.
```

**Úprava vzhledu:**
```
Krok 12: Vyber "Grass" v paletě.
Krok 13: V sekci "Tile Styles" změň barvu přes Color Picker.
Krok 14: Posuň Noise slider pro zvlněnější terén.
Krok 15: Zadej cestu k textuře do pole "Texture:" (volitelné).
```

---

## 6. CHECKLIST — na co se zapomíná

| # | Věc | Stav |
|---|-----|------|
| 1 | Editor input: `_forward_3d_gui_input()` vrací `AFTER_GUI_INPUT_STOP` aby konzumoval klik | ✅ |
| 2 | Raycast: physics space state + fallback na Y=0 plane intersect | ✅ |
| 3 | Jednotky: CELL_SIZE=2.0, LEVEL_HEIGHT=1.0, osa Y nahoru | ✅ |
| 4 | Výkon: chunky 16×16, dirty-flag rebuild, ne celá mapa | ✅ |
| 5 | Chunk boundary: mark_dirty() označí i sousední chunk | ✅ |
| 6 | Undo/Redo: EditorUndoRedoManager, atomické operace | ✅ |
| 7 | Spáry: sdílené vertex souřadnice, skip wall pro same-type | ✅ |
| 8 | Vertex noise: rozbíjí mřížkový vzhled | ✅ |
| 9 | @tool na všech skriptech (nutné pro editor plugin) | ✅ |
| 10 | class_name na datových třídách (MapData, CellData…) | ✅ |
| 11 | Collision shapes pro raycast (ConcavePolygonShape3D per chunk) | ✅ |
| 12 | Building overlap check (výška, water, bounds) | ✅ |
| 13 | Flood fill safety limit (10 000 buněk) | ✅ |
| 14 | JSON save: Color serialized as [r,g,b,a] array | ✅ |

---

## 7. ARCHITEKTURA — jak to drží pohromadě

```
┌─────────────────────────────────────────┐
│           map_editor_plugin.gd          │ ← EditorPlugin
│  (viewport input, undo/redo, dispatch)  │
└──────────┬──────────────┬───────────────┘
           │              │
     ┌─────▼─────┐  ┌────▼──────────┐
     │ editor_   │  │   MapRoot     │ ← Scene node
     │ dock.gd   │  │ (map_root.gd) │
     │ (UI panel)│  └──┬────────┬───┘
     └───────────┘     │        │
              ┌────────▼──┐ ┌───▼──────────┐
              │  Chunk    │ │   Object     │
              │  Manager  │ │   Manager    │
              │ (chunks)  │ │ (objs+blds)  │
              └─────┬─────┘ └──────────────┘
                    │
              ┌─────▼─────┐
              │   Mesh    │
              │ Generator │ ← Seamless mesh building
              └───────────┘
                    ↑
              ┌─────┴─────┐
              │  MapData   │ ← Pure data (grid + objects + buildings + styles)
              │  CellData  │
              └────────────┘
```

---

## 8. ROZŠÍŘENÍ DO BUDOUCNA

1. **Textury**: Přidej `.png` do `res://textures/`, zadej cestu v Style editoru.
2. **Nové tile typy**: Přidej enum hodnotu do `MapConstants.TileType`, barvu do `TILE_COLORS`, název do `TILE_NAMES`.
3. **Nové budovy**: Přidej záznam do `MapBuilding.TEMPLATES`.
4. **Nové objekty**: Přidej enum do `ObjectType`, implementuj vizuál v `map_object.gd`.
5. **Marching Cubes**: Nahraď `mesh_generator.gd` za MC implementaci. Data model zůstane stejný.
6. **Shader-based blending**: Přidej shader, co blenduje textury podle vertex color/attribute pro ještě plynulejší přechody mezi typy.
7. **LOD**: Pro velké mapy — vzdálené chunky nahraď simplified mesh.
8. **Multithreading**: `build_chunk()` je pure function → snadno paralelizovatelný přes WorkerThreadPool.
