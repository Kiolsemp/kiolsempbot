## editor_camera.gd — Simple orbit/pan camera for navigating the map in editor.
## Attach to the Camera3D node. Works in editor (@tool) and at runtime.
@tool
extends Camera3D

@export var orbit_speed: float = 0.005
@export var pan_speed: float = 0.5
@export var zoom_speed: float = 2.0
@export var min_zoom: float = 5.0
@export var max_zoom: float = 200.0

var _target: Vector3 = Vector3(64, 0, 64)  # Center of 64x64 map (cell_size=2)
var _distance: float = 60.0
var _yaw: float = 0.0
var _pitch: float = -0.8  # Looking down at ~45°
var _dragging_orbit: bool = false
var _dragging_pan: bool = false

func _ready() -> void:
	_update_transform()

func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventMouseButton:
		var mb: InputEventMouseButton = event
		# Middle mouse = orbit
		if mb.button_index == MOUSE_BUTTON_MIDDLE:
			_dragging_orbit = mb.pressed
		# Right mouse = pan
		if mb.button_index == MOUSE_BUTTON_RIGHT:
			_dragging_pan = mb.pressed
		# Scroll = zoom
		if mb.button_index == MOUSE_BUTTON_WHEEL_UP:
			_distance = max(min_zoom, _distance - zoom_speed * (_distance * 0.1))
			_update_transform()
		if mb.button_index == MOUSE_BUTTON_WHEEL_DOWN:
			_distance = min(max_zoom, _distance + zoom_speed * (_distance * 0.1))
			_update_transform()

	if event is InputEventMouseMotion:
		var mm: InputEventMouseMotion = event
		if _dragging_orbit:
			_yaw -= mm.relative.x * orbit_speed
			_pitch -= mm.relative.y * orbit_speed
			_pitch = clamp(_pitch, -1.4, -0.1)
			_update_transform()
		elif _dragging_pan:
			var right := global_transform.basis.x
			var forward := Vector3(global_transform.basis.z.x, 0, global_transform.basis.z.z).normalized()
			_target -= right * mm.relative.x * pan_speed * (_distance * 0.002)
			_target += forward * mm.relative.y * pan_speed * (_distance * 0.002)
			_update_transform()

func _update_transform() -> void:
	var offset := Vector3.ZERO
	offset.x = cos(_pitch) * sin(_yaw) * _distance
	offset.y = -sin(_pitch) * _distance
	offset.z = cos(_pitch) * cos(_yaw) * _distance
	global_position = _target + offset
	look_at(_target, Vector3.UP)
