## Main Game Controller v7
## 1 hero worker around center, no initial buildings, fog of war, Town Hall
extends Node3D

var rts_camera: Node3D
var map_gen: Node3D
var hud: CanvasLayer
var build_ghost: Node3D
var world_env: WorldEnvironment
var sun: DirectionalLight3D

var hero_worker: Node3D = null
var player_workers: Array = []
var player_soldiers: Array = []
var active_vampires: Array = []

# Box selection
var is_box_selecting: bool = false
var box_rect: ColorRect
var click_ring: Node3D
var attack_ring: Node3D
var attack_target_tracked: Node3D = null  # Persistent attack marker target

# Left-click drag tracking
var left_dragging: bool = false
var left_drag_start: Vector2 = Vector2.ZERO
var left_drag_prev: Vector2 = Vector2.ZERO
var left_drag_total: float = 0.0
var did_select_entity: bool = false
var ctrl_held_on_press: bool = false

# Wave / respawn
var vampire_respawn_timer: float = 0.0
var vampire_respawn_delay: float = 15.0
var vampires_to_spawn: int = 0
var spawn_timer: float = 0.0

# Spectating mode (after player death)
var is_spectating: bool = false

# Fog of War
var fog_entities: Array = []  # Entities that can be hidden by fog
var fog_update_timer: float = 0.0

func _ready():
	_setup_environment()
	_setup_camera()
	_setup_map()
	_setup_hud()
	_setup_build_ghost()
	_setup_box_select()
	_setup_click_indicator()
	BuildingManager.build_mode_changed.connect(_on_build_mode_changed)
	GameState.game_over.connect(_on_game_over)
	GameState.wave_started.connect(_on_wave_started)
	GameClock.night_started.connect(_on_night_started)
	GameClock.day_started.connect(_on_day_started)
	call_deferred("_deferred_start")

func _deferred_start():
	await get_tree().process_frame
	await get_tree().process_frame
	# Don't auto-start - lobby will call start_singleplayer or start_multiplayer_game
	pass

func start_singleplayer():
	_start_game()

func start_multiplayer_game():
	# Called when NetworkManager.game_started fires
	seed(NetworkManager.game_seed)
	GameState.nights_to_survive = NetworkManager.nights_to_survive
	var role = NetworkManager.get_local_role()
	if role == NetworkManager.Role.VAMPIRE:
		_start_as_vampire()
	else:
		_start_as_human(NetworkManager.get_local_slot())

func _setup_environment():
	world_env = WorldEnvironment.new()
	var env = Environment.new()
	env.background_mode = Environment.BG_SKY
	var sky = Sky.new()
	var sky_mat = ProceduralSkyMaterial.new()
	sky_mat.sky_top_color = Color(0.25, 0.38, 0.75)
	sky_mat.sky_horizon_color = Color(0.55, 0.65, 0.85)
	sky_mat.ground_bottom_color = Color(0.12, 0.1, 0.08)
	sky_mat.ground_horizon_color = Color(0.35, 0.32, 0.28)
	sky_mat.sun_angle_max = 30.0
	sky_mat.sun_curve = 0.15
	sky.sky_material = sky_mat
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.35, 0.35, 0.4)
	env.ambient_light_energy = 0.6
	env.tonemap_mode = Environment.TONE_MAPPER_ACES
	env.tonemap_white = 6.0
	env.ssao_enabled = true; env.ssao_radius = 3.0; env.ssao_intensity = 1.5
	env.glow_enabled = true; env.glow_intensity = 0.4; env.glow_bloom = 0.15
	env.glow_blend_mode = Environment.GLOW_BLEND_MODE_SOFTLIGHT
	env.fog_enabled = true
	env.fog_light_color = Color(0.45, 0.48, 0.55)
	env.fog_density = 0.00015
	env.volumetric_fog_enabled = false
	env.sdfgi_enabled = false
	world_env.environment = env
	add_child(world_env)

	sun = DirectionalLight3D.new()
	sun.light_color = Color(1.0, 0.95, 0.85)
	sun.light_energy = 1.2
	sun.rotation = Vector3(deg_to_rad(-45), deg_to_rad(30), 0)
	sun.shadow_enabled = true; sun.shadow_bias = 0.04
	sun.shadow_normal_bias = 2.0
	sun.directional_shadow_max_distance = 200.0
	sun.directional_shadow_mode = DirectionalLight3D.SHADOW_PARALLEL_4_SPLITS
	add_child(sun)
	GameClock.directional_light = sun
	GameClock.world_env = world_env

func _setup_camera():
	rts_camera = Node3D.new()
	rts_camera.name = "RTSCamera"
	var arm = Node3D.new(); arm.name = "CameraArm"
	arm.rotation.x = deg_to_rad(-50)
	rts_camera.add_child(arm)
	var cam = Camera3D.new(); cam.name = "Camera3D"
	cam.fov = 50.0; cam.near = 0.5; cam.far = 400.0
	cam.position = Vector3(0, 2.2, 28)
	arm.add_child(cam)
	rts_camera.set_script(load("res://src/camera/RTSCamera.gd"))
	add_child(rts_camera)
	rts_camera.global_position = Vector3(0, 0, 0)

func _setup_map():
	map_gen = Node3D.new(); map_gen.name = "Map"
	map_gen.set_script(load("res://src/map/MapGenerator.gd"))
	add_child(map_gen)

func _setup_hud():
	hud = CanvasLayer.new(); hud.name = "HUD"
	hud.set_script(load("res://src/ui/HUD.gd"))
	add_child(hud)

func _setup_build_ghost():
	build_ghost = Node3D.new(); build_ghost.name = "BuildGhost"
	build_ghost.set_script(load("res://src/buildings/BuildGhost.gd"))
	add_child(build_ghost)

func _setup_box_select():
	var canvas = CanvasLayer.new(); canvas.layer = 10
	box_rect = ColorRect.new()
	box_rect.color = Color(0.2, 1.0, 0.2, 0.12); box_rect.visible = false
	canvas.add_child(box_rect); add_child(canvas)

func _setup_click_indicator():
	click_ring = Node3D.new(); click_ring.visible = false
	var ring = MeshInstance3D.new()
	var torus = TorusMesh.new()
	torus.inner_radius = 0.25; torus.outer_radius = 0.45
	torus.rings = 16; torus.ring_segments = 16
	ring.mesh = torus; ring.position.y = 0.1
	var rmat = StandardMaterial3D.new()
	rmat.albedo_color = Color(0.2, 1.0, 0.2, 0.7)
	rmat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	rmat.emission_enabled = true; rmat.emission = Color(0.2, 1.0, 0.2)
	rmat.emission_energy_multiplier = 2.0; rmat.no_depth_test = true
	ring.material_override = rmat; click_ring.add_child(ring)
	add_child(click_ring)
	# Attack target ring (red, larger, pulsing)
	attack_ring = Node3D.new(); attack_ring.visible = false
	var aring = MeshInstance3D.new()
	var atorus = TorusMesh.new()
	atorus.inner_radius = 0.6; atorus.outer_radius = 0.9
	atorus.rings = 24; atorus.ring_segments = 24
	aring.mesh = atorus; aring.position.y = 0.1
	var amat = StandardMaterial3D.new()
	amat.albedo_color = Color(1.0, 0.15, 0.15, 0.8)
	amat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	amat.emission_enabled = true; amat.emission = Color(1.0, 0.1, 0.1)
	amat.emission_energy_multiplier = 3.0; amat.no_depth_test = true
	aring.material_override = amat; attack_ring.add_child(aring)
	# Inner cross for attack marker
	for i in range(2):
		var xbar = MeshInstance3D.new()
		var xm = BoxMesh.new(); xm.size = Vector3(1.4, 0.05, 0.12)
		xbar.mesh = xm; xbar.position.y = 0.12
		xbar.rotation.y = PI/4.0 + i * PI/2.0
		xbar.material_override = amat
		attack_ring.add_child(xbar)
	add_child(attack_ring)

func _on_build_mode_changed(active: bool, _building_type: String):
	if active: build_ghost.show_ghost(BuildingManager.current_build_type)
	else: build_ghost.hide_ghost()

func _start_game():
	GameState.start_game()
	# Spawn 1 hero worker around the center circle
	# Player spawns at edge of circle (radius ~60) facing outward
	var spawn_radius = 60.0
	var angle = randf() * TAU  # Random position around circle
	var hero_pos = Vector3(cos(angle) * spawn_radius, 1, sin(angle) * spawn_radius)
	_spawn_hero_worker(hero_pos)
	# First vampire spawns at center (lair)
	_spawn_vampire(Vector3(0, 1, 0), false)
	# Focus camera on hero
	if rts_camera and rts_camera.has_method("focus_on"):
		rts_camera.focus_on(hero_pos)
	if hud and hud.has_method("show_message"):
		hud.show_message("VampBeast! Build a Town Hall, gather resources, survive %d nights!" % GameState.nights_to_survive, Color(1, 0.9, 0.4), 6.0)
	# Start ambient music
	if SoundManager and SoundManager.has_method("start_ambient_music"):
		SoundManager.start_ambient_music()

## Start as a human player in multiplayer
func _start_as_human(slot: int):
	GameState.start_game()
	GameState.local_player_team = GameState.Team.HUMAN
	var spawn_pos = NetworkManager.get_human_spawn_position(slot)
	_spawn_hero_worker(spawn_pos)
	# Spawn AI vampire at center (will be controlled by vampire player via RPC)
	_spawn_vampire(Vector3(0, 1, 0), false)
	if rts_camera and rts_camera.has_method("focus_on"):
		rts_camera.focus_on(spawn_pos)
	if hud and hud.has_method("show_message"):
		var col = NetworkManager.players.get(NetworkManager.local_peer_id, {}).get("color", Color.WHITE)
		hud.show_message("You are Human Player %d! Build and survive!" % (slot + 1), col, 5.0)
	if SoundManager and SoundManager.has_method("start_ambient_music"):
		SoundManager.start_ambient_music()

## Start as the vampire player in multiplayer
func _start_as_vampire():
	GameState.start_game()
	GameState.local_player_team = GameState.Team.VAMPIRE
	is_player_vampire = true
	# Spawn player-controlled vampire at center
	var pvamp = CharacterBody3D.new()
	pvamp.name = "PlayerVampire"
	pvamp.set_script(load("res://src/units/Vampire.gd"))
	pvamp.set("is_boss", true)
	pvamp.set("is_player_controlled", true)
	add_child(pvamp)
	pvamp.global_position = Vector3(0, 2, 0)
	pvamp.died.connect(_on_player_vampire_died.bind(pvamp))
	player_vampire = pvamp
	active_vampires.append(pvamp)
	SelectionManager.select_entity(pvamp)
	if rts_camera and rts_camera.has_method("focus_on"):
		rts_camera.focus_on(Vector3.ZERO)
	if hud and hud.has_method("show_message"):
		hud.show_message("You are the VAMPIRE! Destroy all human players!", Color(0.9, 0.1, 0.1), 5.0)
	if SoundManager and SoundManager.has_method("start_ambient_music"):
		SoundManager.start_ambient_music()

## Network callback: another player places a building
func net_place_building(peer_id: int, pos: Vector3, type: int, grid_pos: Vector2i):
	if peer_id == NetworkManager.local_peer_id: return  # Already placed locally
	_create_building(pos, type, grid_pos)

## Network callback: another player trains a unit
func net_train_unit(peer_id: int, bpos: Vector3, unit_type: String):
	if peer_id == NetworkManager.local_peer_id: return
	match unit_type:
		"worker": _spawn_worker(bpos + Vector3(3, 1, 3))
		"soldier": _spawn_soldier(bpos + Vector3(3, 1, 3))

## Remote player hero position markers
var remote_hero_markers: Dictionary = {}  # peer_id -> MeshInstance3D

func net_update_hero_pos(peer_id: int, pos: Vector3, _hp: int):
	if peer_id == NetworkManager.local_peer_id: return
	if peer_id not in remote_hero_markers:
		# Create a colored marker for this player
		var marker = MeshInstance3D.new()
		var cm = CylinderMesh.new(); cm.top_radius = 0.4; cm.bottom_radius = 0.6; cm.height = 3.0
		marker.mesh = cm
		var mat = StandardMaterial3D.new()
		var col = NetworkManager.players.get(peer_id, {}).get("color", Color.WHITE)
		mat.albedo_color = Color(col.r, col.g, col.b, 0.5)
		mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
		mat.emission_enabled = true; mat.emission = col; mat.emission_energy_multiplier = 1.5
		marker.material_override = mat
		add_child(marker)
		remote_hero_markers[peer_id] = marker
	var m = remote_hero_markers[peer_id]
	m.position = pos + Vector3(0, 1.5, 0)

func net_update_vampire_pos(pos: Vector3, _hp: int):
	# Update vampire position for human players
	if is_player_vampire: return  # We're the vampire
	if not active_vampires.is_empty():
		var v = active_vampires[0]
		if is_instance_valid(v):
			v.global_position = pos + Vector3(0, 1, 0)

func net_vampire_attack_building(pos: Vector3, damage: int):
	if is_player_vampire: return  # We did this
	# Find building near pos and apply damage
	for b in BuildingManager.placed_buildings:
		if is_instance_valid(b) and b.global_position.distance_to(pos) < 5.0:
			if b.has_method("take_damage"):
				b.take_damage(damage)
			break

func _process(delta: float):
	if GameState.current_phase == GameState.GamePhase.LOBBY: return
	# Game over but spectating - still run game logic
	if GameState.is_game_over and not is_spectating: return
	active_vampires = active_vampires.filter(func(v): return is_instance_valid(v))
	player_workers = player_workers.filter(func(w): return is_instance_valid(w))
	player_soldiers = player_soldiers.filter(func(s): return is_instance_valid(s))

	# Vampire respawn logic
	if GameClock.is_nighttime() and active_vampires.size() < GameState.max_vampires_per_wave:
		spawn_timer += delta
		if spawn_timer >= vampire_respawn_delay:
			spawn_timer = 0.0
			_spawn_vampire(Vector3(0, 1, 0), GameState.night_count >= 4)

	# Fog of War update
	fog_update_timer += delta
	if fog_update_timer >= 0.3:
		fog_update_timer = 0.0
		_update_fog_of_war()

	# Track attack ring on target
	if attack_target_tracked:
		if is_instance_valid(attack_target_tracked):
			attack_ring.global_position = attack_target_tracked.global_position + Vector3(0, 0.15, 0)
			attack_ring.visible = true
			attack_ring.rotation.y += delta * 2.0  # Slow spin
			# Check if vampire stopped attacking
			if player_vampire and is_instance_valid(player_vampire):
				var vstate = player_vampire.state
				if vstate != player_vampire.State.ATTACKING and vstate != player_vampire.State.ATTACKING_BUILDING:
					attack_target_tracked = null
					attack_ring.visible = false
		else:
			attack_target_tracked = null
			attack_ring.visible = false

	# Multiplayer position sync
	if NetworkManager.is_multiplayer():
		if is_player_vampire and player_vampire and is_instance_valid(player_vampire):
			NetworkManager.sync_vampire_position(player_vampire.global_position, player_vampire.current_health)
		elif not is_player_vampire and not player_workers.is_empty():
			var hero = player_workers[0]
			if is_instance_valid(hero) and "is_hero" in hero and hero.is_hero:
				NetworkManager.sync_hero_position(hero.global_position, hero.current_health)

func _spawn_hero_worker(pos: Vector3):
	var worker = CharacterBody3D.new()
	worker.name = "HeroWorker"
	worker.set_script(load("res://src/units/HumanWorker.gd"))
	worker.set("is_hero", true)
	worker.set("max_health", 200)
	worker.set("attack_damage", 15)
	add_child(worker)
	worker.global_position = pos
	worker.died.connect(_on_worker_died.bind(worker))
	hero_worker = worker
	player_workers.append(worker)
	# Auto-select hero at start
	SelectionManager.select_entity(worker)

func _spawn_worker(pos: Vector3):
	var worker = CharacterBody3D.new()
	worker.name = "Worker_%d" % player_workers.size()
	worker.set_script(load("res://src/units/HumanWorker.gd"))
	worker.set("is_hero", false)
	add_child(worker)
	worker.global_position = pos
	worker.died.connect(_on_worker_died.bind(worker))
	player_workers.append(worker)

func _spawn_soldier(pos: Vector3):
	var soldier = CharacterBody3D.new()
	soldier.name = "Soldier_%d" % player_soldiers.size()
	soldier.set_script(load("res://src/units/Soldier.gd"))
	add_child(soldier)
	soldier.global_position = pos
	soldier.died.connect(_on_soldier_died.bind(soldier))
	player_soldiers.append(soldier)
	if hud and hud.has_method("show_message"):
		hud.show_message("Soldier trained!", Color(0.5, 1.0, 0.5), 2.0)

func _spawn_vampire(pos: Vector3, make_boss: bool = false):
	var vamp = CharacterBody3D.new()
	vamp.name = "Vampire_%d" % active_vampires.size()
	vamp.set_script(load("res://src/units/Vampire.gd"))
	vamp.set("is_boss", make_boss and GameState.night_count >= 5)
	add_child(vamp)
	vamp.global_position = pos
	vamp.died.connect(_on_vampire_died.bind(vamp))
	active_vampires.append(vamp)

## Called by Town Hall when worker training finishes
func train_worker_at(building_pos: Vector3):
	var spawn_pos = building_pos + Vector3(3, 1, 3)
	_spawn_worker(spawn_pos)
	# Check rally point on the building that trained this worker
	var spawned = player_workers.back() if not player_workers.is_empty() else null
	if spawned and is_instance_valid(spawned):
		var src_building = _find_building_at(building_pos)
		if src_building and src_building.has_meta("rally_tree"):
			var tree = src_building.get_meta("rally_tree")
			if is_instance_valid(tree) and spawned.has_method("command_gather"):
				spawned.call_deferred("command_gather", tree)
		elif src_building and src_building.has_meta("rally_point"):
			var rp = src_building.get_meta("rally_point")
			if spawned.has_method("command_move"):
				spawned.call_deferred("command_move", rp)
	if hud and hud.has_method("show_message"):
		hud.show_message("Worker trained!", Color(0.5, 1.0, 0.5), 2.0)

## Called by Barracks when soldier training finishes
func train_soldier_at(building_pos: Vector3):
	var spawn_pos = building_pos + Vector3(3, 1, 3)
	_spawn_soldier(spawn_pos)
	# Check rally point
	var spawned = player_soldiers.back() if not player_soldiers.is_empty() else null
	if spawned and is_instance_valid(spawned):
		var src_building = _find_building_at(building_pos)
		if src_building and src_building.has_meta("rally_point"):
			var rp = src_building.get_meta("rally_point")
			if spawned.has_method("command_move"):
				spawned.call_deferred("command_move", rp)

func _find_building_at(pos: Vector3) -> Node3D:
	for b in BuildingManager.placed_buildings:
		if is_instance_valid(b) and b.global_position.distance_to(pos) < 3.0:
			return b
	return null

## Player vampire (when hero dies and transforms)
var player_vampire: Node3D = null
var is_player_vampire: bool = false  # Player has become a vampire

func _on_worker_died(worker: Node3D):
	player_workers.erase(worker)
	if worker == hero_worker:
		hero_worker = null
		# TRANSFORMATION: Hero becomes a vampire!
		var death_pos = worker.global_position if is_instance_valid(worker) else Vector3(0, 1, 0)
		call_deferred("_transform_hero_to_vampire", death_pos)
	else:
		GameState.on_worker_died()

func _transform_hero_to_vampire(pos: Vector3):
	is_player_vampire = true

	# === STRIP CONTROL OF OLD UNITS AND BUILDINGS ===
	# Deselect everything first
	SelectionManager.deselect_all()
	# Disconnect workers from player control - they become AI-controlled neutrals
	for w in player_workers:
		if is_instance_valid(w):
			# Remove selection ring visibility
			if "selection_ring" in w and w.selection_ring:
				w.selection_ring.visible = false
	# Clear player unit lists - no longer our units
	player_workers.clear()
	player_soldiers.clear()
	hero_worker = null
	# Hide building command panel
	if hud:
		if "building_cmd_panel" in hud and hud.building_cmd_panel:
			hud.building_cmd_panel.visible = false
		if "info_panel" in hud and hud.info_panel:
			hud.info_panel.visible = false
	# Cancel any active building placement
	BuildingManager.cancel_build()
	build_ghost.hide_ghost()

	# === SPAWN PLAYER VAMPIRE ===
	var pvamp = CharacterBody3D.new()
	pvamp.name = "PlayerVampire"
	pvamp.set_script(load("res://src/units/Vampire.gd"))
	pvamp.set("is_boss", true)
	pvamp.set("is_player_controlled", true)
	add_child(pvamp)
	pvamp.global_position = pos + Vector3(0, 1, 0)
	pvamp.died.connect(_on_player_vampire_died.bind(pvamp))
	player_vampire = pvamp
	active_vampires.append(pvamp)
	# All existing vampires become allies
	for v in active_vampires:
		if is_instance_valid(v) and v != pvamp:
			v.set("has_player_ally", true)
	# Select the player vampire
	SelectionManager.select_entity(pvamp)
	# Focus camera
	if rts_camera and rts_camera.has_method("focus_on"):
		rts_camera.focus_on(pos)
	# Announce transformation
	if hud and hud.has_method("show_message"):
		hud.show_message("YOUR HERO HAS RISEN AS A VAMPIRE!\nRight-click buildings and units to attack!", Color(0.8, 0.1, 0.9), 6.0)
	if hud and hud.has_method("add_kill_message"):
		hud.add_kill_message("Hero transformed into Vampire!", Color(0.8, 0.2, 1.0))
	_play_sound("transform")

## Player vampire attacks a building
func _player_vampire_attack_building(building: Node3D):
	if not player_vampire or not is_instance_valid(player_vampire): return
	# Clear any move command and set building as attack target
	player_vampire.set("has_player_move_target", false)
	player_vampire.set("target_unit", null)
	player_vampire.set("target_building", building)
	player_vampire.state = player_vampire.State.ATTACKING_BUILDING

func _on_player_vampire_died(vamp: Node3D):
	active_vampires.erase(vamp)
	player_vampire = null
	# Show game over but DON'T stop the game - allow spectating
	GameState.is_game_over = true
	GameState.game_over.emit(GameState.Team.VAMPIRE)
	# Camera can still move, game continues in background
	is_spectating = true

func _on_soldier_died(soldier: Node3D):
	player_soldiers.erase(soldier)

func _on_vampire_died(vamp: Node3D):
	active_vampires.erase(vamp)
	spawn_timer = 0.0

func _on_game_over(winner: int):
	if hud and hud.has_method("show_game_over"):
		hud.show_game_over(winner)

func _play_sound(snd_name: String, vol: float = -6.0):
	if SoundManager: SoundManager.play_sound(snd_name, vol)

func _on_wave_started(wave_number: int, vampire_count: int):
	spawn_timer = 0.0
	_play_sound("vampire_growl", -3.0)
	if hud and hud.has_method("show_message"):
		if vampire_count > 1:
			hud.show_message("Night %d - %d Vampires approach!" % [wave_number, vampire_count], Color(1.0, 0.2, 0.2), 4.0)
		else:
			hud.show_message("Night %d - The Vampire hunts!" % wave_number, Color(1.0, 0.3, 0.3), 3.0)

func _on_night_started(_night: int):
	_play_sound("night_warning", -3.0)

func _on_day_started(_day: int):
	_play_sound("build_complete", -4.0)

## ======================== FOG OF WAR ========================

func _update_fog_of_war():
	var vis_range = GameState.get_current_visibility()
	# Collect all player visibility sources
	var sources: Array[Vector3] = []

	if is_player_vampire:
		# Vampire player ONLY sees from vampire position - lost old base vision
		if is_instance_valid(player_vampire):
			sources.append(player_vampire.global_position)
		# Also see from ally vampires
		for v in active_vampires:
			if is_instance_valid(v) and v != player_vampire:
				sources.append(v.global_position)
		vis_range = 80.0  # Vampires have good night vision
	else:
		# Human player: see from workers, soldiers, buildings
		for w in player_workers:
			if is_instance_valid(w): sources.append(w.global_position)
		for s in player_soldiers:
			if is_instance_valid(s): sources.append(s.global_position)
		for b in BuildingManager.placed_buildings:
			if is_instance_valid(b): sources.append(b.global_position)

	# Hide/show vampires based on fog
	for v in active_vampires:
		if not is_instance_valid(v): continue
		# Player vampire is always visible to player
		if v == player_vampire:
			v.visible = true; continue
		# If player is vampire, all ally vampires are always visible
		if is_player_vampire:
			v.visible = true; continue
		# Normal fog check
		var visible_flag = false
		for src in sources:
			if v.global_position.distance_to(src) <= vis_range:
				visible_flag = true; break
		v.visible = visible_flag

## ======================== INPUT ========================

func _unhandled_input(event: InputEvent):
	if GameState.current_phase == GameState.GamePhase.LOBBY: return

	# ESC key always works - even during spectate/game over
	if event.is_action_pressed("escape"):
		if hud and hud.get("esc_menu_shown"):
			hud.toggle_esc_menu()
			return
		elif BuildingManager.is_building:
			BuildingManager.cancel_build(); build_ghost.hide_ghost()
			return
		elif SelectionManager.has_selection():
			SelectionManager.deselect_all()
			return
		elif hud and hud.has_method("toggle_esc_menu"):
			hud.toggle_esc_menu()
			return

	# Block all other input when ESC menu open
	if hud and hud.get("esc_menu_shown"): return

	# When spectating: only allow camera movement, no commands
	if GameState.is_game_over and not is_spectating: return
	if is_spectating:
		# Only handle camera pan via mouse drag
		if event is InputEventMouseMotion and left_dragging:
			var spec_motion := event as InputEventMouseMotion
			rts_camera.pan_by_mouse_delta(spec_motion.relative)
		if event.is_action_pressed("select_click"):
			left_dragging = true; left_drag_total = 0.0
		if event.is_action_released("select_click"):
			left_dragging = false
		return

	# === LEFT CLICK PRESS ===
	if event.is_action_pressed("select_click"):
		var mouse = get_viewport().get_mouse_position()
		left_drag_start = mouse; left_drag_prev = mouse
		left_drag_total = 0.0; did_select_entity = false
		ctrl_held_on_press = Input.is_key_pressed(KEY_CTRL)
		# Vampire player cannot build
		if is_player_vampire and BuildingManager.is_building:
			BuildingManager.cancel_build(); build_ghost.hide_ghost()
			return
		if BuildingManager.is_building:
			_try_place_building(); return
		var entity = _raycast_any_entity(mouse)
		if entity:
			# When player IS vampire: only select own vampire, nothing else
			if is_player_vampire:
				if entity == player_vampire:
					SelectionManager.select_entity(entity)
				else:
					# Clicked something else - ignore, keep vampire selected
					pass
			else:
				SelectionManager.select_entity(entity, Input.is_key_pressed(KEY_SHIFT))
			did_select_entity = true; return
		# Clicked empty space
		if is_player_vampire:
			# Don't deselect vampire on empty click
			pass
		else:
			left_dragging = true; is_box_selecting = false

	if event.is_action_released("select_click"):
		if is_box_selecting: _finish_box_select()
		elif left_dragging and left_drag_total < 8.0 and not did_select_entity:
			if not Input.is_key_pressed(KEY_SHIFT) and not is_player_vampire:
				SelectionManager.deselect_all()
		left_dragging = false; is_box_selecting = false; box_rect.visible = false

	if event.is_action_pressed("move_click"):
		if BuildingManager.is_building:
			BuildingManager.cancel_build(); build_ghost.hide_ghost(); return
		_handle_right_click()

	# === KEYBOARD - Only hero can build (NOT when vampire) ===
	if is_player_vampire: return  # Vampires don't build or train
	var has_hero = _has_hero_selected()

	if has_hero:
		if event.is_action_pressed("build_wall"):
			BuildingManager.start_build(BuildingManager.BuildingType.WALL)
		if event.is_action_pressed("build_tower"):
			BuildingManager.start_build(BuildingManager.BuildingType.TOWER)
		if event.is_action_pressed("build_gate"):
			BuildingManager.start_build(BuildingManager.BuildingType.GATE)
		if event.is_action_pressed("build_farm"):
			BuildingManager.start_build(BuildingManager.BuildingType.FARM)
		if event.is_action_pressed("build_lumbermill"):
			BuildingManager.start_build(BuildingManager.BuildingType.LUMBER_MILL)
		if event.is_action_pressed("build_barracks"):
			BuildingManager.start_build(BuildingManager.BuildingType.BARRACKS)
		if event.is_action_pressed("upgrade"):
			BuildingManager.start_build(BuildingManager.BuildingType.BLACKSMITH)
		# H key = build Town Hall
		if event is InputEventKey and event.pressed and event.keycode == KEY_H:
			BuildingManager.start_build(BuildingManager.BuildingType.TOWN_HALL)

	if event.is_action_pressed("stop"):
		for u in SelectionManager.get_selected():
			if u.has_method("command_stop"): u.command_stop()
	if event.is_action_pressed("gather"):
		_command_gather_nearest()
	if event.is_action_pressed("sell"):
		_sell_selected_building()

	# Train worker at selected Town Hall (N key)
	if event is InputEventKey and event.pressed and event.keycode == KEY_N:
		_train_at_selected_building()

	# Teleport (R key) - hero only
	if event is InputEventKey and event.pressed and event.keycode == KEY_R:
		if has_hero:
			var tp_pos = rts_camera.get_world_position_at_mouse()
			if tp_pos:
				for u in SelectionManager.get_selected():
					if u.has_method("cast_teleport_to"): u.cast_teleport_to(tp_pos)

	# Speed controls
	if event is InputEventKey and event.pressed:
		match event.keycode:
			KEY_1: GameState.set_game_speed(1.0)
			KEY_2: GameState.set_game_speed(2.0)
			KEY_3: GameState.set_game_speed(3.0)
			KEY_SPACE:
				if GameClock.is_paused:
					GameClock.is_paused = false
					GameState.set_game_speed(GameState.game_speed)
					if hud and hud.has_method("show_message"):
						hud.show_message("RESUMED", Color(0.5, 1.0, 0.5), 1.0)
				else:
					GameClock.is_paused = true
					Engine.time_scale = 0.0
					if hud and hud.has_method("show_message"):
						hud.show_message("PAUSED (Space to resume)", Color(1.0, 1.0, 0.5), 999.0)

	# Mouse motion
	if event is InputEventMouseMotion:
		var motion := event as InputEventMouseMotion
		if BuildingManager.is_building:
			var ghost_pos = rts_camera.get_world_position_at_mouse()
			if ghost_pos: build_ghost.update_position(ghost_pos)
		if left_dragging:
			left_drag_total += motion.relative.length()
			var mp = motion.position
			if left_drag_total > 8.0:
				if ctrl_held_on_press:
					is_box_selecting = true; box_rect.visible = true
					box_rect.position = Vector2(min(left_drag_start.x, mp.x), min(left_drag_start.y, mp.y))
					box_rect.size = Vector2(abs(mp.x - left_drag_start.x), abs(mp.y - left_drag_start.y))
				else:
					rts_camera.pan_by_mouse_delta(motion.relative)
			left_drag_prev = mp

func _has_hero_selected() -> bool:
	for e in SelectionManager.get_selected():
		if is_instance_valid(e) and e.has_method("can_build") and e.can_build():
			return true
	return false

func _has_worker_selected() -> bool:
	return SelectionManager.get_selection_type() == SelectionManager.SelType.WORKER

func _train_at_selected_building():
	var selected = SelectionManager.get_selected()
	if selected.is_empty(): return
	var entity = selected[0]
	if "building_type" in entity and entity.has_method("start_training"):
		entity.start_training()

func _raycast_any_entity(screen_pos: Vector2) -> Node3D:
	var cam = rts_camera.get_camera()
	if not cam: return null
	var from = cam.project_ray_origin(screen_pos)
	var to = from + cam.project_ray_normal(screen_pos) * 300.0
	var space = get_world_3d().direct_space_state
	# Units (layer 2)
	var uq = PhysicsRayQueryParameters3D.create(from, to, 2)
	var ur = space.intersect_ray(uq)
	if ur:
		var unit_hit = ur.collider
		if unit_hit is CharacterBody3D: return unit_hit
	# Buildings (layer 4)
	var bq = PhysicsRayQueryParameters3D.create(from, to, 4)
	var br = space.intersect_ray(bq)
	if br:
		var bldg_hit = br.collider
		if bldg_hit is StaticBody3D and ("building_type" in bldg_hit or bldg_hit.has_meta("type")): return bldg_hit
	# Trees (layer 8)
	var tq = PhysicsRayQueryParameters3D.create(from, to, 8)
	var tr = space.intersect_ray(tq)
	if tr:
		var tree_col = tr.collider
		if tree_col.has_meta("type") and tree_col.get_meta("type") == "tree":
			var parent = tree_col.get_parent()
			if parent and parent.has_meta("type"): return parent
			return tree_col
	return null

func _finish_box_select():
	is_box_selecting = false; box_rect.visible = false
	if left_drag_total < 15: return
	var mouse_pos = get_viewport().get_mouse_position()
	var rect = Rect2(
		Vector2(min(left_drag_start.x, mouse_pos.x), min(left_drag_start.y, mouse_pos.y)),
		Vector2(abs(mouse_pos.x - left_drag_start.x), abs(mouse_pos.y - left_drag_start.y)))
	if not Input.is_key_pressed(KEY_SHIFT): SelectionManager.deselect_all()
	var cam = rts_camera.get_camera()
	if not cam: return
	var all_human_units = player_workers + player_soldiers
	for w in all_human_units:
		if is_instance_valid(w):
			var sp = cam.unproject_position(w.global_position)
			if rect.has_point(sp): SelectionManager.select_entity(w, true)

func _handle_right_click():
	if not SelectionManager.has_selection() and not is_player_vampire: return
	var sel_type = SelectionManager.get_selection_type()
	var mouse = get_viewport().get_mouse_position()
	var cam = rts_camera.get_camera()
	if not cam: return
	var from = cam.project_ray_origin(mouse)
	var to = from + cam.project_ray_normal(mouse) * 300.0
	var space = get_world_3d().direct_space_state

	# VAMPIRE PLAYER: always check for attack targets first
	if is_player_vampire and player_vampire and is_instance_valid(player_vampire):
		# Ensure vampire is selected
		if sel_type != SelectionManager.SelType.VAMPIRE:
			SelectionManager.select_entity(player_vampire)

		# Check for building targets (layer mask 4 = collision layer 3 = buildings)
		var bq = PhysicsRayQueryParameters3D.create(from, to, 4)
		var br = space.intersect_ray(bq)
		if br:
			var bldg_hit = br.collider
			if bldg_hit.has_method("take_damage"):
				_player_vampire_attack_building(bldg_hit)
				_show_attack_effect(bldg_hit)
				return

		# Check for human unit targets (layer mask 2 = collision layer 2 = units)
		var vuq = PhysicsRayQueryParameters3D.create(from, to, 2)
		var vur = space.intersect_ray(vuq)
		if vur:
			var vunit_hit = vur.collider
			if vunit_hit is CharacterBody3D and vunit_hit.has_method("get_team") and vunit_hit.get_team() == GameState.Team.HUMAN:
				player_vampire.set("has_player_move_target", false)
				player_vampire.set("target_building", null)
				player_vampire.set("target_unit", vunit_hit)
				player_vampire.state = player_vampire.State.ATTACKING
				_show_attack_effect(vunit_hit)
				return

		# Move to ground position
		var move_target = rts_camera.get_world_position_at_mouse()
		if move_target:
			player_vampire.command_move_to(move_target)
			_show_click_effect(move_target)
		return

	# NON-VAMPIRE: normal RTS right-click logic

	# Rally point for buildings (Town Hall / Barracks)
	if sel_type == SelectionManager.SelType.BUILDING:
		var sel = SelectionManager.get_selected()
		if not sel.is_empty():
			var bld = sel[0]
			if "building_type" in bld:
				var bt = bld.building_type
				if bt == BuildingManager.BuildingType.TOWN_HALL or bt == BuildingManager.BuildingType.BARRACKS:
					var rally_wp = rts_camera.get_world_position_at_mouse()
					if rally_wp:
						# Check if clicking on a tree for auto-gather rally
						var rally_tq = PhysicsRayQueryParameters3D.create(from, to, 8)
						var tresult = space.intersect_ray(rally_tq)
						if tresult and tresult.collider.has_meta("type") and tresult.collider.get_meta("type") == "tree":
							var rally_tree_n = tresult.collider.get_parent() if tresult.collider.get_parent() and tresult.collider.get_parent().has_meta("type") else tresult.collider
							bld.set_meta("rally_point", rally_wp)
							bld.set_meta("rally_tree", rally_tree_n)
							_show_click_effect(rally_wp)
							if hud and hud.has_method("show_message"):
								hud.show_message("Rally: Auto-gather lumber", Color(0.4, 0.8, 0.3), 2.0)
						else:
							bld.set_meta("rally_point", rally_wp)
							if bld.has_meta("rally_tree"): bld.remove_meta("rally_tree")
							_show_click_effect(rally_wp)
							if hud and hud.has_method("show_message"):
								hud.show_message("Rally point set!", Color(0.4, 0.8, 1.0), 2.0)
					return

	# Allow commands for workers and soldiers only (vampire already handled above)
	var valid_types = [SelectionManager.SelType.WORKER, SelectionManager.SelType.SOLDIER]
	if sel_type not in valid_types: return

	# Check for enemy unit targets (layer 2) - soldiers attack vampires
	var uq = PhysicsRayQueryParameters3D.create(from, to, 2)
	var ur = space.intersect_ray(uq)
	if ur:
		var enemy_hit = ur.collider
		if enemy_hit is CharacterBody3D and enemy_hit.has_method("get_team"):
			if enemy_hit.get_team() != GameState.Team.HUMAN:
				SelectionManager.issue_attack_command(enemy_hit); return

	# Worker tree gathering
	if sel_type == SelectionManager.SelType.WORKER:
		var tq = PhysicsRayQueryParameters3D.create(from, to, 8)
		var ray_result = space.intersect_ray(tq)
		if ray_result:
			var tree_hit = ray_result.collider
			if tree_hit.has_meta("type") and tree_hit.get_meta("type") == "tree":
				var tree_node = tree_hit.get_parent() if tree_hit.get_parent() and tree_hit.get_parent().has_meta("type") else tree_hit
				for u in SelectionManager.get_selected():
					if u.has_method("command_gather"): u.command_gather(tree_node)
				return

	var move_pos = rts_camera.get_world_position_at_mouse()
	if move_pos:
		SelectionManager.issue_move_command(move_pos)
		_show_click_effect(move_pos)

func _try_place_building():
	var build_pos = rts_camera.get_world_position_at_mouse()
	if not build_pos: return
	if not build_ghost.is_valid:
		if hud and hud.has_method("show_message"):
			hud.show_message("Can't build there!", Color(1, 0.3, 0.3)); return
	var grid_pos = GameState.world_to_grid(build_pos)
	var type = BuildingManager.current_build_type
	var costs = BuildingManager.building_costs.get(type, [0, 0])
	if not ResourceManager.can_afford(costs[0], costs[1]):
		if hud and hud.has_method("show_message"):
			hud.show_message("Not enough resources!", Color(1, 0.3, 0.3)); return
	if not BuildingManager.can_place_at(grid_pos, type):
		if hud and hud.has_method("show_message"):
			hud.show_message("Space is occupied!", Color(1, 0.3, 0.3)); return
	ResourceManager.spend(costs[0], costs[1])
	var world_pos = GameState.grid_to_world(grid_pos)
	_create_building(world_pos, type, grid_pos)
	GameState.add_score(10)
	# Broadcast to other players in multiplayer
	if NetworkManager.is_multiplayer():
		NetworkManager.rpc_place_building.rpc_id(1,
			NetworkManager.local_peer_id, world_pos.x, world_pos.z,
			type, grid_pos.x, grid_pos.y)
	if not Input.is_key_pressed(KEY_SHIFT):
		BuildingManager.cancel_build(); build_ghost.hide_ghost()

func _create_building(pos: Vector3, type: int, grid_pos: Vector2i):
	var building: Node3D
	match type:
		BuildingManager.BuildingType.WALL:
			building = StaticBody3D.new()
			building.set_script(load("res://src/buildings/Wall.gd"))
		BuildingManager.BuildingType.TOWER:
			building = StaticBody3D.new()
			building.set_script(load("res://src/buildings/Tower.gd"))
		_:
			building = StaticBody3D.new()
			building.set_script(load("res://src/buildings/Building.gd"))
			building.set("building_type", type)
	building.name = "Building_%d" % get_child_count()
	building.position = pos
	building.set("grid_center", grid_pos)
	add_child(building)
	BuildingManager.occupy_cells(grid_pos, type, building)
	building.scale = Vector3(1, 0.01, 1)
	var tw = create_tween()
	tw.tween_property(building, "scale", Vector3(1, 1, 1), 0.4).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_BACK)
	if hud and hud.has_method("show_message"):
		hud.show_message(BuildingManager.get_building_name(type) + " placed!", Color(0.5, 1, 0.5), 1.5)
	_play_sound("place_building")

func _sell_selected_building():
	var selected = SelectionManager.get_selected()
	if selected.is_empty(): return
	var entity = selected[0]
	if "building_type" in entity and "grid_center" in entity:
		BuildingManager.remove_building(entity, entity.grid_center, entity.building_type)
		SelectionManager.deselect_all()
		var tw = create_tween()
		tw.tween_property(entity, "scale:y", 0.0, 0.3)
		tw.tween_callback(entity.queue_free)
		if hud and hud.has_method("show_message"):
			hud.show_message("Building sold! (75% refund)", Color(1, 0.9, 0.4), 2.0)

func _command_gather_nearest():
	for u in SelectionManager.get_selected():
		if u.has_method("command_gather") and map_gen:
			var tree = map_gen.get_nearest_tree(u.global_position, 50.0)
			if tree: u.command_gather(tree)

func _show_click_effect(pos: Vector3):
	click_ring.global_position = pos + Vector3(0, 0.15, 0)
	click_ring.visible = true; click_ring.scale = Vector3(1.5, 1.5, 1.5)
	var tw = create_tween()
	tw.tween_property(click_ring, "scale", Vector3(0.3, 0.3, 0.3), 0.4)
	tw.tween_callback(func(): click_ring.visible = false)

func _show_attack_effect(target_node: Node3D):
	if not is_instance_valid(target_node): return
	attack_ring.global_position = target_node.global_position + Vector3(0, 0.15, 0)
	attack_ring.visible = true; attack_ring.scale = Vector3(0.3, 0.3, 0.3)
	# Set persistent tracking for vampire player
	if is_player_vampire:
		attack_target_tracked = target_node
	var tw = create_tween()
	# Expand then pulse
	tw.tween_property(attack_ring, "scale", Vector3(2.0, 2.0, 2.0), 0.2).set_ease(Tween.EASE_OUT)
	tw.tween_property(attack_ring, "scale", Vector3(1.2, 1.2, 1.2), 0.15)
	tw.tween_property(attack_ring, "scale", Vector3(1.6, 1.6, 1.6), 0.15)
	tw.tween_property(attack_ring, "scale", Vector3(1.0, 1.0, 1.0), 0.3)
	if not is_player_vampire:
		tw.tween_property(attack_ring, "scale", Vector3(0.8, 0.8, 0.8), 0.5)
		tw.tween_callback(func(): attack_ring.visible = false)
