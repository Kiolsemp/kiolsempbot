## VampBeast HUD v7 - Town Hall, population, hero/worker distinction
extends CanvasLayer

var resource_panel: PanelContainer
var lumber_label: Label
var gold_label: Label
var food_label: Label
var time_label: Label
var phase_label: Label
var night_label: Label
var score_label: Label
var speed_label: Label
var unit_count_label: Label
var info_panel: PanelContainer
var info_vbox: VBoxContainer
var entity_name_label: Label
var entity_hp_label: Label
var entity_hp_bar: ProgressBar
var entity_detail_label: Label
var spell_panel: PanelContainer
var spell_vbox: VBoxContainer
var build_panel: PanelContainer
var build_vbox: VBoxContainer
var building_cmd_panel: PanelContainer
var building_cmd_vbox: VBoxContainer
var message_label: Label
var night_warning: Label
var message_timer: float = 0.0
var update_timer: float = 0.0
var minimap_panel: PanelContainer
var minimap_img: TextureRect
var minimap_size: int = 180
var minimap_image: Image
var minimap_texture: ImageTexture
var game_over_panel: PanelContainer
var game_over_shown: bool = false
var phase_bar: ProgressBar
var kill_feed_vbox: VBoxContainer
var kill_messages: Array = []

# Lobby UI
var lobby_panel: PanelContainer
var lobby_vbox: VBoxContainer
var lobby_player_list: VBoxContainer
var lobby_name_input: LineEdit
var lobby_ip_input: LineEdit
var lobby_status_label: Label
var lobby_shown: bool = true

func _ready():
	_create_lobby_ui()
	_create_ui()
	ResourceManager.resources_changed.connect(_on_resources_changed)
	ResourceManager.not_enough_resources.connect(_on_not_enough)
	GameClock.time_changed.connect(_on_time_changed)
	GameClock.night_warning_issued.connect(_on_night_warning)
	GameState.game_phase_changed.connect(_on_phase_changed)
	GameState.score_changed.connect(_on_score_changed)
	SelectionManager.selection_changed.connect(_on_selection_changed)
	BuildingManager.build_mode_changed.connect(_on_build_mode_changed)
	NetworkManager.lobby_updated.connect(_refresh_lobby)
	NetworkManager.game_started.connect(_on_mp_game_started)
	NetworkManager.chat_message.connect(_on_chat_msg)
	# Show lobby at start, hide game UI
	_show_lobby()

func _show_lobby():
	lobby_shown = true
	lobby_panel.visible = true
	resource_panel.visible = false
	minimap_panel.visible = false
	build_panel.visible = false
	info_panel.visible = false
	spell_panel.visible = false
	building_cmd_panel.visible = false

func _hide_lobby():
	lobby_shown = false
	lobby_panel.visible = false
	resource_panel.visible = true
	minimap_panel.visible = true

func _on_mp_game_started():
	_hide_lobby()
	var main = get_tree().current_scene
	if main and main.has_method("start_multiplayer_game"):
		main.start_multiplayer_game()

func _on_chat_msg(sender: String, text: String):
	add_kill_message("[%s]: %s" % [sender, text], Color(0.8, 0.8, 0.3))

func _process(delta: float):
	if lobby_shown: return
	if esc_menu_shown: return  # Don't update game UI when menu open
	if message_timer > 0:
		message_timer -= delta
		if message_timer <= 0:
			message_label.visible = false
	if night_warning and night_warning.visible:
		night_warning.modulate.a = abs(sin(Time.get_ticks_msec() * 0.005))
	update_timer += delta
	if update_timer > 0.2:
		update_timer = 0.0
		_refresh_selection_info()
		_update_minimap()
		_update_phase_bar()
		_update_speed_label()
		_update_kill_feed(delta * 5.0)
		_update_unit_count()

func _create_lobby_ui():
	lobby_panel = PanelContainer.new()
	var ls = StyleBoxFlat.new()
	ls.bg_color = Color(0.05, 0.03, 0.08, 0.95)
	ls.corner_radius_top_left = 12; ls.corner_radius_top_right = 12
	ls.corner_radius_bottom_left = 12; ls.corner_radius_bottom_right = 12
	ls.border_width_bottom = 2; ls.border_width_top = 2
	ls.border_width_left = 2; ls.border_width_right = 2
	ls.border_color = Color(0.6, 0.2, 0.2)
	lobby_panel.add_theme_stylebox_override("panel", ls)
	lobby_panel.set_anchors_preset(Control.PRESET_CENTER)
	lobby_panel.offset_left = -280; lobby_panel.offset_right = 280
	lobby_panel.offset_top = -260; lobby_panel.offset_bottom = 260
	lobby_vbox = VBoxContainer.new()
	lobby_vbox.add_theme_constant_override("separation", 8)
	lobby_panel.add_child(lobby_vbox)
	# Title
	var title = Label.new(); title.text = "VAMPBEAST"
	title.add_theme_font_size_override("font_size", 42)
	title.add_theme_color_override("font_color", Color(0.9, 0.2, 0.2))
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	lobby_vbox.add_child(title)
	var sub = Label.new(); sub.text = "8 Humans vs 1 Vampire - Multiplayer"
	sub.add_theme_font_size_override("font_size", 16)
	sub.add_theme_color_override("font_color", Color(0.6, 0.6, 0.5))
	sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	lobby_vbox.add_child(sub)
	lobby_vbox.add_child(HSeparator.new())
	# Name input
	var nh = HBoxContainer.new()
	var nl = Label.new(); nl.text = "Name:"; nl.add_theme_font_size_override("font_size", 18)
	nl.add_theme_color_override("font_color", Color(0.8, 0.8, 0.7))
	nh.add_child(nl)
	lobby_name_input = LineEdit.new()
	lobby_name_input.text = "Player"
	lobby_name_input.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	lobby_name_input.add_theme_font_size_override("font_size", 18)
	nh.add_child(lobby_name_input); lobby_vbox.add_child(nh)
	# Buttons row
	var bh = HBoxContainer.new(); bh.add_theme_constant_override("separation", 10)
	var sp_btn = _lobby_btn("SINGLEPLAYER", Color(0.15, 0.4, 0.15))
	sp_btn.pressed.connect(_on_singleplayer_pressed)
	bh.add_child(sp_btn)
	var host_btn = _lobby_btn("HOST GAME", Color(0.1, 0.25, 0.5))
	host_btn.pressed.connect(_on_host_pressed)
	bh.add_child(host_btn)
	lobby_vbox.add_child(bh)
	# Join row
	var jh = HBoxContainer.new(); jh.add_theme_constant_override("separation", 8)
	lobby_ip_input = LineEdit.new(); lobby_ip_input.text = "127.0.0.1"
	lobby_ip_input.placeholder_text = "IP Address"
	lobby_ip_input.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	lobby_ip_input.add_theme_font_size_override("font_size", 16)
	jh.add_child(lobby_ip_input)
	var join_btn = _lobby_btn("JOIN", Color(0.4, 0.25, 0.1))
	join_btn.pressed.connect(_on_join_pressed)
	jh.add_child(join_btn)
	lobby_vbox.add_child(jh)
	lobby_vbox.add_child(HSeparator.new())
	# Status
	lobby_status_label = Label.new()
	lobby_status_label.text = "Choose Singleplayer or Host/Join a multiplayer game"
	lobby_status_label.add_theme_font_size_override("font_size", 14)
	lobby_status_label.add_theme_color_override("font_color", Color(0.5, 0.7, 0.5))
	lobby_status_label.autowrap_mode = TextServer.AUTOWRAP_WORD
	lobby_vbox.add_child(lobby_status_label)
	# Player list
	lobby_player_list = VBoxContainer.new()
	lobby_player_list.add_theme_constant_override("separation", 4)
	lobby_vbox.add_child(lobby_player_list)
	# Start / Vampire toggle buttons (shown in lobby)
	var ah = HBoxContainer.new(); ah.add_theme_constant_override("separation", 10)
	ah.name = "ActionRow"
	var vamp_btn = _lobby_btn("Toggle Vampire Role", Color(0.4, 0.1, 0.3))
	vamp_btn.name = "VampBtn"
	vamp_btn.pressed.connect(func(): NetworkManager.request_vampire_role())
	ah.add_child(vamp_btn)
	var start_btn = _lobby_btn("START GAME", Color(0.5, 0.15, 0.15))
	start_btn.name = "StartBtn"
	start_btn.pressed.connect(_on_start_pressed)
	ah.add_child(start_btn)
	var dc_btn = _lobby_btn("Disconnect", Color(0.3, 0.2, 0.2))
	dc_btn.pressed.connect(func(): NetworkManager.disconnect_game(); _refresh_lobby())
	ah.add_child(dc_btn)
	ah.visible = false
	lobby_vbox.add_child(ah)
	add_child(lobby_panel)

func _lobby_btn(text: String, col: Color) -> Button:
	var b = Button.new(); b.text = text
	var bs = StyleBoxFlat.new()
	bs.bg_color = col; bs.corner_radius_top_left = 6; bs.corner_radius_top_right = 6
	bs.corner_radius_bottom_left = 6; bs.corner_radius_bottom_right = 6
	b.add_theme_stylebox_override("normal", bs)
	var bh = bs.duplicate(); bh.bg_color = col * 1.3
	b.add_theme_stylebox_override("hover", bh)
	b.add_theme_font_size_override("font_size", 16)
	b.custom_minimum_size.x = 150; b.custom_minimum_size.y = 36
	b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	return b

func _on_singleplayer_pressed():
	_hide_lobby()
	var main = get_tree().current_scene
	if main and main.has_method("start_singleplayer"):
		main.start_singleplayer()

func _on_host_pressed():
	var pname = lobby_name_input.text.strip_edges()
	if pname.is_empty(): pname = "Host"
	var ok = NetworkManager.host_game(pname)
	if ok:
		lobby_status_label.text = "Hosting on port %d... Waiting for players." % NetworkManager.game_port
	else:
		lobby_status_label.text = "Failed to host! Port may be in use."

func _on_join_pressed():
	var pname = lobby_name_input.text.strip_edges()
	if pname.is_empty(): pname = "Player"
	var ip = lobby_ip_input.text.strip_edges()
	if ip.is_empty(): ip = "127.0.0.1"
	var ok = NetworkManager.join_game(pname, ip)
	if ok:
		lobby_status_label.text = "Connecting to %s..." % ip
	else:
		lobby_status_label.text = "Failed to connect!"

func _on_start_pressed():
	if not NetworkManager.is_host: return
	if NetworkManager.get_player_count() < 2:
		lobby_status_label.text = "Need at least 2 players!"
		return
	NetworkManager.start_multiplayer_game()

func _refresh_lobby():
	if not lobby_panel or not lobby_panel.visible: return
	# Clear player list
	for c in lobby_player_list.get_children(): c.queue_free()
	# Show action buttons if in lobby
	var ar = lobby_vbox.get_node_or_null("ActionRow")
	if ar: ar.visible = NetworkManager.state == NetworkManager.NetState.LOBBY
	if NetworkManager.state == NetworkManager.NetState.LOBBY:
		if NetworkManager.is_host:
			lobby_status_label.text = "%d player(s). YOU ARE HOST (Port: %d)\nFriends connect to your IP on port %d. For online: forward port %d in router." % [
				NetworkManager.get_player_count(), NetworkManager.game_port, NetworkManager.game_port, NetworkManager.game_port]
		else:
			lobby_status_label.text = "%d player(s). Waiting for host to start..." % NetworkManager.get_player_count()
		# Show start button only for host
		var sb = ar.get_node_or_null("StartBtn") if ar else null
		if sb: sb.visible = NetworkManager.is_host
	# List players
	for pid in NetworkManager.players:
		var p = NetworkManager.players[pid]
		var h = HBoxContainer.new()
		var dot = Label.new()
		dot.text = "●"
		dot.add_theme_color_override("font_color", p.color if p.color is Color else Color.WHITE)
		dot.add_theme_font_size_override("font_size", 20)
		h.add_child(dot)
		var nl = Label.new()
		var role_str = " [VAMPIRE]" if p.role == NetworkManager.Role.VAMPIRE else " [Human]"
		var host_str = " (HOST)" if pid == 1 else ""
		var you_str = " ← YOU" if pid == NetworkManager.local_peer_id else ""
		nl.text = " %s%s%s%s" % [p.name, role_str, host_str, you_str]
		nl.add_theme_font_size_override("font_size", 16)
		nl.add_theme_color_override("font_color", Color(0.9, 0.85, 0.7))
		h.add_child(nl)
		lobby_player_list.add_child(h)

func _create_ui():
	_create_top_bar()
	_create_info_panel()
	_create_minimap()
	_create_spell_panel()
	_create_build_panel()
	_create_building_cmd_panel()
	_create_messages()
	_create_phase_bar()
	_create_kill_feed()
	_create_esc_menu()

func _create_top_bar():
	resource_panel = PanelContainer.new()
	var ts = StyleBoxFlat.new()
	ts.bg_color = Color(0.02, 0.02, 0.05, 0.92)
	ts.border_color = Color(0.45, 0.35, 0.15)
	ts.border_width_bottom = 2
	ts.content_margin_left = 20
	ts.content_margin_right = 20
	ts.content_margin_top = 6
	ts.content_margin_bottom = 6
	resource_panel.add_theme_stylebox_override("panel", ts)
	var hb = HBoxContainer.new()
	hb.add_theme_constant_override("separation", 22)
	hb.alignment = BoxContainer.ALIGNMENT_CENTER
	resource_panel.add_child(hb)
	lumber_label = _res_icon(hb, "W", Color(0.4, 0.8, 0.2), "250")
	gold_label = _res_icon(hb, "G", Color(1, 0.85, 0.2), "200")
	food_label = _res_icon(hb, "P", Color(0.9, 0.6, 0.3), "3/20")
	hb.add_child(VSeparator.new())
	time_label = Label.new()
	time_label.text = "06:00"
	time_label.add_theme_font_size_override("font_size", 18)
	time_label.add_theme_color_override("font_color", Color(0.8, 0.8, 0.9))
	hb.add_child(time_label)
	phase_label = Label.new()
	phase_label.text = "DAY"
	phase_label.add_theme_font_size_override("font_size", 20)
	phase_label.add_theme_color_override("font_color", Color(1, 0.9, 0.4))
	hb.add_child(phase_label)
	night_label = Label.new()
	night_label.text = "Night: 0"
	night_label.add_theme_font_size_override("font_size", 16)
	night_label.add_theme_color_override("font_color", Color(0.7, 0.7, 0.8))
	hb.add_child(night_label)
	hb.add_child(VSeparator.new())
	score_label = Label.new()
	score_label.text = "Score: 0"
	score_label.add_theme_font_size_override("font_size", 16)
	score_label.add_theme_color_override("font_color", Color(0.9, 0.8, 0.3))
	hb.add_child(score_label)
	speed_label = Label.new()
	speed_label.text = "1x"
	speed_label.add_theme_font_size_override("font_size", 14)
	speed_label.add_theme_color_override("font_color", Color(0.6, 0.6, 0.7))
	hb.add_child(speed_label)
	hb.add_child(VSeparator.new())
	unit_count_label = Label.new()
	unit_count_label.text = "Units: 1"
	unit_count_label.add_theme_font_size_override("font_size", 14)
	unit_count_label.add_theme_color_override("font_color", Color(0.5, 0.8, 0.5))
	hb.add_child(unit_count_label)
	resource_panel.set_anchors_and_offsets_preset(Control.PRESET_TOP_WIDE)
	add_child(resource_panel)

func _create_phase_bar():
	phase_bar = ProgressBar.new()
	phase_bar.custom_minimum_size = Vector2(300, 8)
	phase_bar.show_percentage = false
	phase_bar.max_value = 1.0
	var bs = StyleBoxFlat.new()
	bs.bg_color = Color(1, 0.9, 0.3)
	for p in ["corner_radius_top_left","corner_radius_top_right","corner_radius_bottom_left","corner_radius_bottom_right"]:
		bs.set(p, 2)
	phase_bar.add_theme_stylebox_override("fill", bs)
	var bg = StyleBoxFlat.new()
	bg.bg_color = Color(0.1, 0.1, 0.15)
	for p in ["corner_radius_top_left","corner_radius_top_right","corner_radius_bottom_left","corner_radius_bottom_right"]:
		bg.set(p, 2)
	phase_bar.add_theme_stylebox_override("background", bg)
	phase_bar.set_anchors_preset(Control.PRESET_CENTER_TOP)
	phase_bar.offset_top = 40; phase_bar.offset_bottom = 48
	phase_bar.offset_left = -150; phase_bar.offset_right = 150
	add_child(phase_bar)

func _update_phase_bar():
	phase_bar.value = GameClock.get_phase_progress()
	var fs = phase_bar.get_theme_stylebox("fill") as StyleBoxFlat
	if fs:
		fs.bg_color = Color(1,0.9,0.3) if GameClock.is_daytime() else Color(0.6,0.15,0.5)

func _update_speed_label():
	if GameClock.is_paused:
		speed_label.text = "PAUSED"
		speed_label.add_theme_color_override("font_color", Color(1, 0.4, 0.4))
	else:
		var spd = GameState.game_speed
		speed_label.text = "%dx" % int(spd)
		speed_label.add_theme_color_override("font_color", Color(0.6,0.6,0.7) if spd == 1.0 else Color(0.4,0.8,1))

func _update_unit_count():
	var main = get_tree().current_scene
	if not main: return
	var workers = main.player_workers.size() if "player_workers" in main else 0
	var soldiers = main.player_soldiers.size() if "player_soldiers" in main else 0
	if main.get("is_player_vampire") and main.is_player_vampire:
		unit_count_label.text = "VAMPIRE"
		unit_count_label.add_theme_color_override("font_color", Color(0.8, 0.2, 0.9))
	elif main.get("hero_worker") and is_instance_valid(main.hero_worker):
		unit_count_label.text = "Hero+%dW+%dS" % [workers - 1, soldiers] if workers > 0 else "Hero+%dS" % soldiers
	else:
		unit_count_label.text = "%dW+%dS" % [workers, soldiers]

func _create_info_panel():
	info_panel = PanelContainer.new()
	info_panel.add_theme_stylebox_override("panel", _panel_style())
	info_panel.custom_minimum_size = Vector2(280, 100)
	info_panel.set_anchors_preset(Control.PRESET_CENTER_BOTTOM)
	info_panel.offset_top = -110; info_panel.offset_bottom = 0
	info_panel.offset_left = -140; info_panel.offset_right = 140
	info_panel.visible = false
	info_vbox = VBoxContainer.new()
	info_vbox.add_theme_constant_override("separation", 3)
	entity_name_label = Label.new()
	entity_name_label.add_theme_font_size_override("font_size", 18)
	entity_name_label.add_theme_color_override("font_color", Color(1, 0.9, 0.6))
	entity_name_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	info_vbox.add_child(entity_name_label)
	entity_hp_bar = ProgressBar.new()
	entity_hp_bar.custom_minimum_size = Vector2(250, 14)
	entity_hp_bar.show_percentage = false
	var hpf = StyleBoxFlat.new(); hpf.bg_color = Color(0.1,0.8,0.1)
	entity_hp_bar.add_theme_stylebox_override("fill", hpf)
	var hpbg = StyleBoxFlat.new(); hpbg.bg_color = Color(0.15,0.05,0.05)
	entity_hp_bar.add_theme_stylebox_override("background", hpbg)
	info_vbox.add_child(entity_hp_bar)
	entity_hp_label = Label.new()
	entity_hp_label.add_theme_font_size_override("font_size", 13)
	entity_hp_label.add_theme_color_override("font_color", Color(0.5,1,0.5))
	entity_hp_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	info_vbox.add_child(entity_hp_label)
	entity_detail_label = Label.new()
	entity_detail_label.add_theme_font_size_override("font_size", 12)
	entity_detail_label.add_theme_color_override("font_color", Color(0.7,0.7,0.7))
	entity_detail_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	info_vbox.add_child(entity_detail_label)
	info_panel.add_child(info_vbox)
	add_child(info_panel)

## ABILITIES PANEL - RIGHT OF MINIMAP (key fix!)
func _create_spell_panel():
	spell_panel = PanelContainer.new()
	spell_panel.add_theme_stylebox_override("panel", _panel_style())
	spell_panel.set_anchors_preset(Control.PRESET_BOTTOM_LEFT)
	spell_panel.offset_left = minimap_size + 24
	spell_panel.offset_right = minimap_size + 24 + 185
	spell_panel.offset_top = -280
	spell_panel.offset_bottom = -10
	spell_panel.visible = false
	spell_vbox = VBoxContainer.new()
	spell_vbox.add_theme_constant_override("separation", 3)
	spell_panel.add_child(spell_vbox)
	add_child(spell_panel)

func _create_build_panel():
	build_panel = PanelContainer.new()
	build_panel.add_theme_stylebox_override("panel", _panel_style())
	build_panel.set_anchors_preset(Control.PRESET_BOTTOM_RIGHT)
	build_panel.offset_left = -200; build_panel.offset_right = -10
	build_panel.offset_top = -420; build_panel.offset_bottom = -10
	build_panel.visible = false
	build_vbox = VBoxContainer.new()
	build_vbox.add_theme_constant_override("separation", 4)
	build_panel.add_child(build_vbox)
	add_child(build_panel)

func _create_building_cmd_panel():
	building_cmd_panel = PanelContainer.new()
	building_cmd_panel.add_theme_stylebox_override("panel", _panel_style())
	building_cmd_panel.set_anchors_preset(Control.PRESET_BOTTOM_RIGHT)
	building_cmd_panel.offset_left = -220; building_cmd_panel.offset_right = -10
	building_cmd_panel.offset_top = -280; building_cmd_panel.offset_bottom = -10
	building_cmd_panel.visible = false
	building_cmd_vbox = VBoxContainer.new()
	building_cmd_vbox.add_theme_constant_override("separation", 4)
	building_cmd_panel.add_child(building_cmd_vbox)
	add_child(building_cmd_panel)

func _create_messages():
	message_label = Label.new()
	message_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	message_label.add_theme_font_size_override("font_size", 22)
	message_label.add_theme_color_override("font_color", Color(1, 0.9, 0.4))
	message_label.set_anchors_preset(Control.PRESET_CENTER_TOP)
	message_label.offset_top = 55; message_label.offset_bottom = 85
	message_label.offset_left = -300; message_label.offset_right = 300
	message_label.visible = false
	add_child(message_label)
	night_warning = Label.new()
	night_warning.text = "NIGHT IS COMING!"
	night_warning.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	night_warning.add_theme_font_size_override("font_size", 32)
	night_warning.add_theme_color_override("font_color", Color(1, 0.3, 0.1))
	night_warning.set_anchors_preset(Control.PRESET_CENTER)
	night_warning.offset_top = -100; night_warning.offset_bottom = -60
	night_warning.offset_left = -200; night_warning.offset_right = 200
	night_warning.visible = false
	add_child(night_warning)

func _create_minimap():
	minimap_panel = PanelContainer.new()
	var s = StyleBoxFlat.new()
	s.bg_color = Color(0,0,0,0.92)
	s.border_color = Color(0.5,0.4,0.2)
	s.border_width_left = 2; s.border_width_right = 2
	s.border_width_top = 2; s.border_width_bottom = 2
	s.content_margin_left = 4; s.content_margin_right = 4
	s.content_margin_top = 4; s.content_margin_bottom = 4
	minimap_panel.add_theme_stylebox_override("panel", s)
	minimap_panel.set_anchors_preset(Control.PRESET_BOTTOM_LEFT)
	minimap_panel.offset_left = 10
	minimap_panel.offset_right = 10 + minimap_size + 8
	minimap_panel.offset_top = -minimap_size - 18
	minimap_panel.offset_bottom = -10
	minimap_img = TextureRect.new()
	minimap_img.custom_minimum_size = Vector2(minimap_size, minimap_size)
	minimap_img.stretch_mode = TextureRect.STRETCH_SCALE
	minimap_panel.add_child(minimap_img)
	minimap_image = Image.create(minimap_size, minimap_size, false, Image.FORMAT_RGBA8)
	minimap_image.fill(Color(0.1, 0.15, 0.08))
	minimap_texture = ImageTexture.create_from_image(minimap_image)
	minimap_img.texture = minimap_texture
	minimap_img.gui_input.connect(_on_minimap_click)
	add_child(minimap_panel)

func _create_kill_feed():
	kill_feed_vbox = VBoxContainer.new()
	kill_feed_vbox.set_anchors_preset(Control.PRESET_TOP_RIGHT)
	kill_feed_vbox.offset_left = -280; kill_feed_vbox.offset_right = -10
	kill_feed_vbox.offset_top = 50; kill_feed_vbox.offset_bottom = 200
	kill_feed_vbox.add_theme_constant_override("separation", 2)
	add_child(kill_feed_vbox)

func add_kill_message(text: String, color: Color = Color(0.8,0.4,0.4)):
	var lbl = Label.new()
	lbl.text = text
	lbl.add_theme_font_size_override("font_size", 12)
	lbl.add_theme_color_override("font_color", color)
	lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	kill_feed_vbox.add_child(lbl)
	kill_messages.append({"label": lbl, "timer": 5.0})
	if kill_feed_vbox.get_child_count() > 5:
		kill_feed_vbox.get_child(0).queue_free()
		if kill_messages.size() > 0: kill_messages.pop_front()

func _update_kill_feed(delta: float):
	var rm = []
	for i in range(kill_messages.size()):
		kill_messages[i].timer -= delta
		if kill_messages[i].timer <= 0: rm.append(i)
		elif kill_messages[i].timer < 1.0: kill_messages[i].label.modulate.a = kill_messages[i].timer
	for i in range(rm.size()-1,-1,-1):
		if rm[i] < kill_messages.size():
			var l = kill_messages[rm[i]].label
			if is_instance_valid(l): l.queue_free()
			kill_messages.remove_at(rm[i])

func _on_minimap_click(event: InputEvent):
	if event is InputEventMouseButton and event.pressed:
		var local_pos = minimap_img.get_local_mouse_position()
		var hm = GameState.map_size / 2.0
		var world_x = (local_pos.x / minimap_size) * GameState.map_size - hm
		var world_z = (local_pos.y / minimap_size) * GameState.map_size - hm
		var cam = get_tree().current_scene.get_node_or_null("RTSCamera")
		if cam and cam.has_method("focus_on"):
			cam.focus_on(Vector3(world_x, 0, world_z))

func _update_minimap():
	if not minimap_image: return
	minimap_image.fill(Color(0.08,0.12,0.06,1))
	var hm = GameState.map_size / 2.0
	for b in BuildingManager.placed_buildings:
		if is_instance_valid(b):
			var bld_px = clampi(int((b.global_position.x+hm)/GameState.map_size*minimap_size),1,minimap_size-2)
			var bld_py = clampi(int((b.global_position.z+hm)/GameState.map_size*minimap_size),1,minimap_size-2)
			var col = Color(0.5,0.5,0.4)
			if "building_type" in b:
				match b.building_type:
					BuildingManager.BuildingType.WALL: col = Color(0.6,0.55,0.4)
					BuildingManager.BuildingType.TOWER: col = Color(0.9,0.8,0.2)
					BuildingManager.BuildingType.TOWN_HALL: col = Color(0.9,0.6,0.2)
					_: col = Color(0.4,0.7,0.3)
			for dx in range(-1,2):
				for dz in range(-1,2):
					minimap_image.set_pixel(clampi(bld_px+dx,0,minimap_size-1),clampi(bld_py+dz,0,minimap_size-1),col)
	# Draw spawn circle on minimap
	var cx2: int = int(minimap_size / 2.0); var cy2: int = int(minimap_size / 2.0)
	var spawn_r = int(60.0 / GameState.map_size * minimap_size)
	for a in range(64):
		var angle = a * TAU / 64.0
		var px2 = clampi(cx2 + int(cos(angle) * spawn_r), 0, minimap_size-1)
		var py2 = clampi(cy2 + int(sin(angle) * spawn_r), 0, minimap_size-1)
		minimap_image.set_pixel(px2, py2, Color(0.3, 0.3, 0.2, 0.6))
	var cx: int = int(minimap_size / 2.0); var cy: int = int(minimap_size / 2.0)
	for dx in range(-4,5):
		for dz in range(-4,5):
			if Vector2(dx,dz).length()<4:
				minimap_image.set_pixel(clampi(cx+dx,0,minimap_size-1),clampi(cy+dz,0,minimap_size-1),Color(0.4,0.05,0.05))
	for u in UnitManager.human_units:
		if is_instance_valid(u):
			var unit_px = clampi(int((u.global_position.x+hm)/GameState.map_size*minimap_size),1,minimap_size-2)
			var unit_py = clampi(int((u.global_position.z+hm)/GameState.map_size*minimap_size),1,minimap_size-2)
			var is_hero_u = "is_hero" in u and u.is_hero
			var uc = Color(1,0.9,0.2) if is_hero_u else Color(0.2,1,0.2)
			var dot_size = 2 if is_hero_u else 1
			for dx in range(-dot_size,dot_size+1):
				for dz in range(-dot_size,dot_size+1):
					minimap_image.set_pixel(clampi(unit_px+dx,0,minimap_size-1),clampi(unit_py+dz,0,minimap_size-1),uc)
	# Check if player has become a vampire
	var main = get_tree().current_scene
	var player_is_vamp = main and "is_player_vampire" in main and main.is_player_vampire
	for u in UnitManager.vampire_units:
		if is_instance_valid(u):
			var vamp_px = clampi(int((u.global_position.x+hm)/GameState.map_size*minimap_size),1,minimap_size-2)
			var vamp_py = clampi(int((u.global_position.z+hm)/GameState.map_size*minimap_size),1,minimap_size-2)
			# Show vampires: always if player is vampire, or at night if visible
			var is_pvamp = "is_player_controlled" in u and u.is_player_controlled
			var show_vamp = player_is_vamp or (GameClock.is_nighttime() and u.visible)
			if show_vamp:
				var vcol = Color(0.8, 0.2, 1.0) if is_pvamp else Color(1, 0.1, 0.1)
				var vs = 3 if is_pvamp else 2
				for dx in range(-vs,vs+1):
					for dz in range(-vs,vs+1):
						minimap_image.set_pixel(clampi(vamp_px+dx,0,minimap_size-1),clampi(vamp_py+dz,0,minimap_size-1),vcol)
	var cam = get_tree().current_scene.get_node_or_null("RTSCamera")
	if cam:
		var cpx = int((cam.global_position.x+hm)/GameState.map_size*minimap_size)
		var cpy = int((cam.global_position.z+hm)/GameState.map_size*minimap_size)
		for i in range(-8,9):
			for b in [-6,6]:
				minimap_image.set_pixel(clampi(cpx+i,0,minimap_size-1),clampi(cpy+b,0,minimap_size-1),Color(1,1,1,0.8))
			for b in [-8,8]:
				minimap_image.set_pixel(clampi(cpx+b,0,minimap_size-1),clampi(cpy+i,0,minimap_size-1),Color(1,1,1,0.8))
	minimap_texture.update(minimap_image)

func _res_icon(p: HBoxContainer, icon: String, col: Color, val: String) -> Label:
	var h = HBoxContainer.new(); h.add_theme_constant_override("separation",4)
	var il = Label.new(); il.text = icon
	il.add_theme_font_size_override("font_size",20)
	il.add_theme_color_override("font_color",col); h.add_child(il)
	var vl = Label.new(); vl.text = val
	vl.add_theme_font_size_override("font_size",18)
	vl.add_theme_color_override("font_color",Color.WHITE); h.add_child(vl)
	p.add_child(h); return vl

func _panel_style() -> StyleBoxFlat:
	var s = StyleBoxFlat.new()
	s.bg_color = Color(0.02,0.02,0.05,0.92)
	s.border_color = Color(0.45,0.35,0.15)
	s.border_width_left = 2; s.border_width_right = 2
	s.border_width_top = 2; s.border_width_bottom = 2
	s.content_margin_left = 10; s.content_margin_right = 10
	s.content_margin_top = 8; s.content_margin_bottom = 8
	return s

func _on_selection_changed(selected: Array, sel_type: String):
	# When player is vampire, hide ALL human building/unit UI
	var main = get_tree().current_scene
	var is_pvamp = main and "is_player_vampire" in main and main.is_player_vampire
	if is_pvamp:
		# Only show info for vampire selection
		if sel_type == "vampire":
			info_panel.visible = true
			spell_panel.visible = true
		else:
			info_panel.visible = false
			spell_panel.visible = false
		build_panel.visible = false
		building_cmd_panel.visible = false
		if sel_type != "vampire": return
	else:
		info_panel.visible = not selected.is_empty()
		spell_panel.visible = sel_type in ["worker","soldier","vampire"]
	# Build panel only shows for hero worker
	var is_hero_sel = false
	if not is_pvamp and sel_type == "worker" and not selected.is_empty():
		var first = selected[0]
		if is_instance_valid(first) and "is_hero" in first and first.is_hero:
			is_hero_sel = true
	build_panel.visible = is_hero_sel
	if not is_pvamp:
		building_cmd_panel.visible = sel_type == "building"
	if selected.is_empty(): return
	var e = selected[0]
	if not is_instance_valid(e): return
	match sel_type:
		"worker":
			if selected.size() == 1:
				if "is_hero" in e and e.is_hero:
					entity_name_label.text = "HERO"
				else:
					entity_name_label.text = "Worker"
			else:
				entity_name_label.text = "%d Workers" % selected.size()
		"soldier": entity_name_label.text = "Soldier" if selected.size()==1 else "%d Soldiers" % selected.size()
		"vampire":
			var bt = " (BOSS)" if "is_boss" in e and e.is_boss else ""
			var is_pvamp_unit = "is_player_controlled" in e and e.is_player_controlled
			if is_pvamp_unit:
				entity_name_label.text = "YOUR VAMPIRE"
				entity_name_label.add_theme_color_override("font_color", Color(0.8, 0.3, 1.0))
			else:
				entity_name_label.text = "Vampire" + bt
		"building":
			if "building_type" in e: entity_name_label.text = BuildingManager.get_building_name(e.building_type)
		"tree": entity_name_label.text = "Tree"
	_update_entity_info(e, sel_type)
	if sel_type in ["worker","soldier","vampire"]: _populate_spell_panel(e, sel_type)
	if is_hero_sel: _populate_build_panel()
	if sel_type == "building": _populate_building_commands(e)

func _populate_spell_panel(e: Node3D, st: String):
	_clear(spell_vbox)
	var t = Label.new(); t.text = "ABILITIES"
	t.add_theme_font_size_override("font_size",14)
	t.add_theme_color_override("font_color",Color(0.9,0.8,0.4))
	t.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	spell_vbox.add_child(t)
	spell_vbox.add_child(HSeparator.new())
	if st == "worker":
		spell_vbox.add_child(_make_btn("[R] Blink (Teleport)",Color(0.2,0.12,0.35)))
		var gb = _make_btn("[G] Gather Nearest",Color(0.12,0.2,0.08))
		gb.pressed.connect(func():
			var m = get_tree().current_scene
			if m and m.has_method("_command_gather_nearest"): m._command_gather_nearest())
		spell_vbox.add_child(gb)
	if st == "soldier":
		var pb = _make_btn("[P] Patrol",Color(0.2,0.15,0.05))
		pb.pressed.connect(func():
			for u in SelectionManager.get_selected():
				if u.has_method("command_patrol"): u.command_patrol())
		spell_vbox.add_child(pb)
	if st == "vampire":
		var is_pvamp_spell = "is_player_controlled" in e and e.is_player_controlled
		var il = Label.new()
		if is_pvamp_spell:
			il.text = "YOUR VAMPIRE"
			il.add_theme_color_override("font_color",Color(0.8,0.3,1.0))
		else:
			il.text = "Enemy Unit"
			il.add_theme_color_override("font_color",Color(0.8,0.3,0.3))
		il.add_theme_font_size_override("font_size",12)
		il.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		spell_vbox.add_child(il)
		if is_pvamp_spell:
			var al = Label.new(); al.text = "RMB to move/attack"
			al.add_theme_font_size_override("font_size",11)
			al.add_theme_color_override("font_color",Color(0.7,0.6,0.9))
			al.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
			spell_vbox.add_child(al)
	var sb = _make_btn("[S] Stop",Color(0.2,0.08,0.08))
	sb.pressed.connect(func():
		for u in SelectionManager.get_selected():
			if u.has_method("command_stop"): u.command_stop())
	spell_vbox.add_child(sb)
	spell_vbox.add_child(HSeparator.new())
	var sh = HBoxContainer.new()
	sh.add_theme_constant_override("separation",3)
	sh.alignment = BoxContainer.ALIGNMENT_CENTER
	for sd in [["1x",1.0],["2x",2.0],["3x",3.0]]:
		var b = _make_btn(sd[0],Color(0.08,0.08,0.12))
		b.custom_minimum_size = Vector2(48,22)
		b.pressed.connect(func(): GameState.set_game_speed(sd[1]))
		sh.add_child(b)
	spell_vbox.add_child(sh)

func _populate_build_panel():
	_clear(build_vbox)
	var t = Label.new(); t.text = "BUILD"
	t.add_theme_font_size_override("font_size",15)
	t.add_theme_color_override("font_color",Color(0.9,0.8,0.4))
	t.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	build_vbox.add_child(t)
	build_vbox.add_child(HSeparator.new())
	_bb(build_vbox,"[H] Town Hall",BuildingManager.BuildingType.TOWN_HALL)
	_bb(build_vbox,"[Q] Wall",BuildingManager.BuildingType.WALL)
	_bb(build_vbox,"[W] Tower",BuildingManager.BuildingType.TOWER)
	_bb(build_vbox,"[E] Gate",BuildingManager.BuildingType.GATE)
	_bb(build_vbox,"[F] Farm",BuildingManager.BuildingType.FARM)
	_bb(build_vbox,"[L] Lumber Mill",BuildingManager.BuildingType.LUMBER_MILL)
	_bb(build_vbox,"[B] Barracks",BuildingManager.BuildingType.BARRACKS)
	_bb(build_vbox,"[U] Blacksmith",BuildingManager.BuildingType.BLACKSMITH)
	build_vbox.add_child(HSeparator.new())
	var h = Label.new()
	h.text = "Shift+Click = multi-place\nSurvive %d nights to win!" % GameState.nights_to_survive
	h.add_theme_font_size_override("font_size",11)
	h.add_theme_color_override("font_color",Color(0.5,0.5,0.5))
	h.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	build_vbox.add_child(h)

func _populate_building_commands(e: Node3D):
	_clear(building_cmd_vbox)
	var bt = e.building_type if "building_type" in e else -1
	var t = Label.new(); t.text = BuildingManager.get_building_name(bt)
	t.add_theme_font_size_override("font_size",16)
	t.add_theme_color_override("font_color",Color(1,0.9,0.6))
	t.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	building_cmd_vbox.add_child(t)
	match bt:
		BuildingManager.BuildingType.TOWN_HALL:
			_il(building_cmd_vbox,"Drop-off point for resources",Color(0.4,0.7,0.3))
			_il(building_cmd_vbox,"Pop: %d/%d"%[GameState.current_population, GameState.max_population],Color(0.9,0.7,0.3))
			if e.has_method("start_training"):
				var it = e.is_training if "is_training" in e else false
				if it:
					var p = e.get_train_progress() if e.has_method("get_train_progress") else 0.0
					_il(building_cmd_vbox,"Training Worker... %d%%"%int(p*100),Color(0.4,0.7,1))
				else:
					var can_pop = GameState.can_train_worker()
					var costs = BuildingManager.worker_train_cost
					var tb = _make_btn("[N] Train Worker (%dW %dG)"%costs,Color(0.15,0.3,0.1))
					if not can_pop or not ResourceManager.can_afford(costs[0], costs[1]):
						tb.disabled = true
					tb.pressed.connect(func():
						e.start_training()
						_populate_building_commands(e))
					building_cmd_vbox.add_child(tb)
					if not can_pop:
						_il(building_cmd_vbox,"Pop limit! Build Farms",Color(1,0.4,0.3))
			# Rally point indicator
			if e.has_meta("rally_point"):
				if e.has_meta("rally_tree"):
					_il(building_cmd_vbox,"Rally: Auto-gather",Color(0.3,0.8,0.3))
				else:
					_il(building_cmd_vbox,"Rally point set",Color(0.4,0.7,1.0))
			else:
				_il(building_cmd_vbox,"RMB: Set rally point",Color(0.5,0.5,0.4))
		BuildingManager.BuildingType.TOWER:
			var d = e.attack_damage if "attack_damage" in e else 15
			_il(building_cmd_vbox,"DMG: %d | Auto-attacks"%d,Color(0.7,0.6,0.4))
		BuildingManager.BuildingType.LUMBER_MILL:
			var lm_lv = e.upgrade_level if "upgrade_level" in e else 0
			_il(building_cmd_vbox,"Produces +%d W every %ds" % [3+lm_lv, 15-lm_lv*2],Color(0.4,0.7,0.3))
		BuildingManager.BuildingType.FARM:
			var fm_lv = e.upgrade_level if "upgrade_level" in e else 0
			_il(building_cmd_vbox,"Produces +%d G every %ds" % [3+fm_lv, 20-fm_lv*3],Color(0.8,0.7,0.3))
		BuildingManager.BuildingType.BARRACKS:
			_il(building_cmd_vbox,"Train soldiers (40W 30G)",Color(0.6,0.5,0.4))
			if e.has_method("start_training"):
				var brk_it = e.is_training if "is_training" in e else false
				if brk_it:
					var brk_p = e.get_train_progress() if e.has_method("get_train_progress") else 0.0
					_il(building_cmd_vbox,"Training... %d%%"%int(brk_p*100),Color(0.4,0.7,1))
				else:
					var brk_tb = _make_btn("Train Soldier (80W 60G)",Color(0.15,0.3,0.1))
					brk_tb.pressed.connect(func():
						e.start_training()
						_populate_building_commands(e))
					building_cmd_vbox.add_child(brk_tb)
			# Rally point indicator for Barracks
			if e.has_meta("rally_point"):
				_il(building_cmd_vbox,"Rally point set",Color(0.4,0.7,1.0))
			else:
				_il(building_cmd_vbox,"RMB: Set rally point",Color(0.5,0.5,0.4))
		BuildingManager.BuildingType.BLACKSMITH:
			var bs_lv = e.upgrade_level if "upgrade_level" in e else 0
			_il(building_cmd_vbox,"Lv%d: +%dDMG +%dHP +%dArmor"%[bs_lv,bs_lv*3,bs_lv*20,bs_lv],Color(0.5,0.5,0.6))
		_: _il(building_cmd_vbox,"Building",Color(0.6,0.6,0.5))
	building_cmd_vbox.add_child(HSeparator.new())
	if e.has_method("upgrade"):
		var upg_lv = e.upgrade_level if "upgrade_level" in e else 0
		var upg_mx = e.max_upgrade if "max_upgrade" in e else 3
		if upg_lv < upg_mx:
			var c = e.get_upgrade_cost() if e.has_method("get_upgrade_cost") else [0,0]
			var ub = _make_btn("Upgrade (%dW %dG)"%c,Color(0.15,0.35,0.55))
			ub.pressed.connect(func():
				if e.upgrade():
					show_message("Upgraded!",Color(0.5,1,0.5),1.5)
					_populate_building_commands(e)
				else: show_message("Can't upgrade!",Color(1,0.3,0.3),1.5))
			building_cmd_vbox.add_child(ub)
		else:
			_il(building_cmd_vbox,"MAX LEVEL",Color(1,0.8,0.2))
	var sb = _make_btn("Sell [DEL]",Color(0.5,0.15,0.15))
	sb.pressed.connect(func():
		var m = get_tree().current_scene
		if m and m.has_method("_sell_selected_building"): m._sell_selected_building())
	building_cmd_vbox.add_child(sb)

func _il(p: VBoxContainer, text: String, col: Color):
	var l = Label.new(); l.text = text
	l.add_theme_font_size_override("font_size",12)
	l.add_theme_color_override("font_color",col)
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	p.add_child(l)

func _update_entity_info(e: Node3D, st: String):
	if not is_instance_valid(e): return
	if "current_health" in e and "max_health" in e:
		entity_hp_label.text = "HP: %d / %d" % [e.current_health, e.max_health]
		entity_hp_bar.max_value = e.max_health
		entity_hp_bar.value = e.current_health
		entity_hp_bar.visible = true
		var r = float(e.current_health)/float(e.max_health)
		var fs = entity_hp_bar.get_theme_stylebox("fill") as StyleBoxFlat
		if fs:
			if r > 0.6: fs.bg_color = Color(0.1,0.8,0.1)
			elif r > 0.3: fs.bg_color = Color(0.8,0.8,0.1)
			else: fs.bg_color = Color(0.8,0.1,0.1)
	else:
		entity_hp_label.text = ""; entity_hp_bar.visible = false
	match st:
		"worker":
			var dp: Array[String] = []
			if e.has_method("get_state_string"): dp.append(e.get_state_string())
			if e.has_method("get_teleport_cd_percent"):
				dp.append("Blink: READY" if e.get_teleport_cd_percent()>=1.0 else "Blink: CD")
			if "carry_amount" in e and e.carry_amount > 0:
				dp.append("Carry: %d/%d"%[e.carry_amount,e.carry_capacity])
			entity_detail_label.text = " | ".join(dp)
		"soldier":
			var sol_dp: Array[String] = []
			if e.has_method("get_state_string"): sol_dp.append(e.get_state_string())
			sol_dp.append("DMG: %d"%(e.attack_damage if "attack_damage" in e else 0))
			entity_detail_label.text = " | ".join(sol_dp)
		"vampire":
			entity_detail_label.text = "DMG: %d | LS: %d%%"%[e.attack_damage if "attack_damage" in e else 0, int(e.lifesteal_percent*100) if "lifesteal_percent" in e else 0]
		"building":
			var lv = e.upgrade_level if "upgrade_level" in e else 0
			entity_detail_label.text = "Level: %d"%(lv+1)
		"tree":
			var lu = 0
			if e.has_meta("lumber"): lu = e.get_meta("lumber")
			else:
				for c in e.get_children():
					if c is StaticBody3D and c.has_meta("lumber"): lu = c.get_meta("lumber"); break
			entity_detail_label.text = "Lumber: %d"%lu

func _refresh_selection_info():
	var sel = SelectionManager.get_selected()
	if sel.is_empty(): return
	if not is_instance_valid(sel[0]): return
	_update_entity_info(sel[0], SelectionManager._type_string())

func _clear(c: VBoxContainer):
	for ch in c.get_children(): ch.queue_free()

func _bb(p: VBoxContainer, text: String, type: int):
	var cost = BuildingManager.get_cost_string(type)
	var b = _make_btn("%s (%s)"%[text,cost],Color(0.08,0.07,0.04))
	b.pressed.connect(func(): BuildingManager.start_build(type))
	p.add_child(b)

func _make_btn(text: String, bg: Color) -> Button:
	var b = Button.new(); b.text = text; b.custom_minimum_size.y = 26
	var s = StyleBoxFlat.new()
	s.bg_color = bg; s.border_color = Color(0.4,0.35,0.2)
	s.border_width_left = 1; s.border_width_right = 1
	s.border_width_top = 1; s.border_width_bottom = 1
	s.corner_radius_top_left = 3; s.corner_radius_top_right = 3
	s.corner_radius_bottom_left = 3; s.corner_radius_bottom_right = 3
	s.content_margin_left = 6; s.content_margin_right = 6
	b.add_theme_stylebox_override("normal", s)
	var h = s.duplicate(); h.bg_color = bg.lightened(0.25)
	b.add_theme_stylebox_override("hover", h)
	b.add_theme_font_size_override("font_size", 13)
	return b

func show_game_over(winner: int):
	if game_over_shown: return
	game_over_shown = true
	game_over_panel = PanelContainer.new()
	var s = StyleBoxFlat.new()
	s.bg_color = Color(0,0,0,0.92)
	s.border_color = Color(0.6,0.5,0.2)
	s.border_width_left = 3; s.border_width_right = 3
	s.border_width_top = 3; s.border_width_bottom = 3
	s.corner_radius_top_left = 10; s.corner_radius_top_right = 10
	s.corner_radius_bottom_left = 10; s.corner_radius_bottom_right = 10
	s.content_margin_left = 40; s.content_margin_right = 40
	s.content_margin_top = 30; s.content_margin_bottom = 30
	game_over_panel.add_theme_stylebox_override("panel", s)
	game_over_panel.set_anchors_preset(Control.PRESET_CENTER)
	game_over_panel.offset_left = -220; game_over_panel.offset_right = 220
	game_over_panel.offset_top = -200; game_over_panel.offset_bottom = 200
	var vb = VBoxContainer.new()
	vb.add_theme_constant_override("separation", 12)
	var tl = Label.new()
	tl.text = "VICTORY!" if winner==GameState.Team.HUMAN else "DEFEAT"
	tl.add_theme_color_override("font_color",Color(1,0.9,0.2) if winner==GameState.Team.HUMAN else Color(1,0.2,0.2))
	tl.add_theme_font_size_override("font_size",52)
	tl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vb.add_child(tl)
	var sl = Label.new()
	sl.text = "Score: %d | Nights: %d | Kills: %d"%[GameState.score,GameState.night_count,GameState.vampires_killed_total]
	sl.add_theme_font_size_override("font_size",18)
	sl.add_theme_color_override("font_color",Color(0.8,0.8,0.8))
	sl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vb.add_child(sl)
	vb.add_child(HSeparator.new())
	# Spectate button
	var spec_btn = _lobby_btn("Watch Game (Spectate)", Color(0.15, 0.3, 0.4))
	spec_btn.pressed.connect(func(): game_over_panel.visible = false)
	vb.add_child(spec_btn)
	# Restart button
	var restart_btn = _lobby_btn("New Game (Main Menu)", Color(0.2, 0.4, 0.15))
	restart_btn.pressed.connect(func(): get_tree().reload_current_scene())
	vb.add_child(restart_btn)
	# Quit button
	var quit_btn = _lobby_btn("Quit Game", Color(0.4, 0.15, 0.15))
	quit_btn.pressed.connect(func(): get_tree().quit())
	vb.add_child(quit_btn)
	game_over_panel.add_child(vb)
	add_child(game_over_panel)
	game_over_panel.modulate.a = 0
	var tw = create_tween()
	tw.tween_property(game_over_panel,"modulate:a",1.0,1.0)

## ====== ESC MENU ======
var esc_menu: PanelContainer
var esc_menu_shown: bool = false

func _create_esc_menu():
	esc_menu = PanelContainer.new()
	var s = StyleBoxFlat.new()
	s.bg_color = Color(0.03, 0.02, 0.06, 0.95)
	s.border_color = Color(0.4, 0.3, 0.2)
	s.border_width_left = 2; s.border_width_right = 2
	s.border_width_top = 2; s.border_width_bottom = 2
	s.corner_radius_top_left = 10; s.corner_radius_top_right = 10
	s.corner_radius_bottom_left = 10; s.corner_radius_bottom_right = 10
	s.content_margin_left = 30; s.content_margin_right = 30
	s.content_margin_top = 20; s.content_margin_bottom = 20
	esc_menu.add_theme_stylebox_override("panel", s)
	esc_menu.set_anchors_preset(Control.PRESET_CENTER)
	esc_menu.offset_left = -180; esc_menu.offset_right = 180
	esc_menu.offset_top = -180; esc_menu.offset_bottom = 180
	var vb = VBoxContainer.new()
	vb.add_theme_constant_override("separation", 10)
	var title = Label.new(); title.text = "GAME MENU"
	title.add_theme_font_size_override("font_size", 28)
	title.add_theme_color_override("font_color", Color(0.9, 0.8, 0.6))
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vb.add_child(title)
	vb.add_child(HSeparator.new())
	var resume_btn = _lobby_btn("Resume Game", Color(0.15, 0.35, 0.15))
	resume_btn.pressed.connect(func(): toggle_esc_menu())
	vb.add_child(resume_btn)
	# Game speed
	var sh = HBoxContainer.new(); sh.add_theme_constant_override("separation", 8)
	var s1 = _lobby_btn("1x", Color(0.2, 0.2, 0.3)); s1.custom_minimum_size.x = 60
	s1.pressed.connect(func(): GameState.set_game_speed(1.0))
	sh.add_child(s1)
	var s2 = _lobby_btn("2x", Color(0.2, 0.2, 0.3)); s2.custom_minimum_size.x = 60
	s2.pressed.connect(func(): GameState.set_game_speed(2.0))
	sh.add_child(s2)
	var s3 = _lobby_btn("3x", Color(0.2, 0.2, 0.3)); s3.custom_minimum_size.x = 60
	s3.pressed.connect(func(): GameState.set_game_speed(3.0))
	sh.add_child(s3)
	vb.add_child(sh)
	vb.add_child(HSeparator.new())
	# Hotkey help
	var help = Label.new()
	help.text = "Q=Wall W=Tower E=Gate H=TownHall\nF=Farm L=Lumber B=Barracks\nG=Gather N=Train S=Stop\nR=Teleport(Hero) Del=Sell\nCtrl+Drag=Box Select\n1/2/3=Speed Space=Pause"
	help.add_theme_font_size_override("font_size", 13)
	help.add_theme_color_override("font_color", Color(0.6, 0.6, 0.5))
	vb.add_child(help)
	vb.add_child(HSeparator.new())
	var main_btn = _lobby_btn("Main Menu", Color(0.3, 0.25, 0.1))
	main_btn.pressed.connect(func(): get_tree().reload_current_scene())
	vb.add_child(main_btn)
	var quit_btn = _lobby_btn("Quit Game", Color(0.4, 0.15, 0.15))
	quit_btn.pressed.connect(func(): get_tree().quit())
	vb.add_child(quit_btn)
	esc_menu.add_child(vb)
	esc_menu.visible = false
	add_child(esc_menu)

func toggle_esc_menu():
	if lobby_shown: return
	esc_menu_shown = !esc_menu_shown
	esc_menu.visible = esc_menu_shown

func _unhandled_input_hud(event: InputEvent):
	if event is InputEventKey and event.pressed and event.keycode == KEY_ESCAPE:
		if not lobby_shown and not game_over_shown:
			toggle_esc_menu()
			get_viewport().set_input_as_handled()

func _on_resources_changed(lum: int, gld: int):
	var lum_rate = ResourceManager.lumber_gained_last_min
	var gld_rate = ResourceManager.gold_gained_last_min
	lumber_label.text = "%d" % lum if lum_rate == 0 else "%d (+%d/m)" % [lum, lum_rate]
	gold_label.text = "%d" % gld if gld_rate == 0 else "%d (+%d/m)" % [gld, gld_rate]
	food_label.text = "%d/%d"%[GameState.current_population, GameState.max_population]

func _on_not_enough(rt: String):
	if SoundManager: SoundManager.play_sound("error", -8.0)
	show_message("Not enough %s!"%rt, Color(1,0.3,0.3))

func _on_time_changed(_t: float):
	time_label.text = GameClock.get_time_string()

func _on_phase_changed(phase: int):
	match phase:
		GameState.GamePhase.DAY_PHASE:
			phase_label.text = "DAY"
			phase_label.add_theme_color_override("font_color",Color(1,0.9,0.4))
			night_warning.visible = false
			show_message("Day %d - Build!"%GameClock.day_number,Color(1,0.9,0.4))
		GameState.GamePhase.NIGHT_PHASE:
			phase_label.text = "NIGHT"
			phase_label.add_theme_color_override("font_color",Color(0.6,0.3,0.8))
			night_warning.visible = false
	night_label.text = "Night: %d/%d"%[GameState.night_count,GameState.nights_to_survive]

func _on_score_changed(sc: int): score_label.text = "Score: %d"%sc
func _on_night_warning():
	night_warning.visible = true
	get_tree().create_timer(5.0).timeout.connect(func(): night_warning.visible = false)

func _on_build_mode_changed(active: bool, bt: String):
	if active: show_message("Building: %s (Click, ESC cancel)"%bt,Color(0.5,1,0.5))
	else: message_label.visible = false

func show_message(text: String, color: Color = Color.WHITE, duration: float = 3.0):
	message_label.text = text
	message_label.add_theme_color_override("font_color", color)
	message_label.visible = true
	message_timer = duration
