## VampBeast Map Generator v4 - Maze layout from 2D array
## Trees respawn after 6 seconds, WC3-style town halls tracked
extends Node3D

const MAP_SIZE: float = 400.0
const HALF_MAP: float = 200.0
const CELL_SIZE: float = 4.0  # Each maze cell = 4x4 world units
const MAZE_DIM: int = 100     # 100x100 cells = 400x400 world

var trees: Array[Node3D] = []
var nav_region: NavigationRegion3D
var grass_multimesh: MultiMeshInstance3D
var town_hall_positions: Array[Vector3] = []

# Tree respawn system
var respawn_queue: Array = []  # [{pos, lumber, timer}]

# Maze grid: 0=path, 1=tree wall, 2=base, 3=lair
var maze_grid: Array = []

func _ready():
	_generate_maze_grid()
	_generate_terrain()
	_generate_navigation()
	_generate_maze_trees()
	_generate_vampire_lair()
	# No human bases at start - player builds their own!
	_generate_grass()
	_generate_rocks()
	_generate_boundary_walls()

func _process(delta: float):
	# Tree respawn timer
	var ri = 0
	while ri < respawn_queue.size():
		respawn_queue[ri].timer -= delta
		if respawn_queue[ri].timer <= 0:
			var data = respawn_queue[ri]
			respawn_queue.remove_at(ri)
			_spawn_single_tree(data.pos, data.lumber)
		else:
			ri += 1

## Called by HumanWorker when a tree is fully chopped
func on_tree_chopped(tree: Node3D):
	if not is_instance_valid(tree):
		return
	var pos = tree.global_position
	var _lumber = tree.get_meta("lumber", 30)
	# Queue for respawn
	respawn_queue.append({
		"pos": pos,
		"lumber": 30,  # Always respawn with full lumber
		"timer": 6.0
	})
	# Clean up
	var grid_pos = GameState.world_to_grid(pos)
	BuildingManager.clear_tree_cell(grid_pos)
	trees.erase(tree)
	# Fade out animation
	var tw = tree.create_tween()
	tw.tween_property(tree, "scale", Vector3(0.01, 0.01, 0.01), 0.4)
	tw.tween_callback(tree.queue_free)

func _spawn_single_tree(pos: Vector3, lumber_amount: int):
	# Check if cell is now occupied by a building
	var grid_pos = GameState.world_to_grid(pos)
	if BuildingManager.occupied_cells.has(grid_pos):
		return  # Building placed here, don't respawn
	var rng = RandomNumberGenerator.new()
	rng.randomize()
	_create_tree(pos, rng, lumber_amount)

# ===== MAZE GENERATION =====
func _generate_maze_grid():
	# Initialize all as tree walls
	maze_grid.resize(MAZE_DIM)
	for x in range(MAZE_DIM):
		maze_grid[x] = []
		maze_grid[x].resize(MAZE_DIM)
		for z in range(MAZE_DIM):
			maze_grid[x][z] = 1  # tree wall

	# Clear center area (vampire lair) - radius ~7 cells = 28 world units
	var center = MAZE_DIM >> 1
	for x in range(center - 8, center + 8):
		for z in range(center - 8, center + 8):
			if _in_bounds(x, z):
				var dist = Vector2(x - center, z - center).length()
				if dist < 8:
					maze_grid[x][z] = 3  # lair

	# Clear spawn ring around center (radius ~60 world = ~15 cells, width ~4 cells)
	var spawn_r = 15  # cells
	for x in range(MAZE_DIM):
		for z in range(MAZE_DIM):
			if _in_bounds(x, z):
				var spawn_dist = Vector2(x - center, z - center).length()
				if spawn_dist >= spawn_r - 3 and spawn_dist <= spawn_r + 3:
					maze_grid[x][z] = 0  # clear path for spawn ring

	# Clear 4 corner bases (each ~10x10 cells = 40x40 world units)
	var base_cells = [
		Vector2i(8, 8),         # Bottom-left
		Vector2i(MAZE_DIM - 18, 8),    # Bottom-right
		Vector2i(8, MAZE_DIM - 18),    # Top-left
		Vector2i(MAZE_DIM - 18, MAZE_DIM - 18),  # Top-right
	]
	for bp in base_cells:
		for x in range(bp.x, bp.x + 10):
			for z in range(bp.y, bp.y + 10):
				if _in_bounds(x, z):
					maze_grid[x][z] = 2  # base

	# Carve main corridors (paths between bases and center)
	# Width 3 cells = 12 world units
	var path_width = 3

	# Diagonal paths from each base to center
	for bp in base_cells:
		var start = Vector2(bp.x + 5, bp.y + 5)
		var end_pt = Vector2(center, center)
		_carve_path(start, end_pt, path_width)

	# Horizontal paths between bases
	_carve_path(Vector2(base_cells[0].x + 5, base_cells[0].y + 5), Vector2(base_cells[1].x + 5, base_cells[1].y + 5), path_width)
	_carve_path(Vector2(base_cells[2].x + 5, base_cells[2].y + 5), Vector2(base_cells[3].x + 5, base_cells[3].y + 5), path_width)

	# Vertical paths between bases
	_carve_path(Vector2(base_cells[0].x + 5, base_cells[0].y + 5), Vector2(base_cells[2].x + 5, base_cells[2].y + 5), path_width)
	_carve_path(Vector2(base_cells[1].x + 5, base_cells[1].y + 5), Vector2(base_cells[3].x + 5, base_cells[3].y + 5), path_width)

	# Ring road around center
	var ring_r = 20  # cells from center
	var ring_points = 16
	for i in range(ring_points):
		var a1 = (float(i) / ring_points) * TAU
		var a2 = (float(i + 1) / ring_points) * TAU
		var p1 = Vector2(center + cos(a1) * ring_r, center + sin(a1) * ring_r)
		var p2 = Vector2(center + cos(a2) * ring_r, center + sin(a2) * ring_r)
		_carve_path(p1, p2, 2)

	# Secondary corridors creating maze-like pockets
	var rng = RandomNumberGenerator.new()
	rng.seed = 54321

	# Create grid of secondary paths
	for x in range(15, MAZE_DIM - 15, 12):
		for z in range(15, MAZE_DIM - 15, 12):
			if maze_grid[x][z] == 1:  # Only carve through walls
				# Random direction corridors
				if rng.randf() < 0.7:
					var len_cells = rng.randi_range(4, 10)
					var dir_choice = rng.randi_range(0, 3)
					var dx = [1, 0, -1, 0][dir_choice]
					var dz = [0, 1, 0, -1][dir_choice]
					for step in range(len_cells):
						var cx = x + dx * step
						var cz = z + dz * step
						if _in_bounds(cx, cz) and maze_grid[cx][cz] == 1:
							maze_grid[cx][cz] = 0
							# Width 2
							if _in_bounds(cx + (1 - abs(dx)), cz + (1 - abs(dz))):
								maze_grid[cx + (1 - abs(dx))][cz + (1 - abs(dz))] = 0

	# Create pockets (small clearings) for hiding bases
	for i in range(30):
		var px = rng.randi_range(12, MAZE_DIM - 12)
		var pz = rng.randi_range(12, MAZE_DIM - 12)
		if maze_grid[px][pz] == 1:
			var pocket_size = rng.randi_range(2, 4)
			for dx in range(-pocket_size, pocket_size + 1):
				for dz in range(-pocket_size, pocket_size + 1):
					if _in_bounds(px + dx, pz + dz) and maze_grid[px + dx][pz + dz] == 1:
						if Vector2(dx, dz).length() <= pocket_size:
							maze_grid[px + dx][pz + dz] = 0
			# Connect pocket to nearest path
			_carve_path(Vector2(px, pz), _find_nearest_path(px, pz), 1)

	# Ensure chokepoints - narrow 1-cell passages at strategic spots
	# (These naturally form from the maze generation)

func _carve_path(from: Vector2, to: Vector2, width: int):
	# Bresenham-style path carving
	var steps = int(max(abs(to.x - from.x), abs(to.y - from.y))) + 1
	for i in range(steps + 1):
		var t = float(i) / float(max(steps, 1))
		var px = int(lerp(from.x, to.x, t))
		var pz = int(lerp(from.y, to.y, t))
		var half_w = width >> 1
		for dx in range(-half_w, half_w + 1):
			for dz in range(-half_w, half_w + 1):
				if _in_bounds(px + dx, pz + dz):
					if maze_grid[px + dx][pz + dz] == 1:
						maze_grid[px + dx][pz + dz] = 0

func _find_nearest_path(x: int, z: int) -> Vector2:
	var best = Vector2(x, z)
	var best_dist = INF
	for dx in range(-15, 16):
		for dz in range(-15, 16):
			var nx = x + dx
			var nz = z + dz
			if _in_bounds(nx, nz) and maze_grid[nx][nz] == 0:
				var d = Vector2(dx, dz).length()
				if d < best_dist:
					best_dist = d
					best = Vector2(nx, nz)
	return best

func _in_bounds(x: int, z: int) -> bool:
	return x >= 0 and x < MAZE_DIM and z >= 0 and z < MAZE_DIM

func _grid_to_world_pos(gx: int, gz: int) -> Vector3:
	# Grid (0,0) = world (-HALF_MAP, -HALF_MAP)
	return Vector3(
		gx * CELL_SIZE - HALF_MAP + CELL_SIZE * 0.5,
		0,
		gz * CELL_SIZE - HALF_MAP + CELL_SIZE * 0.5
	)

# ===== TERRAIN =====
func _generate_terrain():
	var static_body = StaticBody3D.new()
	static_body.name = "TerrainBody"
	static_body.collision_layer = 1
	static_body.collision_mask = 0
	add_child(static_body)

	var col = CollisionShape3D.new()
	var box = BoxShape3D.new()
	box.size = Vector3(MAP_SIZE + 40, 1.0, MAP_SIZE + 40)
	col.shape = box
	col.position.y = -0.5
	static_body.add_child(col)

	var mesh_inst = MeshInstance3D.new()
	var plane = PlaneMesh.new()
	plane.size = Vector2(MAP_SIZE + 40, MAP_SIZE + 40)
	plane.subdivide_width = 80
	plane.subdivide_depth = 80

	var arrays = plane.surface_get_arrays(0)
	var verts: PackedVector3Array = arrays[Mesh.ARRAY_VERTEX]
	var colors = PackedColorArray()
	colors.resize(verts.size())

	for i in range(verts.size()):
		var v = verts[i]
		var _dist = Vector2(v.x, v.z).length()
		var c: Color
		# Map coloring based on maze
		var gx = int((v.x + HALF_MAP) / CELL_SIZE)
		var gz = int((v.z + HALF_MAP) / CELL_SIZE)
		gx = clampi(gx, 0, MAZE_DIM - 1)
		gz = clampi(gz, 0, MAZE_DIM - 1)
		var cell = maze_grid[gx][gz]

		if cell == 3:  # Lair
			c = Color(0.06, 0.03, 0.06)
		elif cell == 2:  # Base
			c = Color(0.32, 0.27, 0.17)
		elif cell == 0:  # Path - varied earth tones
			var path_var = sin(v.x * 0.15) * cos(v.z * 0.12) * 0.04
			c = Color(0.3 + path_var, 0.26 + path_var * 0.8, 0.17 + path_var * 0.5)
		else:  # Tree wall - rich dark forest floor
			c = Color(0.08, 0.2, 0.05)

		var noise = sin(v.x * 0.4) * cos(v.z * 0.35) * 0.025
		noise += sin(v.x * 1.2 + v.z * 0.8) * 0.015  # Higher frequency detail
		c = c.lightened(noise)
		colors[i] = c

	arrays[Mesh.ARRAY_COLOR] = colors

	var arr_mesh = ArrayMesh.new()
	arr_mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
	var mat = StandardMaterial3D.new()
	mat.vertex_color_use_as_albedo = true
	mat.roughness = 0.95
	arr_mesh.surface_set_material(0, mat)
	mesh_inst.mesh = arr_mesh
	add_child(mesh_inst)

func _generate_navigation():
	nav_region = NavigationRegion3D.new()
	nav_region.name = "NavRegion"
	var nav_mesh = NavigationMesh.new()
	nav_mesh.agent_radius = 0.5
	nav_mesh.agent_height = 2.0
	nav_mesh.agent_max_climb = 0.5
	nav_mesh.agent_max_slope = 45.0
	nav_mesh.cell_size = 0.5
	nav_mesh.cell_height = 0.25
	var verts = PackedVector3Array()
	var half = HALF_MAP - 3.0
	verts.append(Vector3(-half, 0.0, -half))
	verts.append(Vector3(half, 0.0, -half))
	verts.append(Vector3(half, 0.0, half))
	verts.append(Vector3(-half, 0.0, half))
	nav_mesh.set_vertices(verts)
	nav_mesh.add_polygon(PackedInt32Array([0, 1, 2]))
	nav_mesh.add_polygon(PackedInt32Array([0, 2, 3]))
	nav_region.navigation_mesh = nav_mesh
	add_child(nav_region)

# ===== MAZE TREES (walls of the labyrinth) =====
func _generate_maze_trees():
	var rng = RandomNumberGenerator.new()
	rng.seed = 42

	# Aggressive culling for performance: step=2 + 50% random skip
	for gx in range(0, MAZE_DIM, 2):
		for gz in range(0, MAZE_DIM, 2):
			if maze_grid[gx][gz] != 1:
				continue
			if rng.randf() < 0.4:
				continue
			var pos = _grid_to_world_pos(gx, gz)
			pos.x += rng.randf_range(-0.8, 0.8)
			pos.z += rng.randf_range(-0.8, 0.8)
			_create_tree(pos, rng, rng.randi_range(20, 45))

func _create_tree(pos: Vector3, rng: RandomNumberGenerator, lumber_amount: int = 30):
	var tree = Node3D.new()
	tree.position = pos
	tree.set_meta("type", "tree")
	tree.set_meta("lumber", lumber_amount)

	var trunk_h = rng.randf_range(4.0, 8.0)
	var trunk_r = rng.randf_range(0.18, 0.4)
	var tree_type = rng.randi_range(0, 2)

	# OPTIMIZED: Single trunk mesh (no root flare, no branches)
	var trunk = MeshInstance3D.new()
	var cyl = CylinderMesh.new()
	cyl.top_radius = trunk_r * 0.4
	cyl.bottom_radius = trunk_r * 1.3
	cyl.height = trunk_h
	cyl.radial_segments = 6
	trunk.mesh = cyl
	trunk.position.y = trunk_h / 2.0
	var tmat = StandardMaterial3D.new()
	match tree_type:
		0: tmat.albedo_color = Color(0.32, 0.2, 0.1).lerp(Color(0.25, 0.15, 0.07), rng.randf())
		1: tmat.albedo_color = Color(0.28, 0.18, 0.08).lerp(Color(0.2, 0.12, 0.06), rng.randf())
		2: tmat.albedo_color = Color(0.7, 0.68, 0.62).lerp(Color(0.8, 0.75, 0.7), rng.randf())
	tmat.roughness = 0.95
	trunk.material_override = tmat
	tree.add_child(trunk)

	# OPTIMIZED: Single canopy mesh (instead of 3-7 spheres)
	var canopy = MeshInstance3D.new()
	var cmat = StandardMaterial3D.new()
	cmat.roughness = 0.8
	match tree_type:
		0:  # Oak - single large sphere
			var sph = SphereMesh.new()
			var cr = rng.randf_range(2.5, 4.0)
			sph.radius = cr; sph.height = cr * 1.5
			sph.radial_segments = 8; sph.rings = 5
			canopy.mesh = sph
			canopy.position.y = trunk_h + rng.randf_range(0.0, 1.0)
			cmat.albedo_color = Color(0.15, 0.35, 0.1).lerp(Color(0.1, 0.28, 0.06), rng.randf())
		1:  # Pine - single cone
			var cm = CylinderMesh.new()
			cm.top_radius = 0.1; cm.bottom_radius = rng.randf_range(2.0, 3.0)
			cm.height = rng.randf_range(4.0, 6.0); cm.radial_segments = 6
			canopy.mesh = cm
			canopy.position.y = trunk_h * 0.6
			cmat.albedo_color = Color(0.08, 0.25, 0.08).lerp(Color(0.06, 0.2, 0.05), rng.randf())
		2:  # Birch - elongated sphere
			var bsph = SphereMesh.new()
			var bcr = rng.randf_range(1.8, 3.0)
			bsph.radius = bcr; bsph.height = bcr * 2.0
			bsph.radial_segments = 8; bsph.rings = 5
			canopy.mesh = bsph
			canopy.position.y = trunk_h + rng.randf_range(0.0, 1.5)
			cmat.albedo_color = Color(0.2, 0.4, 0.12).lerp(Color(0.25, 0.45, 0.15), rng.randf())
	canopy.material_override = cmat
	tree.add_child(canopy)

	# Collision for clicking (keep for gameplay)
	var body = StaticBody3D.new()
	body.collision_layer = 8; body.collision_mask = 0
	body.set_meta("type", "tree"); body.set_meta("lumber", lumber_amount)
	var bcol = CollisionShape3D.new()
	var bcap = CapsuleShape3D.new()
	bcap.radius = trunk_r + 0.6; bcap.height = trunk_h
	bcol.shape = bcap; bcol.position.y = trunk_h / 2.0
	body.add_child(bcol)
	tree.add_child(body)

	var grid_pos = GameState.world_to_grid(pos)
	BuildingManager.mark_tree_cell(grid_pos, tree)
	tree.rotation.y = rng.randf() * TAU
	var s = rng.randf_range(0.85, 1.2)
	tree.scale = Vector3(s, rng.randf_range(0.85, 1.3), s)
	add_child(tree)
	trees.append(tree)

func _generate_grass():
	var rng = RandomNumberGenerator.new()
	rng.seed = 999
	
	# Collect grass positions first
	var positions: Array[Vector3] = []
	var colors: Array[Color] = []
	var max_grass = 1200  # Reduced from 2500 for performance
	var done = false
	for x in range(-int(HALF_MAP - 15), int(HALF_MAP - 15), 8):
		if done: break
		for z in range(-int(HALF_MAP - 15), int(HALF_MAP - 15), 8):
			if positions.size() >= max_grass * 3:
				done = true; break
			var pos = Vector3(x + rng.randf_range(-4, 4), 0, z + rng.randf_range(-4, 4))
			var gx = clampi(int((pos.x + HALF_MAP) / CELL_SIZE), 0, MAZE_DIM - 1)
			var gz = clampi(int((pos.z + HALF_MAP) / CELL_SIZE), 0, MAZE_DIM - 1)
			if maze_grid[gx][gz] == 1 or maze_grid[gx][gz] == 3: continue
			if rng.randf() > 0.4: continue
			# Each tuft = 3 blades (instead of 4-8)
			for _b in range(3):
				var bh = rng.randf_range(0.3, 0.8)
				var offset = Vector3(rng.randf_range(-0.5, 0.5), bh * 0.5, rng.randf_range(-0.5, 0.5))
				positions.append(pos + offset)
				var g = rng.randf_range(0.2, 0.45)
				colors.append(Color(g * 0.4, g, g * 0.15))
	
	# Build MultiMesh for ALL grass blades (1 draw call!)
	var mm = MultiMesh.new()
	mm.transform_format = MultiMesh.TRANSFORM_3D
	mm.use_colors = true
	mm.mesh = BoxMesh.new()
	(mm.mesh as BoxMesh).size = Vector3(0.04, 0.6, 0.015)
	mm.instance_count = positions.size()
	
	for i in range(positions.size()):
		var t = Transform3D()
		t = t.rotated(Vector3.UP, rng.randf() * TAU)
		t = t.rotated(Vector3.RIGHT, rng.randf_range(-0.12, 0.12))
		t.origin = positions[i]
		mm.set_instance_transform(i, t)
		mm.set_instance_color(i, colors[i])
	
	grass_multimesh = MultiMeshInstance3D.new()
	grass_multimesh.multimesh = mm
	var gmat = StandardMaterial3D.new()
	gmat.vertex_color_use_as_albedo = true
	gmat.roughness = 0.85
	gmat.cull_mode = BaseMaterial3D.CULL_DISABLED
	grass_multimesh.material_override = gmat
	add_child(grass_multimesh)

func _generate_vampire_lair():
	var plat = MeshInstance3D.new()
	var cyl = CylinderMesh.new()
	cyl.top_radius = 18.0
	cyl.bottom_radius = 22.0
	cyl.height = 1.0
	plat.mesh = cyl
	plat.position.y = 0.5
	var pmat = StandardMaterial3D.new()
	pmat.albedo_color = Color(0.1, 0.06, 0.1)
	pmat.roughness = 0.7
	pmat.metallic = 0.2
	plat.material_override = pmat
	add_child(plat)

	for i in range(12):
		var angle = (i / 12.0) * TAU
		var px = cos(angle) * 16.0
		var pz = sin(angle) * 16.0

		var pillar = MeshInstance3D.new()
		var pcyl = CylinderMesh.new()
		pcyl.top_radius = 0.4
		pcyl.bottom_radius = 0.65
		pcyl.height = 7.0
		pillar.mesh = pcyl
		pillar.position = Vector3(px, 3.5, pz)
		var pilmat = StandardMaterial3D.new()
		pilmat.albedo_color = Color(0.18, 0.1, 0.18)
		pilmat.roughness = 0.6
		pilmat.metallic = 0.3
		pillar.material_override = pilmat
		add_child(pillar)

		var orb = MeshInstance3D.new()
		var osph = SphereMesh.new()
		osph.radius = 0.5
		osph.height = 1.0
		orb.mesh = osph
		orb.position = Vector3(px, 7.5, pz)
		var omat = StandardMaterial3D.new()
		omat.albedo_color = Color(0.6, 0.05, 0.05)
		omat.emission_enabled = true
		omat.emission = Color(0.8, 0.05, 0.05)
		omat.emission_energy_multiplier = 4.0
		orb.material_override = omat
		add_child(orb)

	for dx in range(-12, 13):
		for dz in range(-12, 13):
			if Vector2(dx, dz).length() <= 12.0:
				BuildingManager.occupied_cells[Vector2i(dx, dz)] = null

	var light = OmniLight3D.new()
	light.position = Vector3(0, 4, 0)
	light.light_color = Color(0.6, 0.08, 0.08)
	light.light_energy = 3.0
	light.omni_range = 30.0
	light.omni_attenuation = 1.5
	add_child(light)

func _get_base_positions() -> Array[Vector3]:
	return [
		Vector3(-150, 0, -150),
		Vector3(150, 0, -150),
		Vector3(-150, 0, 150),
		Vector3(150, 0, 150),
	]

func _generate_human_bases():
	for bp in _get_base_positions():
		town_hall_positions.append(bp)

		var hall = MeshInstance3D.new()
		var hb = BoxMesh.new()
		hb.size = Vector3(7.0, 4.0, 7.0)
		hall.mesh = hb
		hall.position = bp + Vector3(0, 2.0, 0)
		var hmat = StandardMaterial3D.new()
		hmat.albedo_color = Color(0.5, 0.4, 0.25)
		hmat.roughness = 0.8
		hall.material_override = hmat
		add_child(hall)

		var roof = MeshInstance3D.new()
		var prism = PrismMesh.new()
		prism.size = Vector3(8.0, 2.5, 8.0)
		roof.mesh = prism
		roof.position = bp + Vector3(0, 5.25, 0)
		var rmat = StandardMaterial3D.new()
		rmat.albedo_color = Color(0.35, 0.15, 0.08)
		roof.material_override = rmat
		add_child(roof)

		var body = StaticBody3D.new()
		body.collision_layer = 4
		body.set_meta("type", "town_hall")
		var col_sh = CollisionShape3D.new()
		var cbox = BoxShape3D.new()
		cbox.size = Vector3(7.0, 4.0, 7.0)
		col_sh.shape = cbox
		col_sh.position = bp + Vector3(0, 2.0, 0)
		body.add_child(col_sh)
		add_child(body)

		var tc = GameState.world_to_grid(bp)
		for dx in range(-3, 4):
			for dz in range(-3, 4):
				BuildingManager.occupied_cells[tc + Vector2i(dx, dz)] = body

		var blight = OmniLight3D.new()
		blight.position = bp + Vector3(0, 5.0, 0)
		blight.light_color = Color(1.0, 0.85, 0.6)
		blight.light_energy = 2.0
		blight.omni_range = 20.0
		add_child(blight)

func _generate_rocks():
	var rng = RandomNumberGenerator.new()
	rng.seed = 123
	for i in range(200):
		var angle = rng.randf() * TAU
		var dist = rng.randf_range(20.0, HALF_MAP - 15.0)
		var pos = Vector3(cos(angle) * dist, 0, sin(angle) * dist)
		# Only on paths
		var gx = int((pos.x + HALF_MAP) / CELL_SIZE)
		var gz = int((pos.z + HALF_MAP) / CELL_SIZE)
		gx = clampi(gx, 0, MAZE_DIM - 1)
		gz = clampi(gz, 0, MAZE_DIM - 1)
		if maze_grid[gx][gz] != 0:
			continue
		var rock = MeshInstance3D.new()
		# Use spheres squashed for more natural look
		var s = rng.randf_range(0.3, 1.8)
		if rng.randf() > 0.5:
			var rb = SphereMesh.new()
			rb.radius = s * 0.5
			rb.height = s * rng.randf_range(0.3, 0.7)
			rb.radial_segments = rng.randi_range(5, 8)
			rb.rings = rng.randi_range(3, 5)
			rock.mesh = rb
		else:
			var rb2 = BoxMesh.new()
			rb2.size = Vector3(s, s * rng.randf_range(0.3, 0.6), s * rng.randf_range(0.6, 0.9))
			rock.mesh = rb2
		rock.position = pos + Vector3(0, s * 0.15, 0)
		rock.rotation = Vector3(rng.randf_range(-0.15, 0.15), rng.randf() * TAU, rng.randf_range(-0.15, 0.15))
		var rmat = StandardMaterial3D.new()
		# Varied stone colors
		var stone_base = Color(0.4, 0.38, 0.35).lerp(Color(0.3, 0.28, 0.25), rng.randf())
		if rng.randf() < 0.3:  # Some mossy rocks
			stone_base = stone_base.lerp(Color(0.25, 0.35, 0.2), 0.3)
		rmat.albedo_color = stone_base
		rmat.roughness = rng.randf_range(0.85, 0.98)
		rock.material_override = rmat
		add_child(rock)
		# Add small pebbles around larger rocks
		if s > 1.0:
			for _p in range(rng.randi_range(2, 4)):
				var pebble = MeshInstance3D.new()
				var pb = SphereMesh.new()
				var ps = rng.randf_range(0.08, 0.2)
				pb.radius = ps; pb.height = ps * 1.5
				pb.radial_segments = 5; pb.rings = 3
				pebble.mesh = pb
				pebble.position = pos + Vector3(rng.randf_range(-s, s), ps * 0.5, rng.randf_range(-s, s))
				pebble.material_override = rmat
				add_child(pebble)

func _generate_boundary_walls():
	var boundary = StaticBody3D.new()
	boundary.collision_layer = 1
	for side in range(4):
		var col_sh = CollisionShape3D.new()
		var shape = BoxShape3D.new()
		shape.size = Vector3(MAP_SIZE + 50, 20, 3)
		col_sh.shape = shape
		match side:
			0: col_sh.position = Vector3(0, 10, -HALF_MAP - 3)
			1: col_sh.position = Vector3(0, 10, HALF_MAP + 3)
			2:
				col_sh.position = Vector3(-HALF_MAP - 3, 10, 0)
				col_sh.rotation.y = PI / 2
			3:
				col_sh.position = Vector3(HALF_MAP + 3, 10, 0)
				col_sh.rotation.y = PI / 2
		boundary.add_child(col_sh)
	add_child(boundary)

func get_nearest_tree(pos: Vector3, radius: float) -> Node3D:
	var best: Node3D = null
	var best_d = radius * radius
	for tree in trees:
		if is_instance_valid(tree):
			var d = tree.global_position.distance_squared_to(pos)
			if d < best_d:
				best_d = d
				best = tree
	return best

func remove_tree(tree: Node3D):
	var grid_pos = GameState.world_to_grid(tree.global_position)
	BuildingManager.clear_tree_cell(grid_pos)
	trees.erase(tree)
