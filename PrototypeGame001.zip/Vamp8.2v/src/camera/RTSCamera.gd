## Warcraft 3 / LoL style RTS Camera
## - LEFT CLICK DRAG pans INVERSELY (drag down = camera up, like grabbing the map)
## - Very smooth and fluid movement
## - Scroll wheel zoom with auto-tilt
## - Edge scrolling, Arrow keys, Middle mouse rotates
extends Node3D

@export var move_speed: float = 25.0
@export var move_speed_fast: float = 50.0
@export var edge_scroll_speed: float = 20.0
@export var edge_scroll_margin: int = 12
@export var zoom_speed: float = 2.5
@export var zoom_min: float = 10.0
@export var zoom_max: float = 60.0
@export var zoom_default: float = 28.0
@export var rotation_speed: float = 0.004

# Drag pan: lower = smoother/slower
@export var drag_sensitivity: float = 0.006

# WC3 tilt: closer = more side-view angle
@export var tilt_at_max_zoom: float = -62.0
@export var tilt_at_min_zoom: float = -25.0
# Smoothing: higher = snappier, lower = smoother glide
@export var smooth_speed: float = 5.0
@export var zoom_smooth_speed: float = 4.5

# Map bounds (bigger map now)
@export var map_min: Vector2 = Vector2(-220, -220)
@export var map_max: Vector2 = Vector2(220, 220)

var current_zoom: float = 28.0
var target_zoom: float = 28.0
var current_rotation_y: float = 0.0
var target_rotation_y: float = 0.0
var is_rotating: bool = false
var target_position: Vector3 = Vector3.ZERO

@onready var camera_arm: Node3D = $CameraArm
@onready var camera: Camera3D = $CameraArm/Camera3D

func _ready():
	current_zoom = zoom_default
	target_zoom = zoom_default
	target_position = global_position
	_update_camera_transform()

func _process(delta: float):
	_handle_edge_scrolling(delta)
	_handle_keyboard_pan(delta)
	_smooth_update(delta)

func _unhandled_input(event: InputEvent):
	if event is InputEventMouseButton:
		var mb := event as InputEventMouseButton
		if mb.pressed:
			if mb.button_index == MOUSE_BUTTON_WHEEL_UP:
				target_zoom = max(zoom_min, target_zoom - zoom_speed)
				get_viewport().set_input_as_handled()
			elif mb.button_index == MOUSE_BUTTON_WHEEL_DOWN:
				target_zoom = min(zoom_max, target_zoom + zoom_speed)
				get_viewport().set_input_as_handled()

	if event.is_action_pressed("camera_rotate"):
		is_rotating = true
	elif event.is_action_released("camera_rotate"):
		is_rotating = false

	if event is InputEventMouseMotion:
		var motion := event as InputEventMouseMotion
		if is_rotating:
			target_rotation_y -= motion.relative.x * rotation_speed
			get_viewport().set_input_as_handled()

## LoL-style inverse drag: drag mouse down = camera pans UP (grabbing the map)
func pan_by_mouse_delta(delta: Vector2):
	# INVERSE: negate delta so dragging down moves camera up
	var inv_delta = -delta
	# Scale by zoom so it feels consistent at all zoom levels
	var pan_scale = current_zoom * drag_sensitivity
	var world_delta = Vector3(inv_delta.x * pan_scale, 0, inv_delta.y * pan_scale)
	world_delta = world_delta.rotated(Vector3.UP, current_rotation_y)
	target_position += world_delta

func _screen_to_ground(screen_pos: Vector2) -> Variant:
	if not camera:
		return null
	var from = camera.project_ray_origin(screen_pos)
	var dir = camera.project_ray_normal(screen_pos)
	if abs(dir.y) < 0.001:
		return null
	var t = -from.y / dir.y
	if t > 0:
		return from + dir * t
	return null

func _handle_edge_scrolling(delta: float):
	var viewport = get_viewport()
	if not viewport:
		return
	var mouse_pos = viewport.get_mouse_position()
	var screen_size = viewport.get_visible_rect().size
	var move_dir = Vector3.ZERO

	if mouse_pos.x < edge_scroll_margin:
		move_dir.x -= 1.0
	elif mouse_pos.x > screen_size.x - edge_scroll_margin:
		move_dir.x += 1.0
	if mouse_pos.y < edge_scroll_margin:
		move_dir.z -= 1.0
	elif mouse_pos.y > screen_size.y - edge_scroll_margin:
		move_dir.z += 1.0

	if move_dir != Vector3.ZERO:
		move_dir = move_dir.rotated(Vector3.UP, current_rotation_y)
		target_position += move_dir.normalized() * edge_scroll_speed * delta

func _handle_keyboard_pan(delta: float):
	var move_dir = Vector3.ZERO
	if Input.is_action_pressed("camera_up"):    move_dir.z -= 1.0
	if Input.is_action_pressed("camera_down"):  move_dir.z += 1.0
	if Input.is_action_pressed("camera_left"):  move_dir.x -= 1.0
	if Input.is_action_pressed("camera_right"): move_dir.x += 1.0

	if move_dir != Vector3.ZERO:
		var speed = move_speed_fast if Input.is_key_pressed(KEY_SHIFT) else move_speed
		move_dir = move_dir.rotated(Vector3.UP, current_rotation_y)
		target_position += move_dir.normalized() * speed * delta

func _smooth_update(delta: float):
	target_position.x = clamp(target_position.x, map_min.x, map_max.x)
	target_position.z = clamp(target_position.z, map_min.y, map_max.y)
	target_position.y = 0.0

	# Smooth interpolation for fluid camera feel
	global_position = global_position.lerp(target_position, smooth_speed * delta)
	current_zoom = lerp(current_zoom, target_zoom, zoom_smooth_speed * delta)
	current_rotation_y = lerp_angle(current_rotation_y, target_rotation_y, smooth_speed * delta)
	_update_camera_transform()

func _update_camera_transform():
	rotation.y = current_rotation_y
	var zoom_factor = inverse_lerp(zoom_min, zoom_max, current_zoom)
	var tilt_deg = lerp(tilt_at_min_zoom, tilt_at_max_zoom, zoom_factor)
	if camera_arm:
		camera_arm.rotation.x = deg_to_rad(tilt_deg)
	if camera:
		camera.position.z = current_zoom
		camera.position.y = current_zoom * 0.1

func focus_on(pos: Vector3):
	target_position = Vector3(pos.x, 0, pos.z)
	global_position = target_position

func get_world_position_at_mouse() -> Variant:
	return _screen_to_ground(get_viewport().get_mouse_position())

func get_camera() -> Camera3D:
	return camera
