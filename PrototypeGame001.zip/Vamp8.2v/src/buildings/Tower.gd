## Arrow Tower v5 - 2x2, auto-attacks, selectable, upgradeable, destruction tracking
extends StaticBody3D

var max_health: int = 300
var current_health: int = 300
var attack_damage: int = 15
var attack_range: float = 16.0
var attack_cooldown: float = 1.0
var building_type: int = BuildingManager.BuildingType.TOWER
var grid_center: Vector2i = Vector2i.ZERO
var target: Node3D = null
var attack_timer: float = 0.0
var upgrade_level: int = 0
var max_upgrade: int = 3
var is_selected: bool = false

var turret: Node3D
var main_mesh: MeshInstance3D
var hp_bar_pivot: Node3D
var hp_bar_fill: MeshInstance3D
var selection_ring: MeshInstance3D
var night_light: OmniLight3D

func _ready():
	max_health = BuildingManager.building_hp[building_type]
	current_health = max_health
	collision_layer = 4
	collision_mask = 0

	var col = CollisionShape3D.new()
	var cyl_shape = CylinderShape3D.new()
	cyl_shape.radius = 1.8
	cyl_shape.height = 5.0
	col.shape = cyl_shape
	col.position.y = 2.5
	add_child(col)

	main_mesh = MeshInstance3D.new()
	var cyl = CylinderMesh.new()
	cyl.top_radius = 1.2
	cyl.bottom_radius = 1.6
	cyl.height = 5.0
	main_mesh.mesh = cyl
	main_mesh.position.y = 2.5
	var mat = StandardMaterial3D.new()
	mat.albedo_color = Color(0.5, 0.45, 0.35)
	mat.roughness = 0.9
	main_mesh.material_override = mat
	add_child(main_mesh)

	var plat = MeshInstance3D.new()
	var pm = CylinderMesh.new()
	pm.top_radius = 1.6
	pm.bottom_radius = 1.2
	pm.height = 0.4
	plat.mesh = pm
	plat.position.y = 5.2
	var pmat = StandardMaterial3D.new()
	pmat.albedo_color = Color(0.4, 0.35, 0.28)
	plat.material_override = pmat
	add_child(plat)

	turret = Node3D.new()
	turret.position.y = 5.5
	add_child(turret)
	var t_mesh = MeshInstance3D.new()
	var tb = BoxMesh.new()
	tb.size = Vector3(0.3, 0.3, 1.2)
	t_mesh.mesh = tb
	t_mesh.position.z = -0.6
	var tmat = StandardMaterial3D.new()
	tmat.albedo_color = Color(0.35, 0.3, 0.2)
	t_mesh.material_override = tmat
	turret.add_child(t_mesh)

	night_light = OmniLight3D.new()
	night_light.position.y = 5.5
	night_light.light_color = Color(1.0, 0.85, 0.55)
	night_light.light_energy = 0.8
	night_light.omni_range = 58.0
	night_light.omni_attenuation = 0.7
	night_light.shadow_enabled = false
	add_child(night_light)

	_create_selection_ring()
	_create_hp_bar()

func _create_selection_ring():
	selection_ring = MeshInstance3D.new()
	var torus = TorusMesh.new()
	var ring_r = BuildingManager.get_building_radius(building_type)
	torus.inner_radius = ring_r
	torus.outer_radius = ring_r + 0.3
	torus.rings = 20
	torus.ring_segments = 20
	selection_ring.mesh = torus
	selection_ring.position.y = 0.05
	var rmat = StandardMaterial3D.new()
	rmat.albedo_color = Color(0.2, 0.8, 1.0, 0.6)
	rmat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	rmat.emission_enabled = true
	rmat.emission = Color(0.2, 0.7, 1.0)
	rmat.emission_energy_multiplier = 2.5
	rmat.no_depth_test = true
	selection_ring.material_override = rmat
	selection_ring.visible = false
	add_child(selection_ring)

func _create_hp_bar():
	hp_bar_pivot = Node3D.new()
	hp_bar_pivot.position.y = 6.2
	hp_bar_pivot.visible = false
	add_child(hp_bar_pivot)
	var bg = MeshInstance3D.new()
	bg.mesh = BoxMesh.new()
	bg.mesh.size = Vector3(1.2, 0.12, 0.02)
	var bgm = StandardMaterial3D.new()
	bgm.albedo_color = Color(0.15, 0, 0)
	bgm.no_depth_test = true
	bg.material_override = bgm
	hp_bar_pivot.add_child(bg)
	hp_bar_fill = MeshInstance3D.new()
	hp_bar_fill.mesh = BoxMesh.new()
	hp_bar_fill.mesh.size = Vector3(1.1, 0.08, 0.03)
	var fm = StandardMaterial3D.new()
	fm.albedo_color = Color(0.1, 0.9, 0.1)
	fm.no_depth_test = true
	hp_bar_fill.material_override = fm
	hp_bar_pivot.add_child(hp_bar_fill)

var _tower_light_timer: float = 0.0
func _process(delta: float):
	if not is_inside_tree(): return
	if hp_bar_pivot and hp_bar_pivot.visible:
		var cam = get_viewport().get_camera_3d()
		if cam:
			var dsq = hp_bar_pivot.global_position.distance_squared_to(cam.global_position)
			if dsq < 2500.0 and dsq > 0.1:
				hp_bar_pivot.look_at(cam.global_position, Vector3.UP)
	# Night light - update every 0.5s
	_tower_light_timer += delta
	if _tower_light_timer >= 0.5:
		_tower_light_timer = 0.0
		if night_light:
			night_light.light_energy = 3.0 if GameClock.is_nighttime() else 1.2
	_find_target()
	if target and is_instance_valid(target):
		var dir = (target.global_position - global_position).normalized()
		turret.rotation.y = lerp_angle(turret.rotation.y, atan2(dir.x, dir.z), 5.0 * delta)
		attack_timer += delta
		if attack_timer >= attack_cooldown:
			attack_timer = 0.0
			_fire()

func _find_target():
	if target and is_instance_valid(target) and global_position.distance_to(target.global_position) <= attack_range:
		return
	target = null
	var enemies = UnitManager.get_units_in_radius(global_position, attack_range, GameState.Team.VAMPIRE)
	if enemies.size() > 0:
		var best: Node3D = null
		var best_d = INF
		for e in enemies:
			var d = global_position.distance_to(e.global_position)
			if d < best_d:
				best_d = d
				best = e
		target = best

func _fire():
	if not is_inside_tree(): return
	if not target or not is_instance_valid(target):
		return
	if SoundManager: SoundManager.play_sound("tower_shoot", -14.0)
	var proj = MeshInstance3D.new()
	var pm_mesh = BoxMesh.new()
	pm_mesh.size = Vector3(0.08, 0.08, 0.5)
	proj.mesh = pm_mesh
	var pmat = StandardMaterial3D.new()
	pmat.albedo_color = Color(1.0, 0.8, 0.2)
	pmat.emission_enabled = true
	pmat.emission = Color(1.0, 0.7, 0.1)
	pmat.emission_energy_multiplier = 3.0
	proj.material_override = pmat
	var scene = get_tree().current_scene
	if not scene or not is_inside_tree(): return
	scene.add_child(proj)
	proj.global_position = global_position + Vector3(0, 5.5, 0)
	var tgt_pos = target.global_position + Vector3(0, 1, 0)
	if proj.global_position.distance_squared_to(tgt_pos) > 0.01:
		proj.look_at(tgt_pos)
	var captured_target = target
	var tw = create_tween()
	tw.tween_property(proj, "global_position", tgt_pos, 0.25)
	tw.tween_callback(func():
		if is_instance_valid(captured_target) and captured_target.has_method("take_damage"):
			captured_target.take_damage(attack_damage)
		proj.queue_free()
	)

func set_selected(val: bool):
	is_selected = val
	selection_ring.visible = val
	hp_bar_pivot.visible = val or current_health < max_health

func upgrade() -> bool:
	if upgrade_level >= max_upgrade:
		return false
	var cost_w = 30 + upgrade_level * 15
	var cost_g = 20 + upgrade_level * 10
	if not ResourceManager.can_afford(cost_w, cost_g):
		return false
	ResourceManager.spend(cost_w, cost_g)
	upgrade_level += 1
	if SoundManager: SoundManager.play_sound("upgrade", -6.0)
	attack_damage += 5
	attack_range += 2.0
	max_health += 50
	current_health += 50
	attack_cooldown = max(0.4, attack_cooldown - 0.1)
	return true

func get_upgrade_cost() -> Array:
	return [30 + upgrade_level * 15, 20 + upgrade_level * 10]

func take_damage(amount: int):
	current_health -= amount
	current_health = max(0, current_health)
	hp_bar_pivot.visible = true
	var r = float(current_health) / float(max_health)
	hp_bar_fill.scale.x = r
	hp_bar_fill.position.x = (r - 1.0) * 0.55
	if current_health <= 0:
		BuildingManager.free_cells(grid_center, building_type)
		GameState.on_building_destroyed()
		var tw = create_tween()
		tw.tween_property(self, "scale:y", 0.0, 0.4)
		tw.tween_callback(queue_free)
