## Building v7 - Night lights, Town Hall, dynamic selection rings
extends StaticBody3D

var building_type: int = BuildingManager.BuildingType.NONE
var grid_center: Vector2i = Vector2i.ZERO
var current_health: int = 300
var max_health: int = 300
var is_selected: bool = false
var upgrade_level: int = 0
var produces_lumber: bool = false
var provides_food: bool = false
var lumber_timer: float = 0.0
var selection_ring: MeshInstance3D
var hp_bar_pivot: Node3D
var hp_bar_fill: MeshInstance3D
var night_light: OmniLight3D

# Training
var is_training: bool = false
var train_timer: float = 0.0
var train_duration: float = 8.0

# Blacksmith
var blacksmith_upgrades_applied: int = 0

func _ready():
	max_health = BuildingManager.building_hp.get(building_type, 300)
	current_health = max_health
	collision_layer = 4
	collision_mask = 0

	match building_type:
		BuildingManager.BuildingType.GATE: _create_gate()
		BuildingManager.BuildingType.LUMBER_MILL:
			_create_lumber_mill()
			produces_lumber = true
		BuildingManager.BuildingType.FARM:
			_create_farm()
			provides_food = true
		BuildingManager.BuildingType.BARRACKS: _create_barracks()
		BuildingManager.BuildingType.BLACKSMITH: _create_blacksmith()
		BuildingManager.BuildingType.TOWN_HALL: _create_town_hall()

	_create_selection_ring()
	_create_hp_bar()
	_create_night_light()

var _bldg_update_timer: float = 0.0

func _process(delta: float):
	# HP bar billboard - only when visible and camera close
	if hp_bar_pivot and hp_bar_pivot.visible:
		var cam = get_viewport().get_camera_3d()
		if cam:
			var dsq = hp_bar_pivot.global_position.distance_squared_to(cam.global_position)
			if dsq < 2500.0:  # Only billboard within 50m
				if dsq > 0.1: hp_bar_pivot.look_at(cam.global_position, Vector3.UP)
			else:
				hp_bar_pivot.visible = current_health < max_health  # Hide far HP bars

	if produces_lumber:
		lumber_timer += delta
		var rate = 15.0 - upgrade_level * 2.0
		if lumber_timer >= rate:
			lumber_timer = 0.0
			ResourceManager.add_lumber(3 + upgrade_level)

	if provides_food:
		lumber_timer += delta
		var food_rate = 20.0 - upgrade_level * 3.0
		if lumber_timer >= food_rate:
			lumber_timer = 0.0
			ResourceManager.add_gold(3 + upgrade_level)
			if GameState.max_population < 5 + get_farm_count() * 3:
				GameState.max_population = 5 + get_farm_count() * 3

	if is_training:
		train_timer += delta
		if train_timer >= train_duration:
			_finish_training()

	# Slow updates (lights, regen) - every 0.5s instead of every frame
	_bldg_update_timer += delta
	if _bldg_update_timer >= 0.5:
		_bldg_update_timer = 0.0
		# Night light
		if night_light:
			var target = 1.2
			if GameClock.is_nighttime():
				target = 3.0
			elif GameClock.time_of_day > 0.35:
				var dusk_t = (GameClock.time_of_day - 0.35) / 0.15
				target = lerp(1.2, 3.0, clampf(dusk_t, 0.0, 1.0))
			night_light.light_energy = target  # Snap instead of lerp
		# Daytime HP regen
		if not GameClock.is_nighttime() and current_health < max_health:
			current_health = mini(current_health + 1, max_health)
			_update_hp()

func get_farm_count() -> int:
	var count = 0
	for b in BuildingManager.placed_buildings:
		if is_instance_valid(b) and "building_type" in b and b.building_type == BuildingManager.BuildingType.FARM:
			count += 1
	return count

func _create_selection_ring():
	selection_ring = MeshInstance3D.new()
	var torus = TorusMesh.new()
	# Dynamic ring size based on building radius
	var ring_r = BuildingManager.get_building_radius(building_type)
	torus.inner_radius = ring_r
	torus.outer_radius = ring_r + 0.3
	torus.rings = 24
	torus.ring_segments = 24
	selection_ring.mesh = torus
	selection_ring.position.y = 0.05
	var rmat = StandardMaterial3D.new()
	rmat.albedo_color = Color(0.2, 0.8, 1.0, 0.6)
	rmat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	rmat.emission_enabled = true
	rmat.emission = Color(0.2, 0.7, 1.0)
	rmat.emission_energy_multiplier = 2.5
	rmat.no_depth_test = true
	selection_ring.material_override = rmat
	selection_ring.visible = false
	add_child(selection_ring)

func set_selected(val: bool):
	is_selected = val
	selection_ring.visible = val
	hp_bar_pivot.visible = val or current_health < max_health

func _create_night_light():
	night_light = OmniLight3D.new()
	night_light.light_color = Color(1.0, 0.85, 0.6)
	night_light.light_energy = 0.8  # Start with some glow
	night_light.omni_attenuation = 0.7
	night_light.shadow_enabled = false
	# Position light above building
	var fp = BuildingManager.get_footprint(building_type)
	if fp.size() <= 1:
		night_light.position.y = 3.0
		night_light.omni_range = 41.0
	elif fp.size() <= 4:
		night_light.position.y = 5.0
		night_light.omni_range = 58.0
	else:
		night_light.position.y = 6.0
		night_light.omni_range = 66.0
	# Town Hall has biggest warmest light
	if building_type == BuildingManager.BuildingType.TOWN_HALL:
		night_light.omni_range = 82.0
		night_light.light_color = Color(1.0, 0.9, 0.6)
	add_child(night_light)

## Start training a worker (Town Hall) or soldier (Barracks)
func start_training():
	if is_training: return
	if building_type == BuildingManager.BuildingType.TOWN_HALL:
		var costs = BuildingManager.worker_train_cost
		if not ResourceManager.can_afford(costs[0], costs[1]): return
		if not GameState.can_train_worker(): return
		ResourceManager.spend(costs[0], costs[1])
		is_training = true
		train_timer = 0.0
		train_duration = BuildingManager.worker_train_duration
	elif building_type == BuildingManager.BuildingType.BARRACKS:
		if not ResourceManager.can_afford(80, 60): return
		ResourceManager.spend(80, 60)
		is_training = true
		train_timer = 0.0
		train_duration = 12.0
	elif building_type == BuildingManager.BuildingType.BLACKSMITH:
		if not ResourceManager.can_afford(50, 80): return
		ResourceManager.spend(50, 80)
		_apply_blacksmith_upgrade()

func _finish_training():
	is_training = false
	train_timer = 0.0
	if SoundManager: SoundManager.play_sound("train", -6.0)
	var main = get_tree().current_scene
	if building_type == BuildingManager.BuildingType.TOWN_HALL:
		if main and main.has_method("train_worker_at"):
			main.train_worker_at(global_position)
	elif building_type == BuildingManager.BuildingType.BARRACKS:
		if main and main.has_method("train_soldier_at"):
			main.train_soldier_at(global_position)

func _apply_blacksmith_upgrade():
	blacksmith_upgrades_applied += 1
	# Global upgrade for all soldiers and workers
	for u in UnitManager.human_units:
		if is_instance_valid(u):
			if "armor" in u: u.armor += 2
			if "attack_damage" in u: u.attack_damage += 3

func take_damage(amount: int, _attacker: Node3D = null):
	current_health -= amount
	current_health = max(0, current_health)
	hp_bar_pivot.visible = true
	_update_hp()
	# Damage flash
	for child in get_children():
		if child is MeshInstance3D and child != selection_ring and child != hp_bar_fill:
			var mat = child.material_override
			if mat and mat is StandardMaterial3D:
				var orig_c = mat.albedo_color
				mat.albedo_color = Color(1, 0.2, 0.2)
				var ftw = create_tween()
				ftw.tween_property(mat, "albedo_color", orig_c, 0.3)
	if SoundManager: SoundManager.play_sound("attack_hit", -14.0)
	if current_health <= 0:
		if SoundManager: SoundManager.play_sound("death", -6.0)
		_on_destroyed()

func _update_hp():
	var r = float(current_health) / float(max_health)
	hp_bar_fill.scale.x = max(0.01, r)
	hp_bar_fill.position.x = (r - 1.0) * 0.375
	var fm = hp_bar_fill.material_override as StandardMaterial3D
	if fm:
		fm.albedo_color = Color(0.1,0.9,0.1) if r>0.5 else (Color(0.9,0.9,0.1) if r>0.25 else Color(0.9,0.1,0.1))

func _on_destroyed():
	GameState.on_building_destroyed()
	# Check Town Hall loss
	if building_type == BuildingManager.BuildingType.TOWN_HALL:
		var remaining_th = 0
		for b in BuildingManager.placed_buildings:
			if is_instance_valid(b) and "building_type" in b and b.building_type == BuildingManager.BuildingType.TOWN_HALL and b != self:
				remaining_th += 1
		if remaining_th == 0:
			var main = get_tree().current_scene
			if main and main.has_node("HUD"):
				var hud_n = main.get_node("HUD")
				if hud_n.has_method("show_message"):
					hud_n.show_message("TOWN HALL DESTROYED! Build a new one!", Color(1, 0.2, 0.2), 6.0)
	BuildingManager.remove_building(self, grid_center, building_type)
	var tw = create_tween()
	tw.tween_property(self, "scale:y", 0.0, 0.3)
	tw.tween_callback(queue_free)

func get_train_progress() -> float:
	if not is_training: return 0.0
	return train_timer / train_duration

## ======================== BUILDING VISUALS ========================

func _create_town_hall():
	var col = CollisionShape3D.new()
	var box = BoxShape3D.new(); box.size = Vector3(6, 5, 6)
	col.shape = box; col.position.y = 2.5; add_child(col)
	# Main structure
	var base = MeshInstance3D.new()
	var bm = BoxMesh.new(); bm.size = Vector3(6, 4, 6)
	base.mesh = bm; base.position.y = 2.0
	var mat = StandardMaterial3D.new(); mat.albedo_color = Color(0.45, 0.35, 0.2); mat.roughness = 0.8
	base.material_override = mat; add_child(base)
	# Roof
	var roof = MeshInstance3D.new()
	var rm = CylinderMesh.new(); rm.top_radius = 0.3; rm.bottom_radius = 4.5; rm.height = 2.5
	roof.mesh = rm; roof.position.y = 5.25
	var rmat = StandardMaterial3D.new(); rmat.albedo_color = Color(0.5, 0.2, 0.1); rmat.roughness = 0.9
	roof.material_override = rmat; add_child(roof)
	# Door
	var door = MeshInstance3D.new()
	var dm = BoxMesh.new(); dm.size = Vector3(1.2, 2.0, 0.1)
	door.mesh = dm; door.position = Vector3(0, 1.0, 3.05)
	var dmat = StandardMaterial3D.new(); dmat.albedo_color = Color(0.3, 0.18, 0.08)
	door.material_override = dmat; add_child(door)
	# Windows with glow
	for xo in [-1.8, 1.8]:
		var win = MeshInstance3D.new()
		var wm = BoxMesh.new(); wm.size = Vector3(0.8, 0.8, 0.1)
		win.mesh = wm; win.position = Vector3(xo, 2.5, 3.05)
		var wmat = StandardMaterial3D.new(); wmat.albedo_color = Color(0.9, 0.7, 0.3)
		wmat.emission_enabled = true; wmat.emission = Color(0.6, 0.4, 0.1)
		wmat.emission_energy_multiplier = 2.0
		win.material_override = wmat; add_child(win)
	# Flag pole
	var pole = MeshInstance3D.new()
	var pc = CylinderMesh.new(); pc.top_radius = 0.05; pc.bottom_radius = 0.05; pc.height = 3.0
	pole.mesh = pc; pole.position = Vector3(2.5, 5.5, 2.5)
	var pmat = StandardMaterial3D.new(); pmat.albedo_color = Color(0.4, 0.35, 0.25)
	pole.material_override = pmat; add_child(pole)
	var flag = MeshInstance3D.new()
	var fm2 = BoxMesh.new(); fm2.size = Vector3(1.0, 0.6, 0.02)
	flag.mesh = fm2; flag.position = Vector3(3.0, 6.7, 2.5)
	var fmat = StandardMaterial3D.new(); fmat.albedo_color = Color(0.8, 0.2, 0.1)
	flag.material_override = fmat; add_child(flag)

func _create_gate():
	var col = CollisionShape3D.new()
	var box = BoxShape3D.new(); box.size = Vector3(2, 3, 2)
	col.shape = box; col.position.y = 1.5; add_child(col)
	var m = MeshInstance3D.new()
	var bm = BoxMesh.new(); bm.size = Vector3(2, 3, 2)
	m.mesh = bm; m.position.y = 1.5
	var mat = StandardMaterial3D.new(); mat.albedo_color = Color(0.35, 0.3, 0.2); mat.roughness = 0.85
	m.material_override = mat; add_child(m)
	var arch = MeshInstance3D.new()
	var am = BoxMesh.new(); am.size = Vector3(1.0, 2.0, 0.1)
	arch.mesh = am; arch.position = Vector3(0, 1.0, 1.05)
	var amat = StandardMaterial3D.new(); amat.albedo_color = Color(0.25, 0.15, 0.08)
	arch.material_override = amat; add_child(arch)

func _create_lumber_mill():
	var col = CollisionShape3D.new()
	var box = BoxShape3D.new(); box.size = Vector3(6, 4, 6)
	col.shape = box; col.position.y = 2.0; add_child(col)
	var base = MeshInstance3D.new()
	var bm = BoxMesh.new(); bm.size = Vector3(5.5, 3.5, 5.5)
	base.mesh = bm; base.position.y = 1.75
	var mat = StandardMaterial3D.new(); mat.albedo_color = Color(0.4, 0.28, 0.15); mat.roughness = 0.9
	base.material_override = mat; add_child(base)
	# Roof
	var roof = MeshInstance3D.new()
	var rm = BoxMesh.new(); rm.size = Vector3(6.5, 0.4, 6.5)
	roof.mesh = rm; roof.position.y = 3.7
	var rmat = StandardMaterial3D.new(); rmat.albedo_color = Color(0.35, 0.2, 0.08)
	roof.material_override = rmat; add_child(roof)
	# Saw blade decoration
	var saw = MeshInstance3D.new()
	var sc = CylinderMesh.new(); sc.top_radius = 1.0; sc.bottom_radius = 1.0; sc.height = 0.08
	saw.mesh = sc; saw.position = Vector3(0, 4.0, 0); saw.rotation.x = PI/2
	var smat = StandardMaterial3D.new(); smat.albedo_color = Color(0.6, 0.6, 0.65); smat.metallic = 0.6
	saw.material_override = smat; add_child(saw)
	# Log pile
	for i in range(3):
		var log_mesh = MeshInstance3D.new()
		var lc = CylinderMesh.new(); lc.top_radius = 0.25; lc.bottom_radius = 0.25; lc.height = 2.0
		log_mesh.mesh = lc; log_mesh.position = Vector3(-2.0 + i * 0.6, 0.25, -3.5); log_mesh.rotation.z = PI/2
		var lmat = StandardMaterial3D.new(); lmat.albedo_color = Color(0.45, 0.3, 0.12)
		log_mesh.material_override = lmat; add_child(log_mesh)

func _create_farm():
	var col = CollisionShape3D.new()
	var box = BoxShape3D.new(); box.size = Vector3(4, 2, 4)
	col.shape = box; col.position.y = 1.0; add_child(col)
	# Small hut
	var hut = MeshInstance3D.new()
	var hm = BoxMesh.new(); hm.size = Vector3(2, 2, 2)
	hut.mesh = hm; hut.position = Vector3(-1, 1, -1)
	var mat = StandardMaterial3D.new(); mat.albedo_color = Color(0.5, 0.35, 0.2)
	hut.material_override = mat; add_child(hut)
	# Crop field
	var field = MeshInstance3D.new()
	var fm = BoxMesh.new(); fm.size = Vector3(3.5, 0.2, 3.5)
	field.mesh = fm; field.position = Vector3(0.5, 0.1, 0.5)
	var fmat = StandardMaterial3D.new(); fmat.albedo_color = Color(0.35, 0.5, 0.15)
	field.material_override = fmat; add_child(field)
	# Crop rows
	for i in range(4):
		var row = MeshInstance3D.new()
		var rm = BoxMesh.new(); rm.size = Vector3(0.15, 0.4, 3.0)
		row.mesh = rm; row.position = Vector3(-0.5 + i * 0.8, 0.3, 0.5)
		var rmat = StandardMaterial3D.new(); rmat.albedo_color = Color(0.6, 0.7, 0.2)
		row.material_override = rmat; add_child(row)

func _create_barracks():
	var col = CollisionShape3D.new()
	var box = BoxShape3D.new(); box.size = Vector3(6, 4, 6)
	col.shape = box; col.position.y = 2.0; add_child(col)
	var base = MeshInstance3D.new()
	var bm = BoxMesh.new(); bm.size = Vector3(5.5, 3.5, 5.5)
	base.mesh = bm; base.position.y = 1.75
	var mat = StandardMaterial3D.new(); mat.albedo_color = Color(0.4, 0.3, 0.25); mat.roughness = 0.85
	base.material_override = mat; add_child(base)
	var roof = MeshInstance3D.new()
	var rm = CylinderMesh.new(); rm.top_radius = 0.5; rm.bottom_radius = 4.2; rm.height = 2.0
	roof.mesh = rm; roof.position.y = 4.5
	var rmat = StandardMaterial3D.new(); rmat.albedo_color = Color(0.45, 0.15, 0.08)
	roof.material_override = rmat; add_child(roof)
	# Banner
	var banner = MeshInstance3D.new()
	var bnm = BoxMesh.new(); bnm.size = Vector3(0.8, 1.2, 0.02)
	banner.mesh = bnm; banner.position = Vector3(0, 2.5, 2.8)
	var bmat = StandardMaterial3D.new(); bmat.albedo_color = Color(0.7, 0.15, 0.1)
	banner.material_override = bmat; add_child(banner)

func _create_blacksmith():
	var col = CollisionShape3D.new()
	var box = BoxShape3D.new(); box.size = Vector3(4, 3.5, 4)
	col.shape = box; col.position.y = 1.75; add_child(col)
	var base = MeshInstance3D.new()
	var bm = BoxMesh.new(); bm.size = Vector3(3.8, 3, 3.8)
	base.mesh = bm; base.position.y = 1.5
	var mat = StandardMaterial3D.new(); mat.albedo_color = Color(0.3, 0.25, 0.22); mat.roughness = 0.85
	base.material_override = mat; add_child(base)
	# Chimney
	var chimney = MeshInstance3D.new()
	var cm = CylinderMesh.new(); cm.top_radius = 0.3; cm.bottom_radius = 0.4; cm.height = 2.0
	chimney.mesh = cm; chimney.position = Vector3(1.2, 4.0, -1.0)
	var cmat = StandardMaterial3D.new(); cmat.albedo_color = Color(0.35, 0.3, 0.28)
	chimney.material_override = cmat; add_child(chimney)
	# Anvil
	var anvil = MeshInstance3D.new()
	var am = BoxMesh.new(); am.size = Vector3(0.6, 0.4, 0.4)
	anvil.mesh = am; anvil.position = Vector3(-0.5, 0.2, 2.2)
	var amat = StandardMaterial3D.new(); amat.albedo_color = Color(0.4, 0.4, 0.45); amat.metallic = 0.7
	anvil.material_override = amat; add_child(anvil)
	# Forge glow
	var forge = MeshInstance3D.new()
	var fmesh = BoxMesh.new(); fmesh.size = Vector3(1.0, 0.8, 1.0)
	forge.mesh = fmesh; forge.position = Vector3(1.0, 0.4, 0)
	var fmat = StandardMaterial3D.new(); fmat.albedo_color = Color(0.8, 0.3, 0.05)
	fmat.emission_enabled = true; fmat.emission = Color(0.9, 0.3, 0.05)
	fmat.emission_energy_multiplier = 3.0
	forge.material_override = fmat; add_child(forge)

func _create_hp_bar():
	var fp = BuildingManager.get_footprint(building_type)
	var bar_h = 3.0 if fp.size() <= 1 else (5.0 if fp.size() <= 4 else 6.5)
	hp_bar_pivot = Node3D.new(); hp_bar_pivot.position.y = bar_h
	hp_bar_pivot.visible = true; add_child(hp_bar_pivot)
	var bg = MeshInstance3D.new(); bg.mesh = BoxMesh.new(); bg.mesh.size = Vector3(1.2,0.1,0.02)
	var bgm = StandardMaterial3D.new(); bgm.albedo_color = Color(0.15,0,0); bgm.no_depth_test = true
	bg.material_override = bgm; hp_bar_pivot.add_child(bg)
	hp_bar_fill = MeshInstance3D.new(); hp_bar_fill.mesh = BoxMesh.new()
	hp_bar_fill.mesh.size = Vector3(1.1,0.07,0.03)
	var fm = StandardMaterial3D.new(); fm.albedo_color = Color(0.1,0.9,0.1); fm.no_depth_test = true
	hp_bar_fill.material_override = fm; hp_bar_pivot.add_child(hp_bar_fill)
