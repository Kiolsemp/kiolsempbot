## Building placement ghost preview
## Shows footprint: green (valid) / red (occupied) / yellow (tree - chop first!)
extends Node3D

var current_type: int = BuildingManager.BuildingType.NONE
var ghost_meshes: Array[MeshInstance3D] = []
var material_valid: StandardMaterial3D
var material_invalid: StandardMaterial3D
var material_tree_blocked: StandardMaterial3D
var is_valid: bool = false
var grid_center: Vector2i = Vector2i.ZERO

func _ready():
	visible = false

	material_valid = StandardMaterial3D.new()
	material_valid.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	material_valid.albedo_color = Color(0.2, 1.0, 0.2, 0.35)
	material_valid.no_depth_test = true
	material_valid.cull_mode = BaseMaterial3D.CULL_DISABLED

	material_invalid = StandardMaterial3D.new()
	material_invalid.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	material_invalid.albedo_color = Color(1.0, 0.2, 0.2, 0.35)
	material_invalid.no_depth_test = true
	material_invalid.cull_mode = BaseMaterial3D.CULL_DISABLED

	material_tree_blocked = StandardMaterial3D.new()
	material_tree_blocked.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	material_tree_blocked.albedo_color = Color(1.0, 0.8, 0.1, 0.35)
	material_tree_blocked.no_depth_test = true
	material_tree_blocked.cull_mode = BaseMaterial3D.CULL_DISABLED

func show_ghost(type: int):
	current_type = type
	visible = true
	_rebuild_ghost()

func hide_ghost():
	visible = false
	current_type = BuildingManager.BuildingType.NONE
	for m in ghost_meshes:
		m.queue_free()
	ghost_meshes.clear()

func _rebuild_ghost():
	for m in ghost_meshes:
		m.queue_free()
	ghost_meshes.clear()

	var footprint = BuildingManager.get_footprint(current_type)
	var gs = GameState.grid_size

	var height = 3.0
	match current_type:
		BuildingManager.BuildingType.TOWER: height = 5.0
		BuildingManager.BuildingType.LUMBER_MILL: height = 3.5
		BuildingManager.BuildingType.BARRACKS: height = 4.0
		BuildingManager.BuildingType.FARM: height = 2.5
		BuildingManager.BuildingType.BLACKSMITH: height = 3.0
		BuildingManager.BuildingType.GATE: height = 3.5
		BuildingManager.BuildingType.TOWN_HALL: height = 5.0

	for cell_offset in footprint:
		var m = MeshInstance3D.new()
		var box = BoxMesh.new()
		box.size = Vector3(gs * 0.95, height, gs * 0.95)
		m.mesh = box
		m.position = Vector3(cell_offset.x * gs, height / 2.0, cell_offset.y * gs)
		m.material_override = material_valid
		add_child(m)
		ghost_meshes.append(m)

func update_position(world_pos: Vector3):
	if not visible:
		return
	var build_pos = GameState.get_grid_pos(world_pos)
	position = build_pos
	grid_center = GameState.world_to_grid(world_pos)

	is_valid = BuildingManager.can_place_at(grid_center, current_type)

	# Color cells individually
	var footprint = BuildingManager.get_footprint(current_type)
	for i in range(mini(ghost_meshes.size(), footprint.size())):
		var cell = grid_center + footprint[i]
		if BuildingManager.occupied_cells.has(cell):
			ghost_meshes[i].material_override = material_invalid
		elif BuildingManager.tree_cells.has(cell):
			ghost_meshes[i].material_override = material_tree_blocked
		elif not GameState.is_within_map(GameState.grid_to_world(cell)):
			ghost_meshes[i].material_override = material_invalid
		else:
			ghost_meshes[i].material_override = material_valid
