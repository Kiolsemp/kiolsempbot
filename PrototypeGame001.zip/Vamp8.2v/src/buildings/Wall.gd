## Wall v7 - 1x1 defensive building with night light, selection ring
extends StaticBody3D

var max_health: int = 400
var current_health: int = 400
var building_type: int = BuildingManager.BuildingType.WALL
var grid_center: Vector2i = Vector2i.ZERO
var upgrade_level: int = 0
var max_upgrade: int = 3
var is_selected: bool = false

var hp_bar_pivot: Node3D
var hp_bar_fill: MeshInstance3D
var main_mesh: MeshInstance3D
var selection_ring: MeshInstance3D
var night_light: OmniLight3D

func _ready():
	max_health = BuildingManager.building_hp[building_type]
	current_health = max_health
	collision_layer = 4
	collision_mask = 0

	var col = CollisionShape3D.new()
	var box = BoxShape3D.new()
	box.size = Vector3(1.9, 3.0, 1.9)
	col.shape = box
	col.position.y = 1.5
	add_child(col)

	main_mesh = MeshInstance3D.new()
	var bm = BoxMesh.new()
	bm.size = Vector3(1.9, 3.0, 1.9)
	main_mesh.mesh = bm
	main_mesh.position.y = 1.5
	var mat = StandardMaterial3D.new()
	mat.albedo_color = Color(0.5, 0.45, 0.38)
	mat.roughness = 0.95
	main_mesh.material_override = mat
	add_child(main_mesh)

	for h in [0.8, 1.6, 2.4]:
		var line = MeshInstance3D.new()
		var lm = BoxMesh.new()
		lm.size = Vector3(1.95, 0.05, 1.95)
		line.mesh = lm
		line.position.y = h
		var lmat = StandardMaterial3D.new()
		lmat.albedo_color = Color(0.38, 0.35, 0.3)
		line.material_override = lmat
		add_child(line)

	for i in range(4):
		var m = MeshInstance3D.new()
		var mb = BoxMesh.new()
		mb.size = Vector3(0.5, 0.5, 0.5)
		m.mesh = mb
		var angle = i * PI / 2.0
		m.position = Vector3(cos(angle) * 0.65, 3.25, sin(angle) * 0.65)
		m.material_override = main_mesh.material_override
		add_child(m)

	_create_selection_ring()
	_create_hp_bar()
	_create_night_light()

func _create_selection_ring():
	selection_ring = MeshInstance3D.new()
	var torus = TorusMesh.new()
	var ring_r = BuildingManager.get_building_radius(building_type)
	torus.inner_radius = ring_r
	torus.outer_radius = ring_r + 0.3
	torus.rings = 20
	torus.ring_segments = 20
	selection_ring.mesh = torus
	selection_ring.position.y = 0.05
	var rmat = StandardMaterial3D.new()
	rmat.albedo_color = Color(0.2, 0.8, 1.0, 0.6)
	rmat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	rmat.emission_enabled = true
	rmat.emission = Color(0.2, 0.7, 1.0)
	rmat.emission_energy_multiplier = 2.5
	rmat.no_depth_test = true
	selection_ring.material_override = rmat
	selection_ring.visible = false
	add_child(selection_ring)

func _create_hp_bar():
	hp_bar_pivot = Node3D.new()
	hp_bar_pivot.position.y = 3.8
	hp_bar_pivot.visible = false
	add_child(hp_bar_pivot)
	var bg = MeshInstance3D.new()
	bg.mesh = BoxMesh.new()
	bg.mesh.size = Vector3(1.0, 0.1, 0.02)
	var bgm = StandardMaterial3D.new()
	bgm.albedo_color = Color(0.15, 0, 0)
	bgm.no_depth_test = true
	bg.material_override = bgm
	hp_bar_pivot.add_child(bg)
	hp_bar_fill = MeshInstance3D.new()
	hp_bar_fill.mesh = BoxMesh.new()
	hp_bar_fill.mesh.size = Vector3(0.9, 0.07, 0.03)
	var fm = StandardMaterial3D.new()
	fm.albedo_color = Color(0.1, 0.9, 0.1)
	fm.no_depth_test = true
	hp_bar_fill.material_override = fm
	hp_bar_pivot.add_child(hp_bar_fill)

var _wall_timer: float = 0.0
func _process(_d: float):
	if hp_bar_pivot and hp_bar_pivot.visible:
		var cam = get_viewport().get_camera_3d()
		if cam:
			var dsq = hp_bar_pivot.global_position.distance_squared_to(cam.global_position)
			if dsq < 2500.0 and dsq > 0.1:
				hp_bar_pivot.look_at(cam.global_position, Vector3.UP)
	_wall_timer += _d
	if _wall_timer >= 0.5:
		_wall_timer = 0.0
		if night_light:
			night_light.light_energy = 2.5 if GameClock.is_nighttime() else 1.0

func _create_night_light():
	night_light = OmniLight3D.new()
	night_light.light_color = Color(1.0, 0.85, 0.55)
	night_light.light_energy = 0.6
	night_light.omni_range = 33.0
	night_light.omni_attenuation = 0.7
	night_light.shadow_enabled = false
	night_light.position.y = 3.5
	add_child(night_light)

func set_selected(val: bool):
	is_selected = val
	selection_ring.visible = val
	hp_bar_pivot.visible = val or current_health < max_health

func upgrade() -> bool:
	if upgrade_level >= max_upgrade:
		return false
	var cost_w = 20 + upgrade_level * 10
	var cost_g = 10 + upgrade_level * 5
	if not ResourceManager.can_afford(cost_w, cost_g):
		return false
	ResourceManager.spend(cost_w, cost_g)
	upgrade_level += 1
	if SoundManager: SoundManager.play_sound("upgrade", -6.0)
	max_health += 150
	current_health += 150
	main_mesh.scale.y = 1.0 + upgrade_level * 0.2
	main_mesh.position.y = 1.5 * (1.0 + upgrade_level * 0.2)
	return true

func get_upgrade_cost() -> Array:
	return [20 + upgrade_level * 10, 10 + upgrade_level * 5]

func take_damage(amount: int):
	current_health -= amount
	current_health = max(0, current_health)
	hp_bar_pivot.visible = true
	_update_hp()
	var mat = main_mesh.material_override as StandardMaterial3D
	var orig = Color(0.5, 0.45, 0.38)
	mat.albedo_color = Color(1, 0.3, 0.3)
	var tw = create_tween()
	tw.tween_property(mat, "albedo_color", orig, 0.25)
	if current_health <= 0:
		BuildingManager.free_cells(grid_center, building_type)
		GameState.on_building_destroyed()
		var dtw = create_tween()
		dtw.tween_property(self, "scale:y", 0.0, 0.4)
		dtw.tween_callback(queue_free)

func _update_hp():
	if hp_bar_fill:
		var r = float(current_health) / float(max_health)
		hp_bar_fill.scale.x = r
		hp_bar_fill.position.x = (r - 1.0) * 0.45
