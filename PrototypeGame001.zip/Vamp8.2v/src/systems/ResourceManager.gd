extends Node

signal resources_changed(lumber: int, gold: int)
signal not_enough_resources(resource_type: String)

var lumber: int = 200
var gold: int = 150
var gold_income_rate: float = 2.0
var income_timer: float = 0.0
var income_interval: float = 10.0

# Income tracking
var lumber_gained_last_min: int = 0
var gold_gained_last_min: int = 0
var lumber_gain_buffer: int = 0
var gold_gain_buffer: int = 0
var income_track_timer: float = 0.0

func _ready():
	lumber = GameState.starting_lumber
	gold = GameState.starting_gold

func _process(delta: float):
	if GameState.current_phase == GameState.GamePhase.GAME_OVER:
		return
	if GameState.current_phase == GameState.GamePhase.LOBBY:
		return
	income_timer += delta
	if income_timer >= income_interval:
		income_timer -= income_interval
		add_gold(int(gold_income_rate))
	# Track income per minute (update every 30s)
	income_track_timer += delta
	if income_track_timer >= 30.0:
		income_track_timer = 0.0
		lumber_gained_last_min = lumber_gain_buffer * 2  # Extrapolate to per-minute
		gold_gained_last_min = gold_gain_buffer * 2
		lumber_gain_buffer = 0
		gold_gain_buffer = 0

func add_lumber(amount: int):
	lumber += amount
	lumber_gain_buffer += amount
	resources_changed.emit(lumber, gold)

func add_gold(amount: int):
	gold += amount
	gold_gain_buffer += amount
	resources_changed.emit(lumber, gold)

func spend(lumber_cost: int, gold_cost: int) -> bool:
	if lumber < lumber_cost:
		not_enough_resources.emit("lumber")
		return false
	if gold < gold_cost:
		not_enough_resources.emit("gold")
		return false
	lumber -= lumber_cost
	gold -= gold_cost
	resources_changed.emit(lumber, gold)
	return true

func can_afford(lumber_cost: int, gold_cost: int) -> bool:
	return lumber >= lumber_cost and gold >= gold_cost

func refund(lumber_amount: int, gold_amount: int):
	lumber += int(lumber_amount * 0.75)
	gold += int(gold_amount * 0.75)
	resources_changed.emit(lumber, gold)
