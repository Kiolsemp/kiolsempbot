## NetworkManager - Handles multiplayer connections, lobby, and RPC routing
## 8 Humans vs 1 Vampire - LAN/Online multiplayer
extends Node

signal player_joined(peer_id: int, info: Dictionary)
signal player_left(peer_id: int)
signal lobby_updated()
signal game_started()
signal chat_message(sender: String, text: String)

enum Role { HUMAN = 0, VAMPIRE = 1 }
enum NetState { OFFLINE, HOSTING, JOINING, LOBBY, IN_GAME }

var state: int = NetState.OFFLINE
var peer: ENetMultiplayerPeer = null
var game_port: int = 7777
var max_players: int = 9  # 8 humans + 1 vampire

# Player registry: peer_id -> { name, role, slot, color, alive }
var players: Dictionary = {}
var local_peer_id: int = 0
var local_player_name: String = "Player"
var is_host: bool = false

# Game config (host sets these)
var game_seed: int = 0
var nights_to_survive: int = 10
var map_size_setting: float = 400.0

# Spawn slots - 8 positions around the circle for humans
var human_spawn_angles: Array = []
var vampire_slot_id: int = -1  # peer_id of vampire player

# Player colors for teams
var team_colors: Array[Color] = [
	Color(0.2, 0.6, 1.0),   # Blue
	Color(1.0, 0.3, 0.3),   # Red
	Color(0.2, 0.9, 0.3),   # Green
	Color(1.0, 0.85, 0.2),  # Yellow
	Color(0.8, 0.3, 0.9),   # Purple
	Color(1.0, 0.5, 0.1),   # Orange
	Color(0.1, 0.9, 0.9),   # Cyan
	Color(0.9, 0.5, 0.7),   # Pink
]

func _ready():
	multiplayer.peer_connected.connect(_on_peer_connected)
	multiplayer.peer_disconnected.connect(_on_peer_disconnected)
	multiplayer.connected_to_server.connect(_on_connected_to_server)
	multiplayer.connection_failed.connect(_on_connection_failed)
	multiplayer.server_disconnected.connect(_on_server_disconnected)
	# Calculate spawn angles
	for i in range(8):
		human_spawn_angles.append(i * TAU / 8.0)

func is_multiplayer() -> bool:
	return state == NetState.IN_GAME or state == NetState.LOBBY

func is_singleplayer() -> bool:
	return state == NetState.OFFLINE

func get_local_role() -> int:
	if local_peer_id in players:
		return players[local_peer_id].role
	return Role.HUMAN

func get_local_slot() -> int:
	if local_peer_id in players:
		return players[local_peer_id].slot
	return 0

func get_player_count() -> int:
	return players.size()

func get_human_count() -> int:
	var c = 0
	for p in players.values():
		if p.role == Role.HUMAN: c += 1
	return c

func get_vampire_player_id() -> int:
	return vampire_slot_id

## ====== HOST/JOIN ======

func host_game(player_name: String, port: int = 7777):
	local_player_name = player_name
	peer = ENetMultiplayerPeer.new()
	var err = peer.create_server(port, max_players)
	if err != OK:
		push_error("Failed to create server on port %d: %s" % [port, error_string(err)])
		return false
	multiplayer.multiplayer_peer = peer
	is_host = true
	state = NetState.LOBBY
	local_peer_id = 1
	# Register host as first player
	_register_local_player()
	lobby_updated.emit()
	return true

func join_game(player_name: String, ip: String, port: int = 7777):
	local_player_name = player_name
	peer = ENetMultiplayerPeer.new()
	var err = peer.create_client(ip, port)
	if err != OK:
		push_error("Failed to connect to %s:%d: %s" % [ip, port, error_string(err)])
		return false
	multiplayer.multiplayer_peer = peer
	is_host = false
	state = NetState.JOINING
	return true

func disconnect_game():
	if peer:
		multiplayer.multiplayer_peer = null
		peer = null
	players.clear()
	state = NetState.OFFLINE
	is_host = false
	vampire_slot_id = -1
	lobby_updated.emit()

func _register_local_player():
	var slot = _next_free_slot()
	players[local_peer_id] = {
		"name": local_player_name,
		"role": Role.HUMAN,
		"slot": slot,
		"color": team_colors[slot % team_colors.size()],
		"alive": true
	}

func _next_free_slot() -> int:
	var used = []
	for p in players.values():
		used.append(p.slot)
	for i in range(8):
		if i not in used: return i
	return 0

## ====== CALLBACKS ======

func _on_peer_connected(id: int):
	if is_host:
		# Send current lobby state to new player
		rpc_id(id, "_receive_lobby_state", _serialize_lobby())

func _on_peer_disconnected(id: int):
	if id in players:
		if players[id].role == Role.VAMPIRE:
			vampire_slot_id = -1
		players.erase(id)
		player_left.emit(id)
		lobby_updated.emit()
		if is_host and state == NetState.LOBBY:
			_broadcast_lobby_state()

func _on_connected_to_server():
	local_peer_id = multiplayer.get_unique_id()
	state = NetState.LOBBY
	# Tell host our name
	rpc_id(1, "_register_remote_player", local_player_name)

func _on_connection_failed():
	state = NetState.OFFLINE
	push_error("Connection failed")

func _on_server_disconnected():
	state = NetState.OFFLINE
	players.clear()
	lobby_updated.emit()

## ====== RPCs - LOBBY ======

@rpc("any_peer", "reliable")
func _register_remote_player(p_name: String):
	var sender = multiplayer.get_remote_sender_id()
	if not is_host: return
	if players.size() >= max_players: return
	var slot = _next_free_slot()
	players[sender] = {
		"name": p_name,
		"role": Role.HUMAN,
		"slot": slot,
		"color": team_colors[slot % team_colors.size()],
		"alive": true
	}
	player_joined.emit(sender, players[sender])
	_broadcast_lobby_state()

@rpc("authority", "reliable")
func _receive_lobby_state(data: Dictionary):
	players.clear()
	for key_str in data.players.keys():
		var pid = int(key_str)
		players[pid] = data.players[key_str]
		# Restore Color from array
		if "color" in players[pid] and players[pid].color is Array:
			var c = players[pid].color
			players[pid].color = Color(c[0], c[1], c[2])
	vampire_slot_id = data.vampire_id
	nights_to_survive = data.nights
	lobby_updated.emit()

func _serialize_lobby() -> Dictionary:
	var ser_players = {}
	for pid in players:
		var p = players[pid].duplicate()
		p.color = [p.color.r, p.color.g, p.color.b]
		ser_players[str(pid)] = p
	return {
		"players": ser_players,
		"vampire_id": vampire_slot_id,
		"nights": nights_to_survive
	}

func _broadcast_lobby_state():
	if not is_host: return
	var data = _serialize_lobby()
	rpc("_receive_lobby_state", data)
	lobby_updated.emit()

## ====== ROLE MANAGEMENT ======

func toggle_vampire_role(peer_id: int):
	if not is_host: return
	if peer_id not in players: return
	if vampire_slot_id == peer_id:
		# Unset vampire
		players[peer_id].role = Role.HUMAN
		vampire_slot_id = -1
	elif vampire_slot_id == -1:
		# Set as vampire
		players[peer_id].role = Role.VAMPIRE
		vampire_slot_id = peer_id
	_broadcast_lobby_state()

func request_vampire_role():
	if is_host:
		toggle_vampire_role(local_peer_id)
	else:
		rpc_id(1, "_request_role_change")

@rpc("any_peer", "reliable")
func _request_role_change():
	if not is_host: return
	var sender = multiplayer.get_remote_sender_id()
	toggle_vampire_role(sender)

## ====== GAME START ======

func start_multiplayer_game():
	if not is_host: return
	if vampire_slot_id == -1:
		# No vampire assigned - pick last player
		var last_pid = players.keys().back()
		players[last_pid].role = Role.VAMPIRE
		vampire_slot_id = last_pid
	# Generate shared seed
	game_seed = randi()
	state = NetState.IN_GAME
	# Reassign human slots to be sequential 0,1,2...
	var human_idx = 0
	for pid in players:
		if players[pid].role == Role.HUMAN:
			players[pid].slot = human_idx
			players[pid].color = team_colors[human_idx % team_colors.size()]
			human_idx += 1
	# Broadcast game start to all
	var start_data = _serialize_lobby()
	start_data["seed"] = game_seed
	start_data["nights"] = nights_to_survive
	rpc("_receive_game_start", start_data)
	_receive_game_start(start_data)

@rpc("authority", "reliable")
func _receive_game_start(data: Dictionary):
	# Restore player data
	players.clear()
	for key_str in data.players.keys():
		var pid = int(key_str)
		players[pid] = data.players[key_str]
		if "color" in players[pid] and players[pid].color is Array:
			var c = players[pid].color
			players[pid].color = Color(c[0], c[1], c[2])
	vampire_slot_id = data.vampire_id
	game_seed = data.seed
	nights_to_survive = data.nights
	state = NetState.IN_GAME
	game_started.emit()

## ====== IN-GAME RPCs ======

## Get spawn position for a human player slot
func get_human_spawn_position(slot: int) -> Vector3:
	var angle = human_spawn_angles[slot % human_spawn_angles.size()]
	var radius = 60.0
	return Vector3(cos(angle) * radius, 1, sin(angle) * radius)

## ====== GAME COMMAND RPCs ======

@rpc("any_peer", "reliable")
func rpc_place_building(peer_id: int, pos_x: float, pos_z: float, type: int, grid_x: int, grid_z: int):
	# Relay to all peers - each executes locally
	if is_host:
		rpc("_exec_place_building", peer_id, pos_x, pos_z, type, grid_x, grid_z)
		_exec_place_building(peer_id, pos_x, pos_z, type, grid_x, grid_z)

@rpc("authority", "reliable")
func _exec_place_building(peer_id: int, pos_x: float, pos_z: float, type: int, grid_x: int, grid_z: int):
	var main = get_tree().current_scene
	if main and main.has_method("net_place_building"):
		main.net_place_building(peer_id, Vector3(pos_x, 0, pos_z), type, Vector2i(grid_x, grid_z))

@rpc("any_peer", "reliable")
func rpc_move_units(peer_id: int, unit_ids: Array, target_x: float, target_z: float):
	if is_host:
		rpc("_exec_move_units", peer_id, unit_ids, target_x, target_z)
		_exec_move_units(peer_id, unit_ids, target_x, target_z)

@rpc("authority", "reliable")
func _exec_move_units(_peer_id: int, _unit_ids: Array, _target_x: float, _target_z: float):
	pass  # Units move locally for now

@rpc("any_peer", "reliable")
func rpc_train_unit(peer_id: int, building_pos_x: float, building_pos_z: float, unit_type: String):
	if is_host:
		rpc("_exec_train_unit", peer_id, building_pos_x, building_pos_z, unit_type)
		_exec_train_unit(peer_id, building_pos_x, building_pos_z, unit_type)

@rpc("authority", "reliable")
func _exec_train_unit(peer_id: int, bpos_x: float, bpos_z: float, unit_type: String):
	var main = get_tree().current_scene
	if main and main.has_method("net_train_unit"):
		main.net_train_unit(peer_id, Vector3(bpos_x, 0, bpos_z), unit_type)

@rpc("any_peer", "reliable")
func rpc_chat(text: String):
	var sender = multiplayer.get_remote_sender_id()
	var name_str = players[sender].name if sender in players else "???"
	if is_host:
		rpc("_exec_chat", name_str, text)
		_exec_chat(name_str, text)

@rpc("authority", "reliable")
func _exec_chat(sender_name: String, text: String):
	chat_message.emit(sender_name, text)

## Sync game clock from host periodically
var clock_sync_timer: float = 0.0
func _process(delta: float):
	if state != NetState.IN_GAME: return
	if not is_host: return
	clock_sync_timer += delta
	if clock_sync_timer >= 2.0:
		clock_sync_timer = 0.0
		rpc("_sync_clock", GameClock.time_of_day, GameClock.day_number,
			GameState.current_phase, GameState.night_count)

@rpc("authority", "unreliable")
func _sync_clock(time_of_day: float, day_num: int, phase: int, nights: int):
	GameClock.time_of_day = time_of_day
	GameClock.day_number = day_num
	if GameState.current_phase != phase:
		GameState.set_phase(phase)
	GameState.night_count = nights

@rpc("any_peer", "reliable")
func rpc_player_eliminated(peer_id: int):
	if peer_id in players:
		players[peer_id].alive = false
	# Check if all humans dead
	var humans_alive = 0
	for p in players.values():
		if p.role == Role.HUMAN and p.alive: humans_alive += 1
	if humans_alive == 0:
		if get_local_role() == Role.HUMAN:
			GameState.trigger_defeat()
		else:
			GameState.trigger_victory()

## ====== POSITION SYNC ======
var pos_sync_timer: float = 0.0

func sync_hero_position(pos: Vector3, hp: int):
	if state != NetState.IN_GAME: return
	rpc("_recv_hero_pos", local_peer_id, pos.x, pos.z, hp)

@rpc("any_peer", "unreliable")
func _recv_hero_pos(peer_id: int, px: float, pz: float, hp: int):
	var main = get_tree().current_scene
	if main and main.has_method("net_update_hero_pos"):
		main.net_update_hero_pos(peer_id, Vector3(px, 0, pz), hp)

func sync_vampire_position(pos: Vector3, hp: int):
	if state != NetState.IN_GAME: return
	rpc("_recv_vamp_pos", pos.x, pos.z, hp)

@rpc("any_peer", "unreliable")
func _recv_vamp_pos(px: float, pz: float, hp: int):
	var main = get_tree().current_scene
	if main and main.has_method("net_update_vampire_pos"):
		main.net_update_vampire_pos(Vector3(px, 0, pz), hp)

@rpc("any_peer", "reliable")
func rpc_vampire_attack_building(bx: float, bz: float, damage: int):
	if is_host:
		rpc("_exec_vamp_attack_bld", bx, bz, damage)
		_exec_vamp_attack_bld(bx, bz, damage)

@rpc("authority", "reliable")
func _exec_vamp_attack_bld(bx: float, bz: float, damage: int):
	var main = get_tree().current_scene
	if main and main.has_method("net_vampire_attack_building"):
		main.net_vampire_attack_building(Vector3(bx, 0, bz), damage)
