## SoundManager - Procedural sound effects for VampBeast
extends Node

var audio_players: Array[AudioStreamPlayer] = []
var max_players: int = 8
var sound_enabled: bool = true

func _ready():
	for i in range(max_players):
		var player = AudioStreamPlayer.new()
		player.bus = "Master"
		player.volume_db = -6.0
		add_child(player)
		audio_players.append(player)

func _get_free_player() -> AudioStreamPlayer:
	for p in audio_players:
		if not p.playing: return p
	return audio_players[0]  # Steal oldest if all busy

func play_sound(sound_name: String, volume_db: float = -6.0):
	if not sound_enabled: return
	var player = _get_free_player()
	player.volume_db = volume_db
	var stream = _generate_sound(sound_name)
	if stream:
		player.stream = stream
		player.play()

func _generate_sound(sound_name: String) -> AudioStream:
	match sound_name:
		"chop": return _gen_noise_burst(0.08, 800.0, 200.0)
		"build": return _gen_tone_sweep(0.15, 300.0, 600.0)
		"build_complete": return _gen_tone_sweep(0.3, 400.0, 800.0)
		"select": return _gen_click(0.04, 1200.0)
		"train": return _gen_tone_sweep(0.2, 500.0, 700.0)
		"attack_hit": return _gen_noise_burst(0.06, 400.0, 100.0)
		"sword_swing": return _gen_noise_burst(0.1, 1200.0, 400.0)
		"vampire_growl": return _gen_growl(0.4)
		"death": return _gen_tone_sweep(0.3, 400.0, 100.0)
		"transform": return _gen_transform(0.6)
		"night_warning": return _gen_tone_sweep(0.5, 200.0, 150.0)
		"resource_gain": return _gen_click(0.05, 1800.0)
		"error": return _gen_tone_sweep(0.15, 400.0, 200.0)
		"tower_shoot": return _gen_noise_burst(0.05, 2000.0, 800.0)
		"upgrade": return _gen_tone_sweep(0.4, 300.0, 900.0)
		"place_building": return _gen_noise_burst(0.12, 300.0, 150.0)
		_: return _gen_click(0.03, 1000.0)

## Generate a short noise burst (impacts, chopping)
func _gen_noise_burst(duration: float, freq: float, freq_end: float) -> AudioStreamWAV:
	var rate = 22050
	var samples = int(duration * rate)
	var data = PackedByteArray()
	data.resize(samples * 2)
	var rng = RandomNumberGenerator.new()
	rng.randomize()
	for i in range(samples):
		var t = float(i) / float(rate)
		var env = 1.0 - float(i) / float(samples)  # Linear decay
		env = env * env  # Squared for sharper decay
		var f = lerp(freq, freq_end, float(i) / float(samples))
		var sample = sin(t * f * TAU) * 0.5 + rng.randf_range(-0.5, 0.5) * 0.5
		sample *= env * 0.8
		var val = clampi(int(sample * 32000), -32768, 32767)
		data[i * 2] = val & 0xFF
		data[i * 2 + 1] = (val >> 8) & 0xFF
	var stream = AudioStreamWAV.new()
	stream.format = AudioStreamWAV.FORMAT_16_BITS
	stream.mix_rate = rate
	stream.data = data
	return stream

## Generate a clean tone sweep (UI, upgrades)
func _gen_tone_sweep(duration: float, freq_start: float, freq_end: float) -> AudioStreamWAV:
	var rate = 22050
	var samples = int(duration * rate)
	var data = PackedByteArray()
	data.resize(samples * 2)
	for i in range(samples):
		var t = float(i) / float(rate)
		var p = float(i) / float(samples)
		var env = sin(p * PI)  # Smooth fade in/out
		var f = lerp(freq_start, freq_end, p)
		var sample = sin(t * f * TAU) * env * 0.6
		var val = clampi(int(sample * 32000), -32768, 32767)
		data[i * 2] = val & 0xFF
		data[i * 2 + 1] = (val >> 8) & 0xFF
	var stream = AudioStreamWAV.new()
	stream.format = AudioStreamWAV.FORMAT_16_BITS
	stream.mix_rate = rate
	stream.data = data
	return stream

## Generate a click sound (select, UI)
func _gen_click(duration: float, freq: float) -> AudioStreamWAV:
	var rate = 22050
	var samples = int(duration * rate)
	var data = PackedByteArray()
	data.resize(samples * 2)
	for i in range(samples):
		var t = float(i) / float(rate)
		var env = 1.0 - float(i) / float(samples)
		env = pow(env, 4.0)
		var sample = sin(t * freq * TAU) * env * 0.7
		var val = clampi(int(sample * 32000), -32768, 32767)
		data[i * 2] = val & 0xFF
		data[i * 2 + 1] = (val >> 8) & 0xFF
	var stream = AudioStreamWAV.new()
	stream.format = AudioStreamWAV.FORMAT_16_BITS
	stream.mix_rate = rate
	stream.data = data
	return stream

## Generate a menacing growl (vampire)
func _gen_growl(duration: float) -> AudioStreamWAV:
	var rate = 22050
	var samples = int(duration * rate)
	var data = PackedByteArray()
	data.resize(samples * 2)
	var rng = RandomNumberGenerator.new()
	rng.randomize()
	for i in range(samples):
		var t = float(i) / float(rate)
		var p = float(i) / float(samples)
		var env = sin(p * PI) * (1.0 - p * 0.3)
		var base = sin(t * 80.0 * TAU) * 0.4
		var harm = sin(t * 160.0 * TAU) * 0.2
		var noise = rng.randf_range(-0.3, 0.3) * (1.0 - p)
		var vibrato = sin(t * 5.0 * TAU) * 0.15
		var sample = (base + harm + noise) * env + vibrato * env * 0.3
		sample *= 0.7
		var val = clampi(int(sample * 32000), -32768, 32767)
		data[i * 2] = val & 0xFF
		data[i * 2 + 1] = (val >> 8) & 0xFF
	var stream = AudioStreamWAV.new()
	stream.format = AudioStreamWAV.FORMAT_16_BITS
	stream.mix_rate = rate
	stream.data = data
	return stream

## Generate transformation sound (eerie rising)
func _gen_transform(duration: float) -> AudioStreamWAV:
	var rate = 22050
	var samples = int(duration * rate)
	var data = PackedByteArray()
	data.resize(samples * 2)
	var rng = RandomNumberGenerator.new()
	rng.randomize()
	for i in range(samples):
		var t = float(i) / float(rate)
		var p = float(i) / float(samples)
		var env = sin(p * PI)
		var freq = lerp(100.0, 600.0, p * p)
		var base = sin(t * freq * TAU) * 0.3
		var harm1 = sin(t * freq * 1.5 * TAU) * 0.15
		var harm2 = sin(t * freq * 2.0 * TAU) * 0.1
		var noise = rng.randf_range(-0.2, 0.2) * (1.0 - p)
		var sample = (base + harm1 + harm2 + noise) * env * 0.8
		var val = clampi(int(sample * 32000), -32768, 32767)
		data[i * 2] = val & 0xFF
		data[i * 2 + 1] = (val >> 8) & 0xFF
	var stream = AudioStreamWAV.new()
	stream.format = AudioStreamWAV.FORMAT_16_BITS
	stream.mix_rate = rate
	stream.data = data
	return stream

## ===== AMBIENT MUSIC =====
var music_player: AudioStreamPlayer
var music_enabled: bool = true
var current_music: String = ""

func start_ambient_music():
	if music_player: return
	music_player = AudioStreamPlayer.new()
	music_player.bus = "Master"
	music_player.volume_db = -18.0
	add_child(music_player)
	_play_day_music()

func _process(_delta: float):
	if not music_player: return
	if not music_player.playing:
		if GameClock.is_nighttime():
			_play_night_music()
		else:
			_play_day_music()

func _play_day_music():
	if current_music == "day": return
	current_music = "day"
	music_player.stream = _gen_ambient_day()
	music_player.play()

func _play_night_music():
	if current_music == "night": return
	current_music = "night"
	music_player.stream = _gen_ambient_night()
	music_player.play()

func _gen_ambient_day() -> AudioStreamWAV:
	var rate = 22050
	var duration = 8.0
	var samples = int(duration * rate)
	var data = PackedByteArray()
	data.resize(samples * 2)
	for i in range(samples):
		var t = float(i) / float(rate)
		var p = float(i) / float(samples)
		# Peaceful day ambience - soft pads
		var note1 = sin(t * 261.63 * TAU) * 0.08  # C4
		var note2 = sin(t * 329.63 * TAU) * 0.06  # E4
		var note3 = sin(t * 392.0 * TAU) * 0.05   # G4
		# Slow modulation
		var mod = sin(t * 0.3 * TAU) * 0.3 + 0.7
		# Bird-like chirps (sparse)
		var chirp = sin(t * 1800.0 * TAU) * max(0, sin(t * 2.0 * TAU)) * 0.02
		var env = sin(p * PI)  # Fade in/out for seamless loop
		var sample = (note1 + note2 + note3) * mod * env + chirp * env
		var val = clampi(int(sample * 32000), -32768, 32767)
		data[i * 2] = val & 0xFF
		data[i * 2 + 1] = (val >> 8) & 0xFF
	var stream = AudioStreamWAV.new()
	stream.format = AudioStreamWAV.FORMAT_16_BITS
	stream.mix_rate = rate
	stream.loop_mode = AudioStreamWAV.LOOP_FORWARD
	stream.loop_end = samples
	stream.data = data
	return stream

func _gen_ambient_night() -> AudioStreamWAV:
	var rate = 22050
	var duration = 10.0
	var samples = int(duration * rate)
	var data = PackedByteArray()
	data.resize(samples * 2)
	var rng = RandomNumberGenerator.new()
	rng.randomize()
	for i in range(samples):
		var t = float(i) / float(rate)
		var p = float(i) / float(samples)
		# Eerie night ambience - low drones, minor key
		var drone1 = sin(t * 65.41 * TAU) * 0.1   # C2
		var drone2 = sin(t * 77.78 * TAU) * 0.07   # Eb2
		var drone3 = sin(t * 98.0 * TAU) * 0.05    # G2
		# Slow pulsing
		var pulse = sin(t * 0.15 * TAU) * 0.4 + 0.6
		# Occasional eerie whistle
		var whistle = sin(t * 800.0 * TAU) * max(0, sin(t * 0.5 * TAU) - 0.8) * 0.03
		# Wind noise
		var wind = rng.randf_range(-0.02, 0.02) * (sin(t * 0.2 * TAU) * 0.5 + 0.5)
		var env = sin(p * PI)
		var sample = (drone1 + drone2 + drone3) * pulse * env + whistle * env + wind * env
		var val = clampi(int(sample * 32000), -32768, 32767)
		data[i * 2] = val & 0xFF
		data[i * 2 + 1] = (val >> 8) & 0xFF
	var stream = AudioStreamWAV.new()
	stream.format = AudioStreamWAV.FORMAT_16_BITS
	stream.mix_rate = rate
	stream.loop_mode = AudioStreamWAV.LOOP_FORWARD
	stream.loop_end = samples
	stream.data = data
	return stream
