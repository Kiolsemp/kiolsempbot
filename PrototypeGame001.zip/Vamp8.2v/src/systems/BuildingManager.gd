## Building Manager v7 - Town Hall, ownership, night lights
extends Node

signal building_placed(pos: Vector3, type: int)
signal building_destroyed(pos: Vector3)
signal build_mode_changed(active: bool, building_type: String)

enum BuildingType { NONE, WALL, TOWER, GATE, LUMBER_MILL, BARRACKS, FARM, BLACKSMITH, TOWN_HALL }

var building_costs: Dictionary = {
	BuildingType.TOWN_HALL:   [100, 50],
	BuildingType.WALL:        [15, 0],
	BuildingType.TOWER:       [40, 20],
	BuildingType.GATE:        [25, 5],
	BuildingType.LUMBER_MILL: [60, 30],
	BuildingType.BARRACKS:    [80, 40],
	BuildingType.FARM:        [30, 15],
	BuildingType.BLACKSMITH:  [70, 50],
}

var building_hp: Dictionary = {
	BuildingType.TOWN_HALL:   800,
	BuildingType.WALL:        400,
	BuildingType.TOWER:       300,
	BuildingType.GATE:        250,
	BuildingType.LUMBER_MILL: 500,
	BuildingType.BARRACKS:    600,
	BuildingType.FARM:        200,
	BuildingType.BLACKSMITH:  450,
}

var worker_train_cost: Array = [50, 25]
var worker_train_duration: float = 8.0

func get_footprint(type: int) -> Array[Vector2i]:
	match type:
		BuildingType.WALL: return [Vector2i(0,0)]
		BuildingType.GATE: return [Vector2i(0,0)]
		BuildingType.TOWER:
			return [Vector2i(0,0), Vector2i(1,0), Vector2i(0,1), Vector2i(1,1)]
		BuildingType.FARM:
			return [Vector2i(0,0), Vector2i(1,0), Vector2i(0,1), Vector2i(1,1)]
		BuildingType.LUMBER_MILL:
			return [Vector2i(0,0), Vector2i(1,0), Vector2i(-1,0),
					Vector2i(0,1), Vector2i(1,1), Vector2i(-1,1),
					Vector2i(0,-1), Vector2i(1,-1), Vector2i(-1,-1)]
		BuildingType.BARRACKS:
			return [Vector2i(0,0), Vector2i(1,0), Vector2i(-1,0),
					Vector2i(0,1), Vector2i(1,1), Vector2i(-1,1),
					Vector2i(0,-1), Vector2i(1,-1), Vector2i(-1,-1)]
		BuildingType.BLACKSMITH:
			return [Vector2i(0,0), Vector2i(1,0), Vector2i(0,1), Vector2i(1,1)]
		BuildingType.TOWN_HALL:
			return [Vector2i(0,0), Vector2i(1,0), Vector2i(-1,0),
					Vector2i(0,1), Vector2i(1,1), Vector2i(-1,1),
					Vector2i(0,-1), Vector2i(1,-1), Vector2i(-1,-1)]
		_: return [Vector2i(0,0)]

func get_building_radius(type: int) -> float:
	var fp = get_footprint(type)
	if fp.size() <= 1: return 1.2
	elif fp.size() <= 4: return 2.5
	else: return 3.8

var occupied_cells: Dictionary = {}
var tree_cells: Dictionary = {}
var placed_buildings: Array[Node3D] = []

var current_build_type: int = BuildingType.NONE
var is_building: bool = false

func start_build(type: int):
	if type == BuildingType.NONE: cancel_build(); return
	current_build_type = type
	is_building = true
	build_mode_changed.emit(true, get_building_name(type))

func cancel_build():
	current_build_type = BuildingType.NONE
	is_building = false
	build_mode_changed.emit(false, "")

func can_place_at(grid_center: Vector2i, type: int = -1) -> bool:
	if type == -1: type = current_build_type
	var footprint = get_footprint(type)
	for offset in footprint:
		var cell = grid_center + offset
		if occupied_cells.has(cell): return false
		if tree_cells.has(cell): return false
		var world = GameState.grid_to_world(cell)
		if not GameState.is_within_map(world): return false
	return true

func is_cell_blocked(cell: Vector2i) -> bool:
	return occupied_cells.has(cell) or tree_cells.has(cell)

func occupy_cells(grid_center: Vector2i, type: int, building_ref: Node3D):
	var footprint = get_footprint(type)
	for offset in footprint:
		occupied_cells[grid_center + offset] = building_ref
	placed_buildings.append(building_ref)

func free_cells(grid_center: Vector2i, type: int):
	for offset in get_footprint(type):
		occupied_cells.erase(grid_center + offset)

func mark_tree_cell(grid_pos: Vector2i, tree_ref: Node3D):
	tree_cells[grid_pos] = tree_ref

func clear_tree_cell(grid_pos: Vector2i):
	tree_cells.erase(grid_pos)

func place_building(world_pos: Vector3) -> bool:
	if current_build_type == BuildingType.NONE: return false
	var costs = building_costs[current_build_type]
	if not ResourceManager.can_afford(costs[0], costs[1]): return false
	var grid_pos = GameState.world_to_grid(world_pos)
	if not can_place_at(grid_pos): return false
	ResourceManager.spend(costs[0], costs[1])
	building_placed.emit(GameState.grid_to_world(grid_pos), current_build_type)
	return true

func remove_building(building: Node3D, grid_center: Vector2i, type: int):
	free_cells(grid_center, type)
	placed_buildings.erase(building)
	var costs = building_costs.get(type, [0, 0])
	ResourceManager.refund(costs[0], costs[1])
	building_destroyed.emit(GameState.grid_to_world(grid_center))

func get_nearest_town_hall(pos: Vector3) -> Node3D:
	var best: Node3D = null; var bd: float = INF
	for b in placed_buildings:
		if is_instance_valid(b) and "building_type" in b and b.building_type == BuildingType.TOWN_HALL:
			var d = b.global_position.distance_squared_to(pos)
			if d < bd: bd = d; best = b
	return best

func get_nearest_dropoff(pos: Vector3) -> Vector3:
	var best_pos: Vector3 = pos; var bd: float = INF
	for b in placed_buildings:
		if is_instance_valid(b) and "building_type" in b:
			if b.building_type in [BuildingType.TOWN_HALL, BuildingType.LUMBER_MILL]:
				var d = b.global_position.distance_squared_to(pos)
				if d < bd: bd = d; best_pos = b.global_position
	return best_pos

func has_town_hall() -> bool:
	for b in placed_buildings:
		if is_instance_valid(b) and "building_type" in b and b.building_type == BuildingType.TOWN_HALL:
			return true
	return false

func get_building_name(type: int) -> String:
	match type:
		BuildingType.TOWN_HALL: return "Town Hall"
		BuildingType.WALL: return "Wall"
		BuildingType.TOWER: return "Arrow Tower"
		BuildingType.GATE: return "Gate"
		BuildingType.LUMBER_MILL: return "Lumber Mill"
		BuildingType.BARRACKS: return "Barracks"
		BuildingType.FARM: return "Farm"
		BuildingType.BLACKSMITH: return "Blacksmith"
		_: return "Unknown"

func get_cost_string(type: int) -> String:
	var costs = building_costs.get(type, [0, 0])
	var parts: Array[String] = []
	if costs[0] > 0: parts.append("%d W" % costs[0])
	if costs[1] > 0: parts.append("%d G" % costs[1])
	return " ".join(parts)

func get_building_info(type: int) -> String:
	var hp = building_hp.get(type, 0)
	var bname = get_building_name(type)
	var cost = get_cost_string(type)
	var fp = get_footprint(type)
	var size_str = "1x1" if fp.size() <= 1 else ("2x2" if fp.size() <= 4 else "3x3")
	return "%s (%s) HP:%d %s" % [bname, cost, hp, size_str]
