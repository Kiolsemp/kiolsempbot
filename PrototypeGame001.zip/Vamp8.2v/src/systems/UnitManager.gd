extends Node

signal unit_spawned(unit: Node3D)
signal unit_died(unit: Node3D)

var all_units: Array = []
var human_units: Array = []
var vampire_units: Array = []

func register_unit(unit: Node3D):
	all_units.append(unit)
	if unit.has_method("get_team"):
		if unit.get_team() == GameState.Team.HUMAN:
			human_units.append(unit)
		else:
			vampire_units.append(unit)
	unit_spawned.emit(unit)

func unregister_unit(unit: Node3D):
	all_units.erase(unit)
	human_units.erase(unit)
	vampire_units.erase(unit)
	unit_died.emit(unit)

func get_units_in_radius(center: Vector3, radius: float, team: int = -1) -> Array:
	var result: Array = []
	var source = all_units
	if team == GameState.Team.HUMAN:
		source = human_units
	elif team == GameState.Team.VAMPIRE:
		source = vampire_units
	var radius_sq = radius * radius
	for unit in source:
		if is_instance_valid(unit) and unit.global_position.distance_squared_to(center) <= radius_sq:
			result.append(unit)
	return result

func get_nearest_unit(pos: Vector3, team: int) -> Node3D:
	var source = human_units if team == GameState.Team.HUMAN else vampire_units
	var nearest: Node3D = null
	var nearest_dist = INF
	for unit in source:
		if is_instance_valid(unit):
			var d = unit.global_position.distance_squared_to(pos)
			if d < nearest_dist:
				nearest_dist = d
				nearest = unit
	return nearest
