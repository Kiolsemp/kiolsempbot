## GameState v7 - Population, ownership, fog of war support
extends Node

signal game_phase_changed(phase: int)
signal game_over(winner: int)
signal wave_started(wave_number: int, vampire_count: int)
signal score_changed(score: int)

enum Team { HUMAN, VAMPIRE }
enum GamePhase { LOBBY, DAY_PHASE, NIGHT_PHASE, GAME_OVER }

var current_phase: int = GamePhase.LOBBY
var local_player_team: int = Team.HUMAN

var map_size: float = 400.0
var grid_size: float = 2.0
var night_count: int = 0
var vampire_damage_bonus: float = 0.0
var vampire_speed_bonus: float = 0.0
var vampire_hp_bonus: float = 0.0
var starting_lumber: int = 250
var starting_gold: int = 200

# Wave system
var vampires_alive: int = 0
var vampires_killed_total: int = 0
var max_vampires_per_wave: int = 1

# Score
var score: int = 0
var buildings_lost: int = 0
var workers_lost: int = 0

# Win condition
var nights_to_survive: int = 10
var is_game_over: bool = false

# Game speed
var game_speed: float = 1.0

# Population
var current_population: int = 0
var max_population: int = 5  # Base cap, farms increase it

# Fog of war visibility range
var day_visibility: float = 120.0
var night_visibility: float = 60.0  # Half-screen visibility at night
var hero_visibility_bonus: float = 15.0  # Hero sees further

func start_game():
	night_count = 0
	vampire_damage_bonus = 0.0
	vampire_speed_bonus = 0.0
	vampire_hp_bonus = 0.0
	vampires_alive = 0
	vampires_killed_total = 0
	score = 0
	buildings_lost = 0
	workers_lost = 0
	is_game_over = false
	game_speed = 1.0
	current_population = 0
	max_population = 5
	Engine.time_scale = 1.0
	set_phase(GamePhase.DAY_PHASE)

func set_phase(phase: int):
	current_phase = phase
	if phase == GamePhase.NIGHT_PHASE:
		night_count += 1
		vampire_damage_bonus = night_count * 5.0
		vampire_speed_bonus = night_count * 0.5
		vampire_hp_bonus = night_count * 50.0
		max_vampires_per_wave = mini(1 + int(night_count / 2.0), 5)
		wave_started.emit(night_count, max_vampires_per_wave)
	elif phase == GamePhase.DAY_PHASE:
		if night_count > 0:
			add_score(100 * night_count)
		if night_count >= nights_to_survive:
			trigger_victory()
			return
	game_phase_changed.emit(phase)

func set_game_speed(spd: float):
	game_speed = spd
	Engine.time_scale = spd

func add_score(amount: int):
	score += amount
	score_changed.emit(score)

func on_vampire_killed():
	vampires_alive = maxi(0, vampires_alive - 1)
	vampires_killed_total += 1
	add_score(50 + night_count * 10)

func on_vampire_spawned():
	vampires_alive += 1

func on_worker_died():
	workers_lost += 1
	if UnitManager.human_units.size() == 0:
		trigger_defeat()

func on_building_destroyed():
	buildings_lost += 1

func add_population(amount: int = 1):
	current_population += amount

func remove_population(amount: int = 1):
	current_population = maxi(0, current_population - amount)

func can_train_worker() -> bool:
	return current_population < max_population

func increase_max_pop(amount: int = 2):
	max_population += amount

func trigger_victory():
	if is_game_over: return
	is_game_over = true
	add_score(1000)
	set_phase_internal(GamePhase.GAME_OVER)
	game_over.emit(Team.HUMAN)

func trigger_defeat():
	if is_game_over: return
	is_game_over = true
	set_phase_internal(GamePhase.GAME_OVER)
	game_over.emit(Team.VAMPIRE)

func set_phase_internal(phase: int):
	current_phase = phase
	game_phase_changed.emit(phase)

func is_day() -> bool: return current_phase == GamePhase.DAY_PHASE
func is_night() -> bool: return current_phase == GamePhase.NIGHT_PHASE

func get_current_visibility() -> float:
	if is_night(): return night_visibility
	return day_visibility

func get_grid_pos(world_pos: Vector3) -> Vector3:
	return Vector3(
		round(world_pos.x / grid_size) * grid_size, 0,
		round(world_pos.z / grid_size) * grid_size)

func world_to_grid(world_pos: Vector3) -> Vector2i:
	return Vector2i(int(round(world_pos.x / grid_size)), int(round(world_pos.z / grid_size)))

func grid_to_world(grid_pos: Vector2i) -> Vector3:
	return Vector3(grid_pos.x * grid_size, 0, grid_pos.y * grid_size)

func is_within_map(pos: Vector3) -> bool:
	var half = map_size / 2.0
	return abs(pos.x) < half and abs(pos.z) < half
