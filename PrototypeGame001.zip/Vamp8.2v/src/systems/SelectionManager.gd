## Selection Manager v5 - Supports soldiers, workers, vampires, buildings, trees
extends Node

signal selection_changed(selected: Array, selection_type: String)

enum SelType { NONE, WORKER, VAMPIRE, BUILDING, TREE, SOLDIER }

var selected_entities: Array = []
var current_type: int = SelType.NONE

func select_entity(entity: Node3D, add_to_selection: bool = false):
	if not add_to_selection:
		deselect_all()

	if entity in selected_entities:
		if add_to_selection:
			selected_entities.erase(entity)
			if entity.has_method("set_selected"):
				entity.set_selected(false)
	else:
		selected_entities.append(entity)
		if entity.has_method("set_selected"):
			entity.set_selected(true)

	_update_type()
	if SoundManager and selected_entities.size() > 0:
		SoundManager.play_sound("select", -14.0)
	selection_changed.emit(selected_entities, _type_string())

func select_unit(unit: Node3D, add_to_selection: bool = false):
	select_entity(unit, add_to_selection)

func deselect_all():
	for e in selected_entities:
		if is_instance_valid(e) and e.has_method("set_selected"):
			e.set_selected(false)
	selected_entities.clear()
	current_type = SelType.NONE
	selection_changed.emit(selected_entities, "none")

func get_selected() -> Array:
	selected_entities = selected_entities.filter(func(u): return is_instance_valid(u))
	return selected_entities

func has_selection() -> bool:
	return get_selected().size() > 0

func get_selection_type() -> int:
	return current_type

func _update_type():
	if selected_entities.is_empty():
		current_type = SelType.NONE
		return
	var first = selected_entities[0]
	if not is_instance_valid(first):
		current_type = SelType.NONE
		return

	if first is CharacterBody3D and first.has_method("get_team"):
		if first.get_team() == GameState.Team.HUMAN:
			# Check if it's a soldier or worker
			if first.has_method("command_patrol"):
				current_type = SelType.SOLDIER
			else:
				current_type = SelType.WORKER
		else:
			current_type = SelType.VAMPIRE
	elif first is StaticBody3D:
		if first.has_meta("type") and first.get_meta("type") == "tree":
			current_type = SelType.TREE
		elif "building_type" in first:
			current_type = SelType.BUILDING
		else:
			current_type = SelType.NONE
	elif first.has_meta("type") and first.get_meta("type") == "tree":
		current_type = SelType.TREE
	else:
		current_type = SelType.NONE

func _type_string() -> String:
	match current_type:
		SelType.WORKER: return "worker"
		SelType.VAMPIRE: return "vampire"
		SelType.BUILDING: return "building"
		SelType.TREE: return "tree"
		SelType.SOLDIER: return "soldier"
		_: return "none"

func issue_move_command(target_pos: Vector3):
	for e in selected_entities:
		if is_instance_valid(e) and e.has_method("command_move"):
			e.command_move(target_pos)

func issue_attack_command(target: Node3D):
	for e in selected_entities:
		if is_instance_valid(e) and e.has_method("command_attack"):
			e.command_attack(target)
