extends Node

signal time_changed(time_of_day: float)
signal day_started(day_number: int)
signal night_started(night_number: int)
signal night_warning_issued()

var time_of_day: float = 0.05
var day_number: int = 1
var is_paused: bool = false
var night_start: float = 0.5
var night_warning_time: float = 0.42
var warning_issued: bool = false
var cycle_duration: float = 300.0

var directional_light: DirectionalLight3D = null
var world_env: WorldEnvironment = null

func _process(delta: float):
	if is_paused or GameState.current_phase == GameState.GamePhase.LOBBY:
		return
	if GameState.is_game_over:
		return

	var prev_time = time_of_day
	time_of_day += delta / cycle_duration

	if time_of_day >= 1.0:
		time_of_day -= 1.0
		day_number += 1

	# Phase transitions
	if prev_time < night_start and time_of_day >= night_start:
		GameState.set_phase(GameState.GamePhase.NIGHT_PHASE)
		night_started.emit(GameState.night_count)
	
	if prev_time >= night_start and time_of_day < night_start:
		warning_issued = false
		GameState.set_phase(GameState.GamePhase.DAY_PHASE)
		day_started.emit(day_number)
	
	# Wrap-around day start
	if prev_time > 0.9 and time_of_day < 0.1:
		warning_issued = false
		if GameState.current_phase == GameState.GamePhase.NIGHT_PHASE:
			GameState.set_phase(GameState.GamePhase.DAY_PHASE)
			day_started.emit(day_number)

	if not warning_issued and time_of_day >= night_warning_time and time_of_day < night_start:
		warning_issued = true
		night_warning_issued.emit()

	_update_lighting()
	time_changed.emit(time_of_day)

func _update_lighting():
	if not directional_light:
		return

	var light_color: Color
	var light_energy: float
	var sun_angle: float

	if time_of_day < 0.1:
		var dawn_t = time_of_day / 0.1
		light_color = Color(0.9, 0.65, 0.4).lerp(Color(1.0, 0.95, 0.85), dawn_t)
		light_energy = lerp(0.3, 1.0, dawn_t)
		sun_angle = lerp(-10.0, -45.0, dawn_t)
	elif time_of_day < 0.4:
		light_color = Color(1.0, 0.95, 0.85)
		light_energy = 1.0
		var day_t = (time_of_day - 0.1) / 0.3
		sun_angle = lerp(-45.0, -65.0, sin(day_t * PI))
	elif time_of_day < 0.5:
		var dusk_t = (time_of_day - 0.4) / 0.1
		light_color = Color(1.0, 0.95, 0.85).lerp(Color(0.8, 0.4, 0.3), dusk_t)
		light_energy = lerp(1.0, 0.2, dusk_t)
		sun_angle = lerp(-45.0, -10.0, dusk_t)
	else:
		light_color = Color(0.15, 0.18, 0.35)
		light_energy = 0.15
		sun_angle = -5.0

	directional_light.light_color = light_color
	directional_light.light_energy = light_energy
	directional_light.rotation.x = deg_to_rad(sun_angle)
	directional_light.rotation.y = deg_to_rad(time_of_day * 360.0)

	if world_env and world_env.environment:
		var env = world_env.environment
		if time_of_day >= 0.5:
			env.ambient_light_color = Color(0.08, 0.08, 0.18)
			env.ambient_light_energy = 0.35
			env.fog_density = 0.002
		else:
			env.ambient_light_color = Color(0.3, 0.3, 0.35)
			env.ambient_light_energy = 0.5
			env.fog_density = 0.0005

func get_time_string() -> String:
	var hours = int(time_of_day * 24.0) % 24
	var minutes = int(time_of_day * 24.0 * 60.0) % 60
	return "%02d:%02d" % [hours, minutes]

func is_daytime() -> bool:
	return time_of_day < night_start

func is_nighttime() -> bool:
	return time_of_day >= night_start

func get_darkness_factor() -> float:
	if time_of_day < 0.4:
		return 0.0
	elif time_of_day < 0.5:
		return (time_of_day - 0.4) / 0.1
	elif time_of_day < 0.95:
		return 1.0
	else:
		return 1.0 - (time_of_day - 0.95) / 0.05

func get_phase_progress() -> float:
	## Returns 0.0-1.0 progress through current phase
	if is_daytime():
		return time_of_day / night_start
	else:
		return (time_of_day - night_start) / (1.0 - night_start)
