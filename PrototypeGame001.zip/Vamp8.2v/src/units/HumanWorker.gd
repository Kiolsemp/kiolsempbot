## HumanWorker v7 - Hero vs regular worker, 3D model, Town Hall return
extends CharacterBody3D

signal died()

@export var max_health: int = 100
@export var move_speed: float = 8.0
@export var gather_speed: float = 2.5
@export var carry_capacity: int = 15
@export var teleport_range: float = 35.0
@export var teleport_cooldown_max: float = 30.0

enum State { IDLE, MOVING, GATHERING, RETURNING, BUILDING, DEAD, FLEEING }

var current_health: int = 100
var state: int = State.IDLE
var team: int = GameState.Team.HUMAN
var carry_amount: int = 0
var target_tree: Node3D = null
var move_target: Vector3 = Vector3.ZERO
var is_selected: bool = false
var attack_damage: int = 5
var armor: int = 0
var teleport_cooldown: float = 0.0
var gather_timer: float = 0.0

## Hero worker can build and has spells. Regular workers only gather.
var is_hero: bool = false

var body_mesh: MeshInstance3D
var head_mesh: MeshInstance3D
var left_arm: Node3D
var right_arm: Node3D
var left_leg: Node3D
var right_leg: Node3D
var carry_mesh: MeshInstance3D
var selection_ring: MeshInstance3D
var hp_bar_pivot: Node3D
var hp_bar_fill: MeshInstance3D
var nav_agent: NavigationAgent3D
var model_root: Node3D
var anim_time: float = 0.0
var night_light: OmniLight3D

func _ready():
	current_health = max_health
	collision_layer = 2
	collision_mask = 1 | 4
	var col = CollisionShape3D.new()
	var cap = CapsuleShape3D.new()
	if is_hero:
		cap.radius = 0.7; cap.height = 3.2
	else:
		cap.radius = 0.6; cap.height = 2.8  # 70% bigger workers
	col.shape = cap; col.position.y = cap.height / 2.0
	add_child(col)
	_create_model()
	_create_selection_ring()
	_create_hp_bar()
	_create_night_light()
	_setup_nav()
	UnitManager.register_unit(self)
	GameState.add_population()

func _create_model():
	model_root = Node3D.new()
	model_root.name = "Model"
	# Hero is 2x scale, regular workers are 1.7x (70% bigger)
	var s = 2.0 if is_hero else 1.7
	model_root.scale = Vector3(s, s, s)
	add_child(model_root)

	var skin = StandardMaterial3D.new()
	skin.albedo_color = Color(0.85, 0.7, 0.55)
	skin.roughness = 0.7
	var tunic = StandardMaterial3D.new()
	# Hero gets golden tunic, regular workers green
	if is_hero:
		tunic.albedo_color = Color(0.7, 0.5, 0.15)
		tunic.emission_enabled = true
		tunic.emission = Color(0.3, 0.2, 0.05)
		tunic.emission_energy_multiplier = 0.3
	else:
		tunic.albedo_color = Color(0.3, 0.45, 0.2)
	tunic.roughness = 0.8
	var pants = StandardMaterial3D.new()
	pants.albedo_color = Color(0.35, 0.25, 0.15)
	var boot_mat = StandardMaterial3D.new()
	boot_mat.albedo_color = Color(0.25, 0.18, 0.1)

	# Torso
	body_mesh = MeshInstance3D.new()
	var bb = BoxMesh.new(); bb.size = Vector3(0.5, 0.6, 0.3)
	body_mesh.mesh = bb; body_mesh.position.y = 1.1
	body_mesh.material_override = tunic
	model_root.add_child(body_mesh)

	# Head
	head_mesh = MeshInstance3D.new()
	var hs = SphereMesh.new(); hs.radius = 0.2; hs.height = 0.4
	head_mesh.mesh = hs; head_mesh.position.y = 1.65
	head_mesh.material_override = skin
	model_root.add_child(head_mesh)

	# Hat - Hero gets crown, workers get straw hat
	var hat = MeshInstance3D.new()
	if is_hero:
		var hc = CylinderMesh.new(); hc.top_radius = 0.22; hc.bottom_radius = 0.24; hc.height = 0.15
		hat.mesh = hc; hat.position.y = 1.85
		var hm = StandardMaterial3D.new(); hm.albedo_color = Color(0.8, 0.65, 0.1)
		hm.metallic = 0.6; hm.roughness = 0.3
		hm.emission_enabled = true; hm.emission = Color(0.4, 0.3, 0.05)
		hm.emission_energy_multiplier = 1.0
		hat.material_override = hm
	else:
		var whc = CylinderMesh.new(); whc.top_radius = 0.15; whc.bottom_radius = 0.3; whc.height = 0.12
		hat.mesh = whc; hat.position.y = 1.82
		var whm = StandardMaterial3D.new(); whm.albedo_color = Color(0.6, 0.5, 0.25)
		hat.material_override = whm
	model_root.add_child(hat)

	# Arms
	var ab = BoxMesh.new(); ab.size = Vector3(0.14, 0.55, 0.14)
	left_arm = Node3D.new(); left_arm.position = Vector3(-0.35, 1.3, 0)
	model_root.add_child(left_arm)
	var la = MeshInstance3D.new(); la.mesh = ab; la.position.y = -0.25
	la.material_override = skin; left_arm.add_child(la)

	right_arm = Node3D.new(); right_arm.position = Vector3(0.35, 1.3, 0)
	model_root.add_child(right_arm)
	var ra = MeshInstance3D.new(); ra.mesh = ab.duplicate(); ra.position.y = -0.25
	ra.material_override = skin; right_arm.add_child(ra)

	# Axe on right hand
	var axe_handle = MeshInstance3D.new()
	var ah = BoxMesh.new(); ah.size = Vector3(0.06, 0.5, 0.04)
	axe_handle.mesh = ah; axe_handle.position = Vector3(0, -0.45, 0)
	var ahm = StandardMaterial3D.new(); ahm.albedo_color = Color(0.4, 0.3, 0.15)
	axe_handle.material_override = ahm; right_arm.add_child(axe_handle)
	var axe_head = MeshInstance3D.new()
	var ahe = BoxMesh.new(); ahe.size = Vector3(0.15, 0.12, 0.04)
	axe_head.mesh = ahe; axe_head.position = Vector3(0.08, -0.6, 0)
	var ahem = StandardMaterial3D.new(); ahem.albedo_color = Color(0.5, 0.5, 0.55); ahem.metallic = 0.5
	axe_head.material_override = ahem; right_arm.add_child(axe_head)

	# Hero gets a shield on left arm
	if is_hero:
		var shield = MeshInstance3D.new()
		var sb = BoxMesh.new(); sb.size = Vector3(0.04, 0.35, 0.25)
		shield.mesh = sb; shield.position = Vector3(-0.12, -0.3, 0)
		var sm = StandardMaterial3D.new(); sm.albedo_color = Color(0.5, 0.4, 0.15)
		sm.metallic = 0.4; sm.roughness = 0.4
		shield.material_override = sm; left_arm.add_child(shield)

	# Legs
	var lb = BoxMesh.new(); lb.size = Vector3(0.16, 0.55, 0.16)
	var boot = BoxMesh.new(); boot.size = Vector3(0.18, 0.12, 0.22)
	left_leg = Node3D.new(); left_leg.position = Vector3(-0.12, 0.8, 0)
	model_root.add_child(left_leg)
	var ll = MeshInstance3D.new(); ll.mesh = lb; ll.position.y = -0.25
	ll.material_override = pants; left_leg.add_child(ll)
	var lbo = MeshInstance3D.new(); lbo.mesh = boot; lbo.position = Vector3(0, -0.5, 0.03)
	lbo.material_override = boot_mat; left_leg.add_child(lbo)

	right_leg = Node3D.new(); right_leg.position = Vector3(0.12, 0.8, 0)
	model_root.add_child(right_leg)
	var rl = MeshInstance3D.new(); rl.mesh = lb.duplicate(); rl.position.y = -0.25
	rl.material_override = pants; right_leg.add_child(rl)
	var rbo = MeshInstance3D.new(); rbo.mesh = boot.duplicate(); rbo.position = Vector3(0, -0.5, 0.03)
	rbo.material_override = boot_mat; right_leg.add_child(rbo)

	# Carry bundle
	carry_mesh = MeshInstance3D.new()
	var cb = BoxMesh.new(); cb.size = Vector3(0.3, 0.3, 0.5)
	carry_mesh.mesh = cb; carry_mesh.position = Vector3(0, 1.3, -0.3)
	var cm = StandardMaterial3D.new(); cm.albedo_color = Color(0.5, 0.35, 0.15)
	carry_mesh.material_override = cm; carry_mesh.visible = false
	model_root.add_child(carry_mesh)

func _create_selection_ring():
	selection_ring = MeshInstance3D.new()
	var t = TorusMesh.new()
	var ring_size = 1.0 if is_hero else 0.8
	t.inner_radius = ring_size; t.outer_radius = ring_size + 0.2
	t.rings = 16; t.ring_segments = 16
	selection_ring.mesh = t; selection_ring.position.y = 0.05
	var m = StandardMaterial3D.new()
	m.albedo_color = Color(0.2, 1, 0.2, 0.6)
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	m.emission_enabled = true; m.emission = Color(0.2, 1, 0.2)
	m.emission_energy_multiplier = 2.0; m.no_depth_test = true
	selection_ring.material_override = m; selection_ring.visible = false
	add_child(selection_ring)

func _create_hp_bar():
	var bar_h = 2.2 if not is_hero else 4.2
	hp_bar_pivot = Node3D.new(); hp_bar_pivot.position.y = bar_h; hp_bar_pivot.visible = false
	add_child(hp_bar_pivot)
	var bg = MeshInstance3D.new(); bg.mesh = BoxMesh.new(); bg.mesh.size = Vector3(0.8,0.08,0.02)
	var bgm = StandardMaterial3D.new(); bgm.albedo_color = Color(0.15,0,0); bgm.no_depth_test = true
	bg.material_override = bgm; hp_bar_pivot.add_child(bg)
	hp_bar_fill = MeshInstance3D.new(); hp_bar_fill.mesh = BoxMesh.new()
	hp_bar_fill.mesh.size = Vector3(0.75,0.06,0.03)
	var fm = StandardMaterial3D.new(); fm.albedo_color = Color(0.1,0.9,0.1); fm.no_depth_test = true
	hp_bar_fill.material_override = fm; hp_bar_pivot.add_child(hp_bar_fill)

func _create_night_light():
	night_light = OmniLight3D.new()
	night_light.light_color = Color(1.0, 0.85, 0.6)
	night_light.light_energy = 0.6  # Always on
	night_light.omni_range = 33.0 if not is_hero else 58.0
	night_light.omni_attenuation = 0.7
	night_light.shadow_enabled = false
	night_light.position.y = 1.5 if not is_hero else 3.0
	add_child(night_light)

func _setup_nav():
	nav_agent = NavigationAgent3D.new()
	nav_agent.path_desired_distance = 1.5; nav_agent.target_desired_distance = 1.5
	nav_agent.avoidance_enabled = true; nav_agent.radius = 0.5
	add_child(nav_agent)

func _process(delta: float):
	if state == State.DEAD: return
	teleport_cooldown = max(0.0, teleport_cooldown - delta)
	anim_time += delta
	_animate()
	if hp_bar_pivot and hp_bar_pivot.visible:
		var cam = get_viewport().get_camera_3d()
		if cam and hp_bar_pivot.global_position.distance_squared_to(cam.global_position) > 0.1: hp_bar_pivot.look_at(cam.global_position, Vector3.UP)
	# Night torch effect
	if night_light:
		var target_energy = 2.5 if GameClock.is_nighttime() else 1.0
		if GameClock.time_of_day > 0.35 and not GameClock.is_nighttime():
			var dt = (GameClock.time_of_day - 0.35) / 0.15
			target_energy = lerp(1.0, 2.5, clampf(dt, 0.0, 1.0))
		if is_hero: target_energy *= 1.5
		night_light.light_energy = lerp(night_light.light_energy, target_energy, delta * 3.0)

func _animate():
	var walking = state in [State.MOVING, State.RETURNING, State.FLEEING]
	carry_mesh.visible = carry_amount > 0
	if walking:
		var sw = sin(anim_time * 8.0) * 0.6
		left_leg.rotation.x = sw; right_leg.rotation.x = -sw
		left_arm.rotation.x = -sw * 0.5; right_arm.rotation.x = sw * 0.5
		body_mesh.position.y = 1.1 + abs(sin(anim_time * 16.0)) * 0.03
	elif state == State.GATHERING:
		var ch = sin(anim_time * 4.0)
		right_arm.rotation.x = -1.2 + ch * 0.8; left_arm.rotation.x = -0.3
		left_leg.rotation.x = 0; right_leg.rotation.x = 0
		body_mesh.rotation.x = ch * 0.1
	else:
		left_leg.rotation.x = 0; right_leg.rotation.x = 0
		left_arm.rotation.x = 0; right_arm.rotation.x = 0
		body_mesh.rotation.x = 0
		body_mesh.position.y = 1.1 + sin(anim_time * 2.0) * 0.015

func _physics_process(delta: float):
	if state == State.DEAD: return
	if not is_on_floor():
		velocity.y -= 20.0 * delta; move_and_slide(); return
	match state:
		State.IDLE: velocity = Vector3.ZERO
		State.MOVING: _move_nav(delta)
		State.GATHERING: _gather(delta)
		State.RETURNING: _return(delta)
		State.FLEEING: _move_nav(delta)
	move_and_slide()

func _move_nav(delta: float):
	if nav_agent.is_navigation_finished():
		state = State.IDLE; velocity = Vector3.ZERO; return
	var next = nav_agent.get_next_path_position()
	var dir = (next - global_position).normalized(); dir.y = 0
	var spd = move_speed * (1.3 if state == State.FLEEING else 1.0)
	velocity = dir * spd
	if dir.length() > 0.1:
		rotation.y = lerp_angle(rotation.y, atan2(dir.x, dir.z), delta * 10.0)

func _gather(delta: float):
	if not is_instance_valid(target_tree):
		# Auto find next tree
		_auto_find_tree()
		return
	var dist = global_position.distance_to(target_tree.global_position)
	if dist > 3.0:
		nav_agent.target_position = target_tree.global_position
		var next = nav_agent.get_next_path_position()
		var dir = (next - global_position).normalized(); dir.y = 0
		velocity = dir * move_speed
		if dir.length() > 0.1:
			rotation.y = lerp_angle(rotation.y, atan2(dir.x, dir.z), delta * 10.0)
	else:
		velocity = Vector3.ZERO
		var ld = (target_tree.global_position - global_position).normalized()
		if ld.length() > 0.1:
			rotation.y = lerp_angle(rotation.y, atan2(ld.x, ld.z), delta * 8.0)
		gather_timer += delta
		if gather_timer >= gather_speed:
			gather_timer = 0.0; _chop()

func _chop():
	if not is_instance_valid(target_tree): _auto_find_tree(); return
	var left = target_tree.get_meta("lumber", 0)
	var take = mini(mini(5, left), carry_capacity - carry_amount)
	carry_amount += take; left -= take
	target_tree.set_meta("lumber", left)
	for c in target_tree.get_children():
		if c is StaticBody3D and c.has_meta("lumber"): c.set_meta("lumber", left)
	# Sound effect
	if SoundManager: SoundManager.play_sound("chop", -10.0)
	if left <= 0:
		var map = get_tree().current_scene.get_node_or_null("Map")
		if map and map.has_method("on_tree_chopped"): map.on_tree_chopped(target_tree)
		target_tree = null
		if carry_amount > 0: _return_base()
		else: _auto_find_tree()
	elif carry_amount >= carry_capacity: _return_base()

func _auto_find_tree():
	var map = get_tree().current_scene.get_node_or_null("Map")
	if map and map.has_method("get_nearest_tree"):
		var t = map.get_nearest_tree(global_position, 50.0)
		if t:
			target_tree = t; state = State.GATHERING; gather_timer = 0.0
			return
	state = State.IDLE

func _return_base():
	state = State.RETURNING
	# Find nearest Town Hall or Lumber Mill as drop-off
	var dropoff = BuildingManager.get_nearest_dropoff(global_position)
	if dropoff == global_position:
		# No drop-off building exists, just deposit immediately
		ResourceManager.add_lumber(carry_amount); carry_amount = 0
		if is_instance_valid(target_tree) and target_tree.get_meta("lumber", 0) > 0:
			state = State.GATHERING
		else:
			_auto_find_tree()
		return
	nav_agent.target_position = dropoff

func _return(delta: float):
	if nav_agent.is_navigation_finished() or global_position.distance_to(nav_agent.target_position) < 5.0:
		ResourceManager.add_lumber(carry_amount); carry_amount = 0
		if SoundManager: SoundManager.play_sound("resource_gain", -12.0)
		if is_instance_valid(target_tree) and target_tree.get_meta("lumber", 0) > 0:
			state = State.GATHERING
		else:
			_auto_find_tree()
		return
	var next = nav_agent.get_next_path_position()
	var dir = (next - global_position).normalized(); dir.y = 0
	velocity = dir * move_speed
	if dir.length() > 0.1:
		rotation.y = lerp_angle(rotation.y, atan2(dir.x, dir.z), delta * 10.0)

func command_move(pos: Vector3):
	state = State.MOVING; move_target = pos; nav_agent.target_position = pos

func command_gather(tree: Node3D):
	target_tree = tree; state = State.GATHERING; gather_timer = 0.0

func command_stop():
	state = State.IDLE; velocity = Vector3.ZERO; target_tree = null

func command_repair_nearest():
	command_move(global_position)

## Only hero can build - this is checked by Main.gd before calling build
func can_build() -> bool:
	return is_hero

func cast_teleport_to(pos: Vector3):
	if not is_hero: return  # Only hero can teleport
	if teleport_cooldown > 0: return
	if global_position.distance_to(pos) > teleport_range: return
	global_position = Vector3(pos.x, 1.0, pos.z)
	teleport_cooldown = teleport_cooldown_max

func take_damage(amount: int, _attacker: Node3D = null):
	var eff = max(1, amount - armor)
	current_health -= eff; current_health = max(0, current_health)
	hp_bar_pivot.visible = true
	var r = float(current_health) / float(max_health)
	hp_bar_fill.scale.x = r
	hp_bar_fill.position.x = (r - 1.0) * 0.375
	var fm = hp_bar_fill.material_override as StandardMaterial3D
	if fm:
		fm.albedo_color = Color(0.1,0.9,0.1) if r>0.5 else (Color(0.9,0.9,0.1) if r>0.25 else Color(0.9,0.1,0.1))
	if body_mesh and body_mesh.material_override:
		var oc = body_mesh.material_override.albedo_color
		body_mesh.material_override.albedo_color = Color(1,0.3,0.3)
		get_tree().create_timer(0.1).timeout.connect(func():
			if is_instance_valid(body_mesh) and body_mesh.material_override:
				body_mesh.material_override.albedo_color = oc)
	_dmg_num(eff)
	if current_health <= 0: _die()

func _dmg_num(amt: int):
	var l = Label3D.new(); l.text = "-%d"%amt; l.font_size = 28
	l.modulate = Color(1,0.3,0.3); l.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	l.no_depth_test = true
	l.position = global_position + Vector3(randf_range(-0.3,0.3),2.5,0)
	get_tree().current_scene.add_child(l)
	var tw = create_tween()
	tw.tween_property(l,"position:y",l.position.y+1.5,0.8)
	tw.parallel().tween_property(l,"modulate:a",0.0,0.8)
	tw.tween_callback(l.queue_free)

func _die():
	state = State.DEAD
	if SoundManager: SoundManager.play_sound("death", -8.0)
	GameState.remove_population()
	UnitManager.unregister_unit(self); died.emit()
	var tw = create_tween()
	tw.tween_property(self,"rotation:x",-PI/2,0.4)
	tw.tween_callback(queue_free)

func set_selected(val: bool):
	is_selected = val; selection_ring.visible = val
	hp_bar_pivot.visible = val or current_health < max_health

func get_team() -> int: return team
func get_state_string() -> String:
	match state:
		State.IDLE: return "Idle"
		State.MOVING: return "Moving"
		State.GATHERING: return "Gathering"
		State.RETURNING: return "Returning"
		State.FLEEING: return "Fleeing!"
		_: return "?"

func get_teleport_cd_percent() -> float:
	if teleport_cooldown <= 0: return 1.0
	return 1.0 - (teleport_cooldown / teleport_cooldown_max)
