## Vampire v6 - Dark creature with horns, wings, claws, glowing eyes
extends CharacterBody3D

signal died()

@export var base_max_health: int = 500
@export var base_move_speed: float = 7.0
@export var base_attack_damage: int = 25
@export var attack_range: float = 5.0
@export var attack_cooldown: float = 0.8
@export var detection_range: float = 25.0
@export var lifesteal_percent: float = 0.3

enum State { IDLE, PATROLLING, CHASING, ATTACKING, RETREATING, HIDING, ATTACKING_BUILDING }

var current_health: int = 500
var max_health: int = 500
var move_speed: float = 7.0
var attack_damage: int = 25
var state: int = State.HIDING
var team: int = GameState.Team.VAMPIRE
var target_unit: Node3D = null
var target_building: Node3D = null
var _bldg_stuck_timer: float = 0.0
var patrol_target: Vector3 = Vector3.ZERO
var attack_timer: float = 0.0
var ai_timer: float = 0.0
var nav_ready: bool = false
var is_selected: bool = false
var is_boss: bool = false
var is_player_controlled: bool = false  # Player transformed into this vampire
var has_player_ally: bool = false  # AI vampire allied with player vampire

var body_mesh: MeshInstance3D
var head_mesh: MeshInstance3D
var left_arm: Node3D
var right_arm: Node3D
var left_leg: Node3D
var right_leg: Node3D
var left_wing: Node3D
var right_wing: Node3D
var cloak_mesh: MeshInstance3D
var eye_left: MeshInstance3D
var eye_right: MeshInstance3D
var selection_ring: MeshInstance3D
var health_bar: Node3D
var health_bar_fill: MeshInstance3D
var nav_agent: NavigationAgent3D
var model_root: Node3D
var anim_time: float = 0.0
var is_attack_animating: bool = false
var attack_anim_time: float = 0.0
var stuck_timer: float = 0.0
var last_position: Vector3 = Vector3.ZERO
var wall_attack_patience: float = 0.0
var preferred_base_index: int = -1

func _ready():
	_apply_night_bonuses()
	current_health = max_health
	collision_layer = 2; collision_mask = 1 | 4
	var col = CollisionShape3D.new()
	var cap = CapsuleShape3D.new()
	cap.radius = 1.5 if not is_boss else 2.2
	cap.height = 6.0 if not is_boss else 8.0
	col.shape = cap; col.position.y = 3.0
	add_child(col)
	_create_model()
	_create_effects()
	_setup_nav()
	await get_tree().create_timer(0.3).timeout
	if not is_inside_tree(): return
	nav_ready = true; last_position = global_position
	UnitManager.register_unit(self); GameState.on_vampire_spawned()
	var rng = RandomNumberGenerator.new(); rng.randomize()
	preferred_base_index = rng.randi_range(0, 3)
	ai_timer = rng.randf_range(0, 1.0)
	# Eerie vampire glow
	var vamp_light = OmniLight3D.new()
	vamp_light.light_color = Color(0.8, 0.15, 0.3) if not is_player_controlled else Color(0.6, 0.2, 0.8)
	vamp_light.light_energy = 1.5 if is_player_controlled else 0.8
	vamp_light.omni_range = 25.0 if is_player_controlled else 12.0
	vamp_light.omni_attenuation = 1.0
	vamp_light.shadow_enabled = false
	vamp_light.position.y = 3.0
	vamp_light.name = "VampLight"
	add_child(vamp_light)

func _create_model():
	var s = 3.0 if not is_boss else 4.2
	model_root = Node3D.new(); model_root.name = "Model"
	model_root.scale = Vector3(s, s, s); add_child(model_root)
	var dark = StandardMaterial3D.new()
	dark.albedo_color = Color(0.12,0.08,0.15) if not is_boss else Color(0.2,0.05,0.05)
	dark.roughness = 0.6; dark.metallic = 0.1
	var leg_mat = StandardMaterial3D.new()
	leg_mat.albedo_color = Color(0.1,0.07,0.12); leg_mat.roughness = 0.6

	body_mesh = MeshInstance3D.new()
	var bb = BoxMesh.new(); bb.size = Vector3(0.7,0.8,0.4)
	body_mesh.mesh = bb; body_mesh.position.y = 1.2
	body_mesh.material_override = dark; model_root.add_child(body_mesh)

	head_mesh = MeshInstance3D.new()
	var hb = BoxMesh.new(); hb.size = Vector3(0.45,0.5,0.4)
	head_mesh.mesh = hb; head_mesh.position.y = 1.9
	var hm = StandardMaterial3D.new(); hm.albedo_color = Color(0.15,0.1,0.18); hm.roughness = 0.5
	head_mesh.material_override = hm; model_root.add_child(head_mesh)

	var em = StandardMaterial3D.new()
	em.albedo_color = Color(1,0.1,0.05)
	em.emission_enabled = true
	em.emission = Color(1,0.15,0.05) if not is_boss else Color(0.8,0,0.8)
	em.emission_energy_multiplier = 5.0
	var es = SphereMesh.new(); es.radius = 0.06; es.height = 0.12
	eye_left = MeshInstance3D.new(); eye_left.mesh = es
	eye_left.position = Vector3(-0.1,1.95,0.2); eye_left.material_override = em
	model_root.add_child(eye_left)
	eye_right = MeshInstance3D.new(); eye_right.mesh = es.duplicate()
	eye_right.position = Vector3(0.1,1.95,0.2); eye_right.material_override = em
	model_root.add_child(eye_right)

	for side in [-1, 1]:
		var horn = MeshInstance3D.new()
		var hc = CylinderMesh.new(); hc.top_radius = 0.02; hc.bottom_radius = 0.06; hc.height = 0.4
		horn.mesh = hc; horn.position = Vector3(side*0.18,2.2,-0.05)
		horn.rotation.z = side * 0.4; horn.rotation.x = -0.2
		var hmat = StandardMaterial3D.new(); hmat.albedo_color = Color(0.25,0.2,0.15); hmat.roughness = 0.4
		horn.material_override = hmat; model_root.add_child(horn)

	var ab = BoxMesh.new(); ab.size = Vector3(0.16,0.65,0.16)
	left_arm = Node3D.new(); left_arm.position = Vector3(-0.5,1.4,0); model_root.add_child(left_arm)
	var la = MeshInstance3D.new(); la.mesh = ab; la.position.y = -0.3
	la.material_override = dark; left_arm.add_child(la)
	_add_claws(left_arm, Vector3(0,-0.6,0.1))

	right_arm = Node3D.new(); right_arm.position = Vector3(0.5,1.4,0); model_root.add_child(right_arm)
	var ra = MeshInstance3D.new(); ra.mesh = ab.duplicate(); ra.position.y = -0.3
	ra.material_override = dark; right_arm.add_child(ra)
	_add_claws(right_arm, Vector3(0,-0.6,0.1))

	var lgb = BoxMesh.new(); lgb.size = Vector3(0.2,0.6,0.2)
	left_leg = Node3D.new(); left_leg.position = Vector3(-0.18,0.8,0); model_root.add_child(left_leg)
	var ll = MeshInstance3D.new(); ll.mesh = lgb; ll.position.y = -0.3
	ll.material_override = leg_mat; left_leg.add_child(ll)
	right_leg = Node3D.new(); right_leg.position = Vector3(0.18,0.8,0); model_root.add_child(right_leg)
	var rl = MeshInstance3D.new(); rl.mesh = lgb.duplicate(); rl.position.y = -0.3
	rl.material_override = leg_mat; right_leg.add_child(rl)

	var wm = StandardMaterial3D.new()
	wm.albedo_color = Color(0.08,0.05,0.1,0.8)
	wm.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	wm.cull_mode = BaseMaterial3D.CULL_DISABLED
	var wb = BoxMesh.new(); wb.size = Vector3(0.8,0.5,0.03)
	left_wing = Node3D.new(); left_wing.position = Vector3(-0.35,1.5,-0.2); model_root.add_child(left_wing)
	var lw = MeshInstance3D.new(); lw.mesh = wb; lw.position = Vector3(-0.4,0,0)
	lw.material_override = wm; left_wing.add_child(lw)
	right_wing = Node3D.new(); right_wing.position = Vector3(0.35,1.5,-0.2); model_root.add_child(right_wing)
	var rw = MeshInstance3D.new(); rw.mesh = wb.duplicate(); rw.position = Vector3(0.4,0,0)
	rw.material_override = wm; right_wing.add_child(rw)

	cloak_mesh = MeshInstance3D.new()
	var cb = BoxMesh.new(); cb.size = Vector3(0.65,0.9,0.08)
	cloak_mesh.mesh = cb; cloak_mesh.position = Vector3(0,1.0,-0.22)
	var cm = StandardMaterial3D.new(); cm.albedo_color = Color(0.08,0.03,0.08); cm.roughness = 0.8
	cloak_mesh.material_override = cm; model_root.add_child(cloak_mesh)

func _add_claws(parent: Node3D, offset: Vector3):
	var cm = StandardMaterial3D.new(); cm.albedo_color = Color(0.6,0.55,0.45); cm.roughness = 0.3
	for i in range(3):
		var c = MeshInstance3D.new()
		var cc = CylinderMesh.new(); cc.top_radius = 0.005; cc.bottom_radius = 0.02; cc.height = 0.15
		c.mesh = cc; c.position = offset + Vector3((i-1)*0.06,0,0); c.rotation.x = 0.5
		c.material_override = cm; parent.add_child(c)

func _create_effects():
	var aura = MeshInstance3D.new()
	var ac = CylinderMesh.new(); ac.top_radius = 3.0 if not is_boss else 4.5
	ac.bottom_radius = ac.top_radius; ac.height = 0.05
	aura.mesh = ac; aura.position.y = 0.03
	var am = StandardMaterial3D.new()
	am.albedo_color = Color(0.1,0,0.15,0.4); am.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	am.emission_enabled = true; am.emission = Color(0.2,0,0.15)
	am.emission_energy_multiplier = 1.5; am.no_depth_test = true
	aura.material_override = am; add_child(aura)

	selection_ring = MeshInstance3D.new()
	var t = TorusMesh.new(); t.inner_radius = 2.2; t.outer_radius = 2.6
	t.rings = 16; t.ring_segments = 16
	selection_ring.mesh = t; selection_ring.position.y = 0.05
	var rm = StandardMaterial3D.new()
	rm.albedo_color = Color(1,0.2,0.2,0.6); rm.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	rm.emission_enabled = true; rm.emission = Color(1,0.1,0.1)
	rm.emission_energy_multiplier = 2.0; rm.no_depth_test = true
	selection_ring.material_override = rm; selection_ring.visible = false
	add_child(selection_ring)

	health_bar = Node3D.new(); health_bar.position.y = 7.0; health_bar.visible = false
	add_child(health_bar)
	var bg = MeshInstance3D.new(); bg.mesh = BoxMesh.new(); bg.mesh.size = Vector3(1.2,0.1,0.02)
	var bgm = StandardMaterial3D.new(); bgm.albedo_color = Color(0.15,0,0); bgm.no_depth_test = true
	bg.material_override = bgm; health_bar.add_child(bg)
	health_bar_fill = MeshInstance3D.new(); health_bar_fill.mesh = BoxMesh.new()
	health_bar_fill.mesh.size = Vector3(1.1,0.07,0.03)
	var fm = StandardMaterial3D.new(); fm.albedo_color = Color(0.9,0.1,0.1); fm.no_depth_test = true
	health_bar_fill.material_override = fm; health_bar.add_child(health_bar_fill)

func _setup_nav():
	nav_agent = NavigationAgent3D.new()
	nav_agent.path_desired_distance = 1.5; nav_agent.target_desired_distance = 2.0
	nav_agent.avoidance_enabled = true; nav_agent.radius = 1.5
	add_child(nav_agent)

func _apply_night_bonuses():
	max_health = base_max_health + int(GameState.vampire_hp_bonus)
	attack_damage = base_attack_damage + int(GameState.vampire_damage_bonus)
	move_speed = base_move_speed + GameState.vampire_speed_bonus
	if is_boss:
		max_health = int(max_health * 2.5); attack_damage = int(attack_damage * 1.8)
		move_speed *= 0.9; lifesteal_percent = 0.5

func _process(delta: float):
	anim_time += delta; _animate(delta)
	if health_bar and health_bar.visible:
		var cam = get_viewport().get_camera_3d()
		if cam and health_bar.global_position.distance_squared_to(cam.global_position) > 0.1: health_bar.look_at(cam.global_position, Vector3.UP)
	if eye_left and eye_left.material_override:
		eye_left.material_override.emission_energy_multiplier = 3.0 + sin(anim_time * 3.0) * 2.0
	if eye_right and eye_right.material_override:
		eye_right.material_override.emission_energy_multiplier = 3.0 + sin(anim_time * 3.0 + 0.5) * 2.0

func _animate(delta: float):
	var walking = state in [State.PATROLLING, State.CHASING, State.RETREATING]
	if walking:
		var sw = sin(anim_time * 6.0) * 0.5
		left_leg.rotation.x = sw; right_leg.rotation.x = -sw
		left_arm.rotation.x = -sw * 0.4; right_arm.rotation.x = sw * 0.4
		left_wing.rotation.z = sin(anim_time * 4.0) * 0.3
		right_wing.rotation.z = -sin(anim_time * 4.0) * 0.3
		cloak_mesh.rotation.x = sin(anim_time * 3.0) * 0.15
	elif state in [State.ATTACKING, State.ATTACKING_BUILDING]:
		if is_attack_animating:
			attack_anim_time += delta * 8.0
			var atk_sw = sin(attack_anim_time * PI) * 1.5
			right_arm.rotation.x = -atk_sw; left_arm.rotation.x = -atk_sw * 0.7
			body_mesh.rotation.x = sin(attack_anim_time * PI) * 0.15
			if attack_anim_time >= 1.0: is_attack_animating = false; attack_anim_time = 0.0
		left_leg.rotation.x = 0; right_leg.rotation.x = 0
	else:
		left_leg.rotation.x = 0; right_leg.rotation.x = 0
		left_arm.rotation.x = sin(anim_time*1.5)*0.1; right_arm.rotation.x = sin(anim_time*1.5+1)*0.1
		body_mesh.rotation.x = 0
		left_wing.rotation.z = lerp(left_wing.rotation.z,-0.1,delta*3)
		right_wing.rotation.z = lerp(right_wing.rotation.z,0.1,delta*3)

var player_move_target: Vector3 = Vector3.ZERO
var has_player_move_target: bool = false

func _physics_process(delta: float):
	if not nav_ready: return
	if not is_on_floor(): velocity.y -= 20.0 * delta; move_and_slide(); return
	attack_timer -= delta; ai_timer -= delta

	# Player-controlled vampire: use player commands instead of AI
	if is_player_controlled:
		_player_vampire_logic(delta)
		move_and_slide()
		return

	if ai_timer <= 0: ai_timer = 0.5; _ai_think()
	match state:
		State.HIDING:
			velocity = Vector3.ZERO
			if GameClock.is_nighttime(): state = State.PATROLLING; _pick_patrol()
		State.PATROLLING: _patrol(delta)
		State.CHASING: _chase(delta)
		State.ATTACKING: _attack(delta)
		State.ATTACKING_BUILDING: _attack_bldg(delta)
		State.RETREATING: _retreat(delta)
		State.IDLE:
			velocity = Vector3.ZERO
			if GameClock.is_nighttime(): state = State.PATROLLING; _pick_patrol()
			elif GameClock.is_daytime(): state = State.HIDING
	stuck_timer += delta
	if stuck_timer > 3.0:
		stuck_timer = 0.0
		if global_position.distance_to(last_position) < 1.0 and state in [State.CHASING, State.PATROLLING]:
			wall_attack_patience += 1.0
			if wall_attack_patience > 2.0: _try_attack_wall()
		last_position = global_position
	move_and_slide()

func _player_vampire_logic(delta: float):
	# Player vampire is not hurt by daylight, always active
	# Handle attacking a unit
	if state == State.ATTACKING and target_unit and is_instance_valid(target_unit):
		_attack(delta)
		return
	# Handle attacking a building
	if state == State.ATTACKING_BUILDING and target_building and is_instance_valid(target_building):
		_attack_bldg(delta)
		return
	# Check for nearby enemies to auto-attack
	var near = _find_player_enemy()
	if near and global_position.distance_to(near.global_position) < attack_range * 1.5:
		target_unit = near
		state = State.ATTACKING
		return
	# Move to player target
	if has_player_move_target:
		nav_agent.target_position = player_move_target
		state = State.PATROLLING
		if nav_agent.is_navigation_finished() or global_position.distance_to(player_move_target) < 3.0:
			has_player_move_target = false
			state = State.IDLE
			velocity = Vector3.ZERO
		else:
			var next = nav_agent.get_next_path_position()
			var dir = (next - global_position).normalized()
			velocity = dir * move_speed
			if dir.length() > 0.1:
				rotation.y = lerp_angle(rotation.y, atan2(dir.x, dir.z), 10.0 * delta)
	else:
		velocity = Vector3.ZERO
		state = State.IDLE

func _find_player_enemy() -> Node3D:
	# Player vampire attacks human units
	var best: Node3D = null; var bd = INF
	for u in UnitManager.human_units:
		if not is_instance_valid(u): continue
		var d = global_position.distance_to(u.global_position)
		if d < detection_range and d < bd: bd = d; best = u
	return best

func command_move_to(pos: Vector3):
	player_move_target = pos
	has_player_move_target = true
	state = State.PATROLLING

func command_stop():
	has_player_move_target = false
	state = State.IDLE
	velocity = Vector3.ZERO

func _ai_think():
	if GameClock.is_daytime() and state != State.HIDING:
		state = State.RETREATING; nav_agent.target_position = Vector3.ZERO; return
	if state in [State.ATTACKING, State.ATTACKING_BUILDING]: return
	var near = _find_enemy()
	if near and global_position.distance_to(near.global_position) < detection_range:
		target_unit = near; state = State.CHASING; wall_attack_patience = 0.0; return
	if state == State.PATROLLING and wall_attack_patience > 1.0: _try_attack_wall()

func _find_enemy() -> Node3D:
	var best: Node3D = null; var bd = detection_range
	for u in UnitManager.human_units:
		if is_instance_valid(u) and "current_health" in u and u.current_health > 0:
			var d = global_position.distance_to(u.global_position)
			if d < bd: bd = d; best = u
	return best

func _pick_patrol():
	var rng = RandomNumberGenerator.new(); rng.randomize()
	# Hunt player buildings first, then units, then random around circle
	var targets: Array[Vector3] = []
	for b in BuildingManager.placed_buildings:
		if is_instance_valid(b): targets.append(b.global_position)
	for u in UnitManager.human_units:
		if is_instance_valid(u): targets.append(u.global_position)
	if targets.size() > 0:
		var t = targets[rng.randi_range(0, targets.size() - 1)]
		patrol_target = t + Vector3(rng.randf_range(-10,10), 0, rng.randf_range(-10,10))
	else:
		# No targets found - patrol around spawn circle
		var angle = rng.randf() * TAU
		patrol_target = Vector3(cos(angle) * 60.0, 0, sin(angle) * 60.0)
	nav_agent.target_position = patrol_target

func _patrol(delta: float):
	if nav_agent.is_navigation_finished() or global_position.distance_to(patrol_target) < 5.0:
		_pick_patrol(); return
	var next = nav_agent.get_next_path_position()
	var dir = (next - global_position).normalized(); dir.y = 0
	velocity = dir * move_speed
	if dir.length() > 0.1: rotation.y = lerp_angle(rotation.y, atan2(dir.x, dir.z), delta * 8.0)

func _chase(delta: float):
	if not is_instance_valid(target_unit) or target_unit.current_health <= 0:
		target_unit = null; state = State.PATROLLING; _pick_patrol(); return
	if global_position.distance_to(target_unit.global_position) <= attack_range:
		state = State.ATTACKING; velocity = Vector3.ZERO; return
	nav_agent.target_position = target_unit.global_position
	var next = nav_agent.get_next_path_position()
	var dir = (next - global_position).normalized(); dir.y = 0
	velocity = dir * move_speed
	if dir.length() > 0.1: rotation.y = lerp_angle(rotation.y, atan2(dir.x, dir.z), delta * 8.0)

func _attack(delta: float):
	if not is_instance_valid(target_unit) or ("current_health" in target_unit and target_unit.current_health <= 0):
		target_unit = null
		if is_player_controlled:
			state = State.IDLE
		else:
			state = State.PATROLLING; _pick_patrol()
		return
	var dist = global_position.distance_to(target_unit.global_position)
	if dist > attack_range + 1.0:
		# Chase the target
		nav_agent.target_position = target_unit.global_position
		var next = nav_agent.get_next_path_position()
		var dir = (next - global_position).normalized(); dir.y = 0
		if dir.length_squared() < 0.001:
			dir = (target_unit.global_position - global_position).normalized(); dir.y = 0
		velocity = dir * move_speed
		if dir.length() > 0.1: rotation.y = lerp_angle(rotation.y, atan2(dir.x, dir.z), delta * 8.0)
		if not is_player_controlled and dist > detection_range * 1.5:
			state = State.PATROLLING; _pick_patrol()
		return
	velocity = Vector3.ZERO
	var ld = (target_unit.global_position - global_position).normalized()
	if ld.length() > 0.1: rotation.y = lerp_angle(rotation.y, atan2(ld.x, ld.z), delta * 10.0)
	if attack_timer <= 0:
		attack_timer = attack_cooldown
		is_attack_animating = true; attack_anim_time = 0.0
		if SoundManager: SoundManager.play_sound("attack_hit", -12.0)
		if target_unit.has_method("take_damage"):
			target_unit.take_damage(attack_damage, self)
			current_health = mini(current_health + int(attack_damage * lifesteal_percent), max_health)
			_update_hp()

func _attack_bldg(delta: float):
	if not is_instance_valid(target_building):
		target_building = null
		nav_agent.avoidance_enabled = true
		if is_player_controlled:
			state = State.IDLE
		else:
			state = State.PATROLLING; _pick_patrol()
		return
	nav_agent.avoidance_enabled = false
	var bpos = target_building.global_position
	var diff = Vector3(global_position.x - bpos.x, 0, global_position.z - bpos.z)
	var dist_xz = diff.length()
	# Buildings have collision boxes 3-6m wide. Vampire physically can't get
	# closer than ~3.5m from center due to StaticBody3D collision.
	# Attack range must be LARGER than building collision radius!
	var melee_range = 6.5  # Covers Town Hall (6x6), Barracks (6x6), Wall (2x2)
	if dist_xz > 12.0:
		# Far: use nav agent
		nav_agent.target_position = bpos
		var next = nav_agent.get_next_path_position()
		var dir = (next - global_position).normalized(); dir.y = 0
		if dir.length_squared() < 0.001:
			dir = (bpos - global_position).normalized(); dir.y = 0
		velocity = dir * move_speed
		if dir.length() > 0.1: rotation.y = lerp_angle(rotation.y, atan2(dir.x, dir.z), delta * 8.0)
	elif dist_xz > melee_range:
		# Close: direct movement
		var cdir = -diff.normalized()
		velocity = cdir * move_speed * 0.8
		if cdir.length() > 0.1: rotation.y = lerp_angle(rotation.y, atan2(cdir.x, cdir.z), delta * 8.0)
		# Stuck detection: if we haven't moved in 0.5s, we're at the collision edge - attack anyway
		_bldg_stuck_timer += delta
		if _bldg_stuck_timer > 0.4:
			# We're blocked by the building collision - close enough to attack!
			_do_building_melee(delta)
	else:
		_bldg_stuck_timer = 0.0
		_do_building_melee(delta)

func _do_building_melee(delta: float):
	velocity = Vector3.ZERO
	if is_instance_valid(target_building):
		var bpos = target_building.global_position
		var fd = (bpos - global_position).normalized(); fd.y = 0
		if fd.length() > 0.1:
			rotation.y = lerp_angle(rotation.y, atan2(fd.x, fd.z), delta * 8.0)
	if attack_timer <= 0:
		attack_timer = attack_cooldown * 1.2
		is_attack_animating = true; attack_anim_time = 0.0
		if SoundManager: SoundManager.play_sound("attack_hit", -10.0)
		if is_instance_valid(target_building) and target_building.has_method("take_damage"):
			target_building.take_damage(attack_damage)
			if "current_health" in target_building and target_building.current_health <= 0:
				target_building = null
				_bldg_stuck_timer = 0.0
				nav_agent.avoidance_enabled = true
				if is_player_controlled:
					state = State.IDLE
				else:
					state = State.PATROLLING; _pick_patrol()

func _retreat(delta: float):
	if nav_agent.is_navigation_finished() or global_position.distance_to(Vector3.ZERO) < 15.0:
		state = State.HIDING; velocity = Vector3.ZERO; return
	var next = nav_agent.get_next_path_position()
	var dir = (next - global_position).normalized(); dir.y = 0
	velocity = dir * move_speed * 1.2
	if dir.length() > 0.1: rotation.y = lerp_angle(rotation.y, atan2(dir.x, dir.z), delta * 8.0)

func _try_attack_wall():
	var best: Node3D = null; var bd: float = 15.0
	for b in BuildingManager.placed_buildings:
		if is_instance_valid(b) and "building_type" in b:
			if b.building_type in [BuildingManager.BuildingType.WALL, BuildingManager.BuildingType.GATE]:
				var d = global_position.distance_to(b.global_position)
				if d < bd: bd = d; best = b
	if best: target_building = best; state = State.ATTACKING_BUILDING; wall_attack_patience = 0.0

func take_damage(amount: int, _attacker: Node3D = null):
	current_health -= amount; current_health = max(0, current_health)
	_update_hp(); health_bar.visible = true
	if body_mesh and body_mesh.material_override:
		var oc = body_mesh.material_override.albedo_color
		body_mesh.material_override.albedo_color = Color(0.8,0.1,0.1)
		get_tree().create_timer(0.1).timeout.connect(func():
			if is_instance_valid(body_mesh) and body_mesh.material_override:
				body_mesh.material_override.albedo_color = oc)
	var l = Label3D.new(); l.text = "-%d"%amount; l.font_size = 28
	l.modulate = Color(1,0.8,0.2); l.billboard = BaseMaterial3D.BILLBOARD_ENABLED; l.no_depth_test = true
	l.position = global_position + Vector3(randf_range(-0.3,0.3),3,0)
	get_tree().current_scene.add_child(l)
	var tw = create_tween()
	tw.tween_property(l,"position:y",l.position.y+1.5,0.8)
	tw.parallel().tween_property(l,"modulate:a",0.0,0.8)
	tw.tween_callback(l.queue_free)
	if current_health <= 0: _die()

func _update_hp():
	var r = float(current_health) / float(max_health)
	health_bar_fill.scale.x = max(0.01, r)
	health_bar_fill.position.x = (r - 1.0) * 0.55

func _die():
	if SoundManager: SoundManager.play_sound("death", -6.0)
	UnitManager.unregister_unit(self); GameState.on_vampire_killed(); died.emit()
	var tw = create_tween()
	tw.tween_property(self,"scale",Vector3(0.01,0.01,0.01),0.5)
	tw.tween_callback(queue_free)

func set_selected(val: bool):
	is_selected = val; selection_ring.visible = val
	health_bar.visible = val or current_health < max_health

func get_team() -> int: return team
