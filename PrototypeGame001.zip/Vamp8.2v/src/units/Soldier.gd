## Soldier - Trainable combat unit from Barracks
## Melee fighter with shield, stronger than workers in combat
extends CharacterBody3D

signal health_changed(current_hp: int, max_hp: int)
signal died()

@export var max_health: int = 200
@export var move_speed: float = 7.0
@export var attack_damage: int = 20
@export var attack_range: float = 2.5
@export var attack_cooldown: float = 1.0
@export var armor: int = 3  # Damage reduction

enum UnitState { IDLE, MOVING, ATTACKING, PATROL, DEAD }

var current_health: int = 200
var state: int = UnitState.IDLE
var team: int = GameState.Team.HUMAN
var is_selected: bool = false
var attack_timer: float = 0.0
var target_unit: Node3D = null
var patrol_center: Vector3 = Vector3.ZERO
var patrol_radius: float = 15.0
var nav_ready: bool = false
var auto_attack_range: float = 12.0

var body_mesh: MeshInstance3D
var shield_mesh: MeshInstance3D
var sword_mesh: MeshInstance3D
var selection_ring: MeshInstance3D
var hp_bar_pivot: Node3D
var hp_bar_fill: MeshInstance3D
var nav_agent: NavigationAgent3D

func _ready():
	current_health = max_health
	collision_layer = 2
	collision_mask = 1 | 4

	var col = CollisionShape3D.new()
	var capsule_shape = CapsuleShape3D.new()
	capsule_shape.radius = 0.4
	capsule_shape.height = 1.8
	col.shape = capsule_shape
	col.position.y = 0.9
	add_child(col)

	# Body (armored look)
	body_mesh = MeshInstance3D.new()
	var cap = CapsuleMesh.new()
	cap.radius = 0.35
	cap.height = 1.5
	body_mesh.mesh = cap
	body_mesh.position.y = 0.75
	var bmat = StandardMaterial3D.new()
	bmat.albedo_color = Color(0.55, 0.5, 0.4)  # Armor color
	bmat.metallic = 0.3
	bmat.roughness = 0.6
	body_mesh.material_override = bmat
	add_child(body_mesh)

	# Head
	var head = MeshInstance3D.new()
	var hsph = SphereMesh.new()
	hsph.radius = 0.2
	hsph.height = 0.4
	head.mesh = hsph
	head.position.y = 1.7
	var hmat = StandardMaterial3D.new()
	hmat.albedo_color = Color(0.85, 0.72, 0.58)
	head.material_override = hmat
	add_child(head)

	# Helmet
	var helmet = MeshInstance3D.new()
	var helm_mesh = SphereMesh.new()
	helm_mesh.radius = 0.24
	helm_mesh.height = 0.35
	helmet.mesh = helm_mesh
	helmet.position.y = 1.8
	var helm_mat = StandardMaterial3D.new()
	helm_mat.albedo_color = Color(0.45, 0.4, 0.35)
	helm_mat.metallic = 0.5
	helmet.material_override = helm_mat
	add_child(helmet)

	# Shield (left side)
	shield_mesh = MeshInstance3D.new()
	var shm = BoxMesh.new()
	shm.size = Vector3(0.08, 0.6, 0.45)
	shield_mesh.mesh = shm
	shield_mesh.position = Vector3(-0.4, 1.0, 0.1)
	var smat = StandardMaterial3D.new()
	smat.albedo_color = Color(0.3, 0.25, 0.15)
	smat.metallic = 0.2
	shield_mesh.material_override = smat
	add_child(shield_mesh)

	# Sword (right side)
	sword_mesh = MeshInstance3D.new()
	var swm = BoxMesh.new()
	swm.size = Vector3(0.05, 0.8, 0.05)
	sword_mesh.mesh = swm
	sword_mesh.position = Vector3(0.4, 1.2, 0.0)
	var sw_mat = StandardMaterial3D.new()
	sw_mat.albedo_color = Color(0.7, 0.7, 0.75)
	sw_mat.metallic = 0.7
	sw_mat.roughness = 0.3
	sword_mesh.material_override = sw_mat
	add_child(sword_mesh)

	# Selection ring
	selection_ring = MeshInstance3D.new()
	var torus = TorusMesh.new()
	torus.inner_radius = 0.5
	torus.outer_radius = 0.7
	torus.rings = 16
	torus.ring_segments = 16
	selection_ring.mesh = torus
	selection_ring.position.y = 0.05
	var rmat = StandardMaterial3D.new()
	rmat.albedo_color = Color(0.2, 1.0, 0.2, 0.7)
	rmat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	rmat.emission_enabled = true
	rmat.emission = Color(0.2, 1.0, 0.2)
	rmat.emission_energy_multiplier = 2.0
	rmat.no_depth_test = true
	selection_ring.material_override = rmat
	selection_ring.visible = false
	add_child(selection_ring)

	# HP bar
	hp_bar_pivot = Node3D.new()
	hp_bar_pivot.position.y = 2.3
	add_child(hp_bar_pivot)
	var bg = MeshInstance3D.new()
	bg.mesh = BoxMesh.new()
	bg.mesh.size = Vector3(1.0, 0.1, 0.02)
	var bgm = StandardMaterial3D.new()
	bgm.albedo_color = Color(0.15, 0, 0)
	bgm.no_depth_test = true
	bg.material_override = bgm
	hp_bar_pivot.add_child(bg)
	hp_bar_fill = MeshInstance3D.new()
	hp_bar_fill.mesh = BoxMesh.new()
	hp_bar_fill.mesh.size = Vector3(0.9, 0.07, 0.03)
	var fm = StandardMaterial3D.new()
	fm.albedo_color = Color(0.1, 0.9, 0.1)
	fm.no_depth_test = true
	fm.emission_enabled = true
	fm.emission = Color(0.1, 0.9, 0.1)
	fm.emission_energy_multiplier = 0.3
	hp_bar_fill.material_override = fm
	hp_bar_pivot.add_child(hp_bar_fill)
	hp_bar_pivot.visible = false

	# Navigation
	nav_agent = NavigationAgent3D.new()
	nav_agent.path_desired_distance = 1.0
	nav_agent.target_desired_distance = 1.5
	nav_agent.avoidance_enabled = true
	nav_agent.radius = 0.5
	nav_agent.max_speed = move_speed
	add_child(nav_agent)
	nav_agent.velocity_computed.connect(_on_velocity_computed)

	patrol_center = global_position

	# Night torch
	var _nl = OmniLight3D.new()
	_nl.light_color = Color(1.0, 0.85, 0.6)
	_nl.light_energy = 0.6
	_nl.omni_range = 33.0
	_nl.omni_attenuation = 0.7
	_nl.shadow_enabled = false
	_nl.position.y = 1.5
	_nl.name = "NightLight"
	add_child(_nl)

	await get_tree().process_frame
	nav_ready = true
	UnitManager.register_unit(self)
	GameState.add_population()

func _exit_tree():
	UnitManager.unregister_unit(self)
	GameState.remove_population()

func _process(delta: float):
	if hp_bar_pivot.visible:
		var cam = get_viewport().get_camera_3d()
		if cam and hp_bar_pivot.global_position.distance_squared_to(cam.global_position) > 0.001:
			if hp_bar_pivot.global_position.distance_squared_to(cam.global_position) > 0.1: hp_bar_pivot.look_at(cam.global_position, Vector3.UP)
	var nl = get_node_or_null("NightLight")
	if nl:
		var target_e = 2.5 if GameClock.is_nighttime() else 1.0
		if GameClock.time_of_day > 0.35 and not GameClock.is_nighttime():
			var dt = (GameClock.time_of_day - 0.35) / 0.15
			target_e = lerp(1.0, 2.5, clampf(dt, 0.0, 1.0))
		nl.light_energy = lerp(nl.light_energy, target_e, delta * 3.0)
	# Sword swing animation during attack
	if state == UnitState.ATTACKING:
		attack_timer += delta  # visual only
		sword_mesh.rotation.x = sin(Time.get_ticks_msec() * 0.01) * 0.5

func _physics_process(delta: float):
	if not nav_ready:
		return
	if GameState.is_game_over:
		return

	match state:
		UnitState.IDLE:
			velocity.x = move_toward(velocity.x, 0, move_speed * 2.0)
			velocity.z = move_toward(velocity.z, 0, move_speed * 2.0)
			sword_mesh.rotation.x = 0
			_auto_attack_check()
		UnitState.MOVING:
			_do_move(delta)
		UnitState.ATTACKING:
			_do_attack(delta)
		UnitState.PATROL:
			_do_patrol(delta)

	if not is_on_floor():
		velocity.y -= 25.0 * delta
	else:
		velocity.y = 0
	move_and_slide()

func _auto_attack_check():
	# Auto-attack nearby enemies when idle
	var enemies = UnitManager.get_units_in_radius(global_position, auto_attack_range, GameState.Team.VAMPIRE)
	if enemies.size() > 0:
		target_unit = enemies[0]
		state = UnitState.ATTACKING

func _do_move(delta: float):
	if nav_agent.is_navigation_finished():
		state = UnitState.IDLE
		return
	var next_pos = nav_agent.get_next_path_position()
	var dir = (next_pos - global_position)
	dir.y = 0
	if dir.length() > 0.01:
		dir = dir.normalized()
		rotation.y = lerp_angle(rotation.y, atan2(dir.x, dir.z), 10.0 * delta)
		nav_agent.velocity = dir * move_speed
	else:
		state = UnitState.IDLE

func _do_attack(delta: float):
	if not is_instance_valid(target_unit):
		target_unit = null
		state = UnitState.IDLE
		return
	var dist = global_position.distance_to(target_unit.global_position)
	if dist > attack_range:
		nav_agent.target_position = target_unit.global_position
		if not nav_agent.is_navigation_finished():
			var next = nav_agent.get_next_path_position()
			var dir = (next - global_position)
			dir.y = 0
			if dir.length() > 0.01:
				dir = dir.normalized()
				rotation.y = lerp_angle(rotation.y, atan2(dir.x, dir.z), 10.0 * delta)
				nav_agent.velocity = dir * move_speed
	else:
		velocity.x = 0
		velocity.z = 0
		var to_target = (target_unit.global_position - global_position).normalized()
		rotation.y = lerp_angle(rotation.y, atan2(to_target.x, to_target.z), 8.0 * delta)
		attack_timer += delta
		if attack_timer >= attack_cooldown:
			attack_timer = 0.0
			if SoundManager: SoundManager.play_sound("sword_swing", -14.0)
			if target_unit.has_method("take_damage"):
				target_unit.take_damage(attack_damage)
				# Swing animation
				body_mesh.rotation.x = -0.4
				var tw = create_tween()
				tw.tween_property(body_mesh, "rotation:x", 0.0, 0.2)

func _do_patrol(delta: float):
	if nav_agent.is_navigation_finished():
		# Pick new patrol point
		var rng = RandomNumberGenerator.new()
		rng.randomize()
		var angle = rng.randf() * TAU
		var dist_r = rng.randf_range(3.0, patrol_radius)
		var target = patrol_center + Vector3(cos(angle) * dist_r, 0, sin(angle) * dist_r)
		nav_agent.target_position = target
	
	# Check for enemies while patrolling
	_auto_attack_check()
	
	var next_pos = nav_agent.get_next_path_position()
	var dir = (next_pos - global_position)
	dir.y = 0
	if dir.length() > 0.01:
		dir = dir.normalized()
		rotation.y = lerp_angle(rotation.y, atan2(dir.x, dir.z), 10.0 * delta)
		nav_agent.velocity = dir * move_speed

func _on_velocity_computed(safe_vel: Vector3):
	velocity.x = safe_vel.x
	velocity.z = safe_vel.z

func get_state_string() -> String:
	match state:
		UnitState.IDLE: return "Standing Guard"
		UnitState.MOVING: return "Moving"
		UnitState.ATTACKING: return "Fighting"
		UnitState.PATROL: return "Patrolling"
		_: return ""

func command_move(target: Vector3):
	target_unit = null
	state = UnitState.MOVING
	if nav_ready:
		nav_agent.target_position = target

func command_attack(target: Node3D):
	target_unit = target
	state = UnitState.ATTACKING

func command_stop():
	state = UnitState.IDLE
	target_unit = null
	velocity = Vector3.ZERO

func command_patrol():
	patrol_center = global_position
	state = UnitState.PATROL

func set_selected(val: bool):
	is_selected = val
	selection_ring.visible = val
	hp_bar_pivot.visible = val or current_health < max_health

func get_team() -> int:
	return team

func take_damage(amount: int):
	amount = maxi(1, amount - armor)
	current_health -= amount
	current_health = max(0, current_health)
	_update_hp_bar()
	hp_bar_pivot.visible = true
	health_changed.emit(current_health, max_health)
	var bmat_ref = body_mesh.material_override as StandardMaterial3D
	if bmat_ref:
		var orig = Color(0.55, 0.5, 0.4)
		bmat_ref.albedo_color = Color(1.0, 0.3, 0.3)
		var tw = create_tween()
		tw.tween_property(bmat_ref, "albedo_color", orig, 0.25)
	if current_health <= 0:
		_die()

func heal(amount: int):
	current_health = mini(current_health + amount, max_health)
	_update_hp_bar()

func _update_hp_bar():
	if not hp_bar_fill:
		return
	var ratio = float(current_health) / float(max_health)
	hp_bar_fill.scale.x = ratio
	hp_bar_fill.position.x = (ratio - 1.0) * 0.45
	var mat = hp_bar_fill.material_override as StandardMaterial3D
	if mat:
		if ratio > 0.6:
			mat.albedo_color = Color(0.1, 0.9, 0.1)
		elif ratio > 0.3:
			mat.albedo_color = Color(0.9, 0.9, 0.1)
		else:
			mat.albedo_color = Color(0.9, 0.1, 0.1)
		mat.emission = mat.albedo_color

func _die():
	state = UnitState.DEAD
	if SoundManager: SoundManager.play_sound("death", -8.0)
	died.emit()
	GameState.on_worker_died()
	var tw = create_tween()
	tw.tween_property(self, "scale", Vector3(1, 0, 1), 0.5)
	tw.tween_callback(queue_free)
